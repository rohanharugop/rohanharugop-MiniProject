RAMAIAH INSTITUTE OF TECHNOLOGY
(Autonomous Institute, Afiliated to VTU)
Approved by AICTE, New Delhi & Govt. of Karnataka
Accredited by NBA & NAAC with A+ Grade
PIONEERING’ EXCELLENCE IN

ENGINEERING EDUCATION

PROSPECTUS
http://www.msrit.edu

Instituteof Technology

RAMAIAH

YEAR CELEBRATIONS
CENTENARY

DR. M.S. RAMAIAHDR. M.S. RAMAIAH

60 60
YearsYears
CELEBRATINGCELEBRATING
DIAMOND JUBILEEDIAMOND JUBILEE
RAMAIAH ANTHEM

Among Engineering Colleges

# 1 Affiliated to VTU, Karnataka

As per National Institutional Ranking Framework, MoE, Govt. of India. 2022
RIT Ranked

# 67

Best Engineering
Institute Among 1249
Reputed Institutes
in India

# 17

Best Architecture College
Among 91 Reputed
Architecture Colleges in
India
A TRIBUTE TO A
NOBLE SOUL
Founder Chairman,
Gokula Education Foundation
Dr. M.S. Ramaiah

(1922 - 1997)

We offer our humble tributes to our venerable founder

Chairman late Dr. M S Ramaiah, a renowned philanthropist,

educationist and visionary who Established the Gokula

Education Foundation in 1962 and M S Ramaiah Institute of

Technology (MSRIT) was started in the same year envisioning

the need for quality technical education towards taking India

ahead.

MSRIT is celebrating its Diamond Jubilee year in 2022, at this

juncture, we at MSRIT reiterate our commitment to creating

world-class technical professionals who strongly reflect the

universal human values of integrity, honesty, and character as

they go on to contribute to the nation and the world at large.

Dr. Mathikere Sampangappa Ramaiah was born on
20th April 1922. This great visionary lives on
through his legacy, which continues to illuminate
the lives of millions through healthcare, education
and philanthropy.

Dr. M S Ramaiah began his career at Indian Testing
Laboratories, where he rose in popularity amongst
his peers and colleagues. Dr. M S Ramaiah moved
on to the Mysore Railway narrow gauge section as
a fireman a few days later his father called him
back to the family brick manufacturing facility. His
zeal to build greater milestones inspired Dr. M S
Ramaiah into civil contracting of his first
Radhanagiri Hydroelectric Project, building the
Ghataprabha left bank canal. The Sharavathi valley
and Dharma dam and the renowned Irrigation
Project of River Budhi Gandak on the Indo-Nepal
border.

Dr. M S Ramaiah’s strong connection with nature
lured him to the start Gokul dairy farm in 1950 and
procure 700 acres of land near Devanahalli which
he evolved into a lush green region.

In 1957 Dr. M S Ramaiah took over Tayinadu a local
newspaper from Chamrajpet which he enriched
with ample resources and passion. In 1963 he
launched a monthly called Kailasa and a weekly
called Gokula which saw eight years of growing
appreciation in the Kannada Literary World.

Dr. M S Ramaiah believed education is the most
powerful tool to change the world and this
empowered him to set up educational institutions.
In 1962 Ramaiah Institute of Technology (RIT) was
established, which foresaw India’s IT revolution
and is continuously grooming the country’s
leading talent. Today, Ramaiah Institute of
Technology has been recognized as one of the
premier educational institutions across India and
Ranked First among the VTU aliated Engineering
Institutions as per the NIRF, MoE, Government of
India. RIT offers courses that are shaping
professionals of today and tomorrow with
engineering brilliance. Dr. M S Ramaiah focused on
all fields and levels of education, i.e., Nursery to
Surgery, Foundational courses to building the
foundation of the country with lawyers, Artists,
Doctors, Managers and Business Analysts.

TRIBUTE TO A VISIONARY
Celebrating 100 years of this Great Iconic Figure

In 1972 he facilitated water, electricity and
innovative agricultural practices to plant numerous
trees. He won an Asian record for being a single
individual to nurture so many trees, he was also the
first person to implement drip irrigation in private
farms.
Dr. M S Ramaiah welcomed industrialization and set
up M S Ramaiah industrial estate for running
small-scale industries in plastics, agro products,
steel & metals and software technology.
Being a patron of art and culture, Dr. M S Ramaiah
provided a platform to many artists to showcase
their talents. He organised the Kannada Sahithya
Sammelana at Kaiwara in the year 1990, for the
neoteric and literary minds of Kannada literature to
convene.
Dr. M S Ramaiah took over as the Dharmadhikari of
Kaiwara temple and oversaw a pristine temple built
for Tatayya. Great development works were carried
out, including lodging for thousands of daily
devotees. The trust arranges Prasad distribution
every day for all visitors.
Dr. M S Ramaiah built the pristine Venkateshwara
Temple and the magnificent entrance Arch of Raja
Rajeshwari Temple, which is still one of the largest
arches built.
This charismatic man nourished people’s progress
through education as well as philanthropy, he set up
an education fund to support deserving students
irrespective of caste or religion, which today
provides impactful assistance of nearly 90 lakhs a
year. He even developed affordable residential
layouts to house those who could not afford them.
Dr. M S Ramaih also developed numerous places of
worship community marriage halls and tall trees for
mass marriages, and public kitchens and even
started a rural health care center to offer free
medical and dental treatment by top doctors of
Bengaluru city.
Dr. M S Ramaiah’s dreams shine on beyond his
lifetime and his greatness fondly lives on in the
hearts of thousands of people through his numerous
impactful initiatives.
What we have done for ourselves alone dies with us.
What we have done for others and the world remains
and is immortal. – Dr. M.S. Ramaiah
MSRIT - A
Momentous Journey
Spanning 50 Years....
The year 2011-12 is a Golden Jubilee Year and
MSRIT launched the celebration with a glittering
inauguration event graced by His Excellency,
Prof. APJ Abdul Kalam, Former President of
India. Speaking on the occasion, Prof Kalam
succinctly summed up MSRIT’s seminal
contribution to engineering education and the
nation as follows...
“During the last 50 years, MSRIT would have
generated around 50,000 engineers and
technologists who are deployed in various fields
in india and abroad...”
MSRIT - 60 years
Journey of Impeccable
Academic Excellence
I congratulate the M.S. Ramaiah Institute of Technology,

Bangalore on their Diamond Jubilee celebrations. In these sixty

years, the institute has come a long way in imparting education in

the fields of engineering, technology, and management.

Since ancient times, India has been the centre of higher learning.

Education has helped civilisations grow and India has always

been pioneering new educational avenues, whether spiritual or

otherwise.

It has been an endeavour of the Government to reinforce

qualitative improvement in the learning process and educational

infrastructure throughout the country. With sustained efforts, and

participation from institutes such as M.S. Ramaiah Institute of

Technology, we are confident of building the new India of the 21st

century.

Sri Pralhad Joshi
Hon'ble Minister
Parliamentary Affairs,
Coal and Mines,
Govt. of India
Sri Pralhad Joshi
Hon'ble Minister
Parliamentary Affairs,
Coal and Mines,
Govt. of India
GOKULA EDUCATION
FOUNDATION
Dr. M.R. Jayaram
Chairman,
Gokula Education Foundation
Sri. M.R. Seetharam
Vice-Chairman,
Gokula Education Foundation &
Director, Ramaiah Institute of Technology
Sri. M.R. Ramaiah
Secretary,
Gokula Education Foundation &
Director, Ramaiah Institute of Technology
We at M.S. Ramaiah Institute of Technology complete 60 years in 2022, a truly

momentous occasion. Today we are known as one of India’s leading names in

engineering education, a matter of great pride for all of us.

Since inception, MSRIT has been guided by the foresight and zeal of our

visionary Founder Chairman Dr. M.S. Ramaiah who nurtured this institution

through its most crucial years. Dr. M.S. Ramaiah also identified and brought in

professionals of impeccable character, qualification and qualities,

encouraging them to participate in the institution’s growth, a move that

contributed significantly to our success all along. As we celebrate our Golden

Jubilee, we wish to offer our grateful thanks to all those who contributed in

their various capacities to help us achieve this stature.

Post the demise of Dr. M.S. Ramaiah in 1997, MSRIT has been ably led by his

heirs, led by the current Chairman Dr. M.R. Jayaram who took over the helm.

Under his guidance, MSRIT has seen significant investments in infrastructure

& facilities and academic resources, besides notable enhancements in

administrative processes.

Throughout its journey, MSRIT has been responsive to the industry’s needs, be

it introducing new programs, forging alliances or acquiring equipment and

resources. Going forward, we realise engineering education will be strongly

about value addition and the creation of multi-faceted professionals with an

ability to confidently perform in a rapidly changing ecosystem. Our focus

would also be to partner with the industry in pushing the envelope of

innovation and address challenges that would have a wider impact on the

marketplace and the number of patents we have applied for in recent years

reflects this thinking.

We are now amidst an era of rapid change and are confident of managing this

aspect by realigning, reorienting, restructuring and redefining all paradigms

within our control efficiently and effectively to stay the pioneer we have

always been.

Sri. B.S. Ramaprasad IAS (retd.)
Chief Executive,
Gokula Education Foundation
Ramaiah Institute of Technology (RIT) is an institution that has consistently

been regarded for its high reputation and stakes in the field of quality

technical education. It has emerged as one among the top ranking technical

educational institution as per National Institutional Ranking Framework

(NIRF). RIT has also been the most sought-after for bright merited and career

oriented students. It offers academically vibrant environment with scope for

holistic development of students and imparting all the attributes required for

the students to meet global challenges. These attributes have made RIT stand

unique among various other technical educational institutions. As an

academically autonomous institution since 2007, many best practices are

being followed in the institution like outcome based contemporary curriculum

which is industry friendly having scope for innovation and creativity, flexibility

with choice based credit system and grading system of evaluation to match to

international standards. The departments of the institution have emerged as

Centres of excellence in the areas of the thrust and are committed to

generating technical manpower having skills and proficiency to address and

face the challenges of the competitive world with social concern.

RIT has been successful in creating more entrepreneurs and also provides

incubation facility to nurture the best ideas of students. RIT provides an

environment which is conducive to promote sports and cultural activities to

make students proficient in extra-curricular skills. Students are also

encouraged to participate in national/international events for better exposure.

Excellent placements by most of the reputed companies and many students

opting for higher studies, civil services exams and services in armed forces

shows the commitment of the institution to meet aspirations of students. This

brochure has all pertinent information about the institution to facilitate all

stake holders to know RIT better.

Dr. N.V.R Naidu, M.Tech, Ph.D
Principal, RIT
VISION
To be an Institution of International Eminence, renowned for

imparting quality technical education, cutting edge research

and innovation to meet global socio-economic needs.

MISSION
RIT shall meet the global socio-economic needs through :

Imparting quality technical education by nurturing a
conducive learning environment through continuous
improvement and customization.
Establishing research clusters in emerging areas in
collaboration with globally reputed organizations.
Establishing innovative skills development,
techno-entrepreneurial activities and consultancy for
socio-economic needs.
Dr. M.R. Jayaram
Chairman, GEF
GOVERNING
BODY
Dr. N.V.R. Naidu
Principal & Member Secretary
Sri. M.R. Kodandaram

Trustee, GEF

Dr. Archna
Registrar (Academics)
Prof. Satish C Sharma

Professor & Head,
Dept. of Mechanical & Industrial Engg.
IIT, Roorkee, UGC Nominee

Dr. K.G. Chandrashekar

Principal, Govt. SKSJTI, Bangalore
State Govt. Nominee

Dr. H.C. Nagaraj

Principal, Nitte Meenakshi
Institute of Technology, Bangalore
VTU Nominee

Sri. B.S. Ramaprasad

Chief Executive,
GEF (Engg. & General Sciences)

Dr. V.K. Aatre
Former Scientific Advisor to Raksha Mantri
Secretary, Dept. of Defense, R&D
Director General, DRDO, Bangalore
Dr. Anita Kanavalli

Professor & Head,
Artificial Intelligence & Data Science

Dr. Pradipkumar Dixit

Vice Principal

Dr. Vinod Kumar Nowal
Deputy Managing Director,
Jindal Steel Works, Bellary
Dr. H.P. Khincha
Chairman, Karnataka State Innovation Council
Former Vice Chancellor, VTU, Belgaum
Sri. G. Ramachandra
Chief Finance Officer,
GEF (Engg. & General Sciences)
Sri. M.R. Sampangiramaiah
Trustee, GEF
Sri. M.R. Seetharam

Vice Chairman, GEF
Director, RIT

Sri. M.R. Ramaiah
Secretary, GEF
Director, RIT
Dr. N V R Naidu
Principal & Chairman
Dr. V Gopalakrishna
Director, Integra Micro Systems (P) Ltd, Bangalore

Dr. Y Narahari
Professor, Computer Science & Automation, IISc, Bangalore

Dr. J K Kittur [VTU nominee]
I/c Principal, Gogte Institute of Technology, Belagavi

Dr. Parasuram Balasubramanian
Theme Work Analytics (P) Ltd., Bangalore

Dr. Swarnalatha K S [VTU nominee]
Professor, Dept. of ISE, Nitte Meenakshi Institute of
Technology, Bangalore

Dr. Thippeswamy M N
HOD, Computer Science & Engg. (AI&ML)
& Computer Science & Engg. (Cyber security)

Dr. Pradipkumar Dixit
HOD, Electrical & Electronics Engineering

Dr. C K Narayanappa
HOD, Medical Electronics Engineering

Dr. A Jagannatha Reddy
HOD, Physics

Dr. Annapurna P Patil
HOD, Computer Science & Engineering

Dr. Anita Kanavalli
HOD, Artificial Intelligence & Data Science

Dr. Raghuram S
Associate Professor, Electronics & Comm. Engg.
Dr. N L Ramesh
HOD, Mathematics & I/c Humanities

Dr. Ahalya N
Associate Professor, Biotechnology
Dr. K R V Subramanian
Head, R&D
Dr. Sanjay H A
HOD, Information Science & Engineering

Dr. P V Raveendra
I/c HOD, Master of Business Administration
Dr. Maya V Karki
HOD, Electronics & Comm. Engineering

Sri. Babu Sathain V
Managing Director Process Pumps(I) Pvt. Ltd, Bangalore
Sri. A T Samuel
Director, STUP Consultants, Bangalore
Dr. Vikram M Gadre
Professor, Dept. of Electrical Engineering, IIT, Bombay
Dr. Raji George
HOD, Mechanical Engineering
Prof. Salim Iddalagi [VTU nominee]
Professor, Dept. of ECE, Basaveshwar Engineering College
Bagalkote
Dr. I Venugopal
HOD, Civil Engineering
Ar. Pushpa Devanathan
HOD, School of Architecture
Dr. N D Prasanna
HOD, Industrial Engineering & Management
Dr. M K Pushpa
HOD, Electronics & Instrumentation Engineering
Dr. Jagadish Kallimani
HOD, Artificial Intelligence & Machine Learning
Dr. Chandraprabha M N
HOD, Biotechnology
Dr. B K Sujatha
HOD, Electronics & Telecommunication Engg.
Dr. Archna
Registrar (Academics) & Member Secretary
Dr. B M Nagabhushana
HOD, Chemistry
Dr. Viswanath Talasila
Professor, Electronics & Telecommunication Engg.
Dr. G M Madhu
Professor, Chemical Engineering
Dr. G S Prakash
Controller of Examinations
Dr. Seema S
HOD, Master of Computer Applications
ACADEMIC
COUNCIL
1 Dr. Raji George
Department of Mechanical Engineering
Dr. I Venugopal
Department of Civil Engineering
3

Dr. Maya V Karki
Department of Electronics & Communication
Engineering
4

Dr. Annapurna P Patil
Department of Computer Science Engineering
7

Dr. Jagadish S Kallimani
Department of Artificial Intelligence & Machine Learning
14

Dr. Thippeswamy M N
Department of Computer Science and Engineering
(Artificial Intelligence and Machine Learning) &
Computer Science and Engineering (Cyber Security)
15

Dr. Anita Kanavalli
Department of Artificial Intelligence & Data Science
13

Dr. Sanjay H A
Department of Information Science & Engineering
9

Dr. M K Pushpa
Department of Electronics & Instrumentation
Engineering
8

Dr. C K Narayanappa
Department of Medical Electronics Engineering
11

Dr. N D Prasanna
Industrial Engineering & Management
6

Dr. Archna
Department of Chemical Engineering
5

12 Dr. Chandraprabha M N
Department of Biotechnology
10 Dr. B K Sujatha
Department of Electronics & Telecommunication
Engineering
16 Dr. Pushpa Devanathan
Department of Architecture
20 Dr. Seema S
Master of Computer Applications (MCA)
21 Dr. P V Raveendra
Masters of Business Administration (MBA), In-charge
17 Dr. A Jagannatha Reddy
Department of Physics
18 Dr. B M Nagabhushana
Department of Chemistry
19 Dr. N L Ramesh
Department of Mathematics &
Department of Humanities, In-charge
ALL THE HEADS OF THE
DEPARTMENTS
2 Dr. Pradipkumar Dixit
Department of Electrical & Electronics
Engineering
MSRIT offers wide range of programs at UG, PG and doctorate level enabling students to

pursue excellence in their chosen streams. All programs are recognized by the concerned

Statutory bodies and Government agencies.

PROGRAMS
OFFERED
Eligibility: The candidate who has passed in 2nd PUC /
12th Std equivalent exam with English as one of the
languages and obtained a minimum of 45% of Marks in
aggregate in Physics and Mathematics along with
Chemistry / Biotechnology / Biology / Electronics /
Computer. 40% marks are required for SC, ST, Cat-1,
2A, 2B, 3A and 3B category candidates. The merit
/rank is determined by taking marks in equal
proportions in QE and CET in PCM subjects.
ELECTRONICS & COMMUNICATION ENGINEERING
COMPUTER SCIENCE & ENGINEERING
COMPUTER SCIENCE & ENGINEERING
(Artificial Intelligence and Machine Learning)
COMPUTER SCIENCE & ENGINEERING (Cyber Security)
ELECTRICAL & ELECTRONICS ENGINEERING
MECHANICAL ENGINEERING
CIVIL ENGINEERING
MSRIT offers the following 4 year Bachelor’s Degree
programs in engineering
UNDERGRADUATE
Programs
Eligibility: The candidate who has passed in 2nd PUC / 12th Std / equivalent exam with English as one of the languages and
obtained 50% marks in Physics, Chemistry, Mathematics and also 50% marks in aggregate at 2nd PUC / 12th Std / Equivalent
Exam in all the subjects. 45% marks are required for SC, ST, Cat-1, 2A, 2B, 3A and 3B category candidates and person with
disability of mental retardation or mental illness (including Dyslexia) The merit /rank is determined based on norms prescribed
in NATA/JEE Paper-2: Admission Rules: relevant Government orders is applicable in determining the merit for admission to
Architecture course.

5 YEAR BACHELOR’S DEGREE
IN ARCHITECTURE
CHEMICAL ENGINEERING
ELECTRONICS & TELECOMMUNICATION ENGINEERING
MEDICAL ELECTRONICS ENGINEERING
INFORMATION SCIENCE & ENGINEERING
ELECTRONICS & INSTRUMENTATION ENGINEERING
INDUSTRIAL ENGINEERING & MANAGEMENT
BIOTECHNOLOGY
ARTIFICIAL INTELLIGENCE AND MACHINE LEARNING
ARTIFICIAL INTELLIGENCE AND DATA SCIENCE
POSTGRADUATE
Programs
MASTER OF BUSINESS ADMINISTRATION (MBA)
We offer a 2-year MBA program, open to candidates who have a 3-year bachelor’s degree from a recognized university with not
less than 50.% of the marks in aggregate of all the years of the degree examination and 45% in case of candidates from
Karnataka belonging to SC/STand Category-1. Candidates require a valid score in KMAT / CMAT / MAT / PGCET for eligibility.

MASTER OF COMPUTER APPLICATIONS (MCA)
This is a 2-year program, open to candidates who have secured at least 50% marks (45% marks in case of candidates belonging
to reserved category) in BCA / Bachelor Degree in Computer Science and Engineering or Equivalent or B.Sc. / B.Com. / B.A. with
Mathematics at 10+2 Level or at Graduation Level (with additional bridge Courses as per the norms of the concerned
University). Candidates require a valid score in KMAT / PGCET for eligibility.
MASTER OF TECHNOLOGY (M.TECH) PROGRAMS
MSRIT offers the following 2-year M.Tech programs for which candidates with a B.E/B.Tech. degree in the relevant discipline
with at least 50% marks in aggregate are eligible. The minimum aggregate marks required is 45% in case of candidates from
Karnataka belonging to SC/ST Category-l. Candidates require a valid score in GATE / PGCET for eligibility.
RESEARCH
PROGRAMS
Research programs leading to Ph.D/M.S are available in the following
departments.
CIVIL ENGINEERING
MECHANICAL ENGINEERING
ELECTRICAL & ELECTRONICS ENGINEERING
ELECTRONICS & COMMUNICATION ENGINEERING
CHEMICAL ENGINEERING
COMPUTER SCIENCE & ENGINEERING
INDUSTRIAL ENGINEERING & MANAGEMENT
BIOTECHNOLOGY
INFORMATION SCIENCE & ENGINEERING
ELECTRONICS & TELECOMMUNICATION ENGINEERING
ELECTRONICS & INSTRUMENTATION ENGINEERING
MEDICAL ELECTRONICS ENGINEERING
ARCHITECTURE
CHEMISTRY
PHYSICS
MATHEMATICS
MASTERS OF BUSINESS ADMINISTRATION (MBA)
MASTER OF COMPUTER APPLICATIONS (MCA)
STRUCTURAL ENGINEERING
MANUFACTURING SCIENCE & ENGINEERING
COMPUTER INTEGRATED MANUFACTURING
COMPUTER APPLICATIONS IN INDUSTRIAL DRIVES
DIGITAL ELECTRONICS & COMMUNICATION
VLSI DESIGN & EMBEDDED SYSTEMS
COMPUTER SCIENCE & ENGINEERING
COMPUTER NETWORK ENGINEERING
INDUSTRIAL ENGINEERING
SOFTWARE ENGINEERING
DIGITAL COMMUNICATION
BIOTECHNOLOGY
MASTER OF ARCHITECTURE (LANDSCAPE ARCHITECTURE)
M.S. Ramaiah Institute of Technology is located in the heart
of Bangalore City on a sprawling campus spread across 25
acres. The institution has world class infrastructure - well
equipped laboratories; high tech auditoriums; library with
subscription to leading journals and magazines; digital
library with subscription to several online e-journals;
air-conditioned, high tech conference halls; dedicated sports
complex; canteens serving hygienic food; and excellent
hostel facilities for boys and girls.
MSR CHARITIES
KARNATAKA MINORITIES DEVELOPMENT CORPORATION
(LOAN SCHOLARSHIP)
LIST OF PRIVATE AND PUBLIC SECTORS AWARDING MERIT SCHOLARSHIPS
Various other scholarships are available and students are advised to find more about them through the various
other means.
DEPARTMENT OF MINORITIES
SITARAM JINDAL TRUST
INDIAN OIL CORPORATION
SCHOLARSHIPS
Deserving students can avail several scholarships awarded by the Government of Karnataka. Here is a list of the scholarships
and the corresponding applications that can be obtained from the Admission and Scholarship section during the month of
September every year.

RAMAIAH DOCTORAL FELLOWSHIP
M S Ramaiah Institute of Technology offers a Ph.D. Doctoral Programme in Faculty of Engineering, Faculty of Applied Sciences,
Faculty of Technology and Faculty of Management Studies. The research scholars admitted for full time Ph.D. Doctoral
Programme at MSRIT are provided with a Ramaiah Doctoral Fellowship amount of Rs. 25,000/- per month for a period of 3
years from the date of registration.

POST METRIC SCHOLARSHIP TO SC/STS
FEE-REIMBURSEMENTS TO SC/STS
FEE- CONCESSION TO CATEGORY-I, II, AND III
EXTRA BOARDING AND LODGING ALLOWANCE TO CATEGORY-I, II, & III
DEFENCE SCHOLARSHIP
MSRIT ALUMNI SCHOLARSHIP
RAMAIAH INSTITUTE OF TECHNOLOGY
MSR Nagar, MSRIT Post, Bengaluru - 560 054.
MULTIPURPOSE
BLOCK
Heritage
BLOCK
DIVISION OF ELECTRICAL
SCIENCES BLOCK

ARCHITECTURE
BLOCK
ENGINEERING
SCIENCES BLOCK
The library has a physical book section (with over 1,50,000 books)
and a digital section with subscription to several leading e-books,
e-journals and magazines.
LIBRARY
SNAPSHOT
MSRIT provides separate hostel facilities for boys and girls with
hygenic food, hot water facilities, common vegetarian mess, TV
lounge and a health centre and has a capacity of 1500 students.
HOSTEL
Located in Bangalore,

India’s IT nerve centre

and among the

fastest growing cities

VTU and UGC have
conferred the
prestigious
Autonomous
Status till 2029
Centrally located
with easy access
from different parts
of the city
National Board
of Accreditation
has accredited
12 UG programs
Entrepreneurship
Development Cell
(EDC) Ramaiah
“Evolute” a cross
disciplinary
Start-up ecosystem
Wi-Fi Campus with
wide Internet
connectivity and
dedicated browsing
Centre
Proctorial system
for guidance and
counseling to
students and
feedback to parents
Boeing Research
and Technology
Centre at MSRIT
Active research

activity with live

projects from reputed

organisations

Full-fledged
Placement Centre
that is active and
successful
Centre for Advanced
Materials
Technology
Centre for Imaging
Technologies
Schneider
Centre of
Excellence
Centre for
Bio & Energy
Materials Innovation
(CBEM)
Centre for
Antennas and Radio
Frequency Systems
(CARFS)
Centre for Cyber
Physical
Systems
The Department of Mechanical Engineering was started in the year
1962 with an intake of 60 students. The department has grown strong
over the last 40 years and today has an intake of 120 students for the
UG program and 18 students each for the two PG programs. All 38
faculty members are well qualified with minimum Post graduate
degree and 26 of them possess doctoral degree.
Being one of the oldest departments of the institution, we offer a
four-year bachelor’s degree program and two Master’s degree
programs in Manufacturing Science & Engineering and Computer
Integrated Manufacturing. The Department is a VTU recognized R&D
Centre for MSc Engineering and Ph.D program. The faculty members
have taken up a number of research projects funded by external
agencies such as DRDO, DST, AICTE and Visvesvaraya Technological
University. Faculty members from the department have published
number of technical papers in International/National Journals &
Conferences. They have also filed 12 and obtained 2 Patents. Two
research-oriented books have been published one by Taylor & Francis
and another by Institute of Physics. Many of them have authored Text
books in different domains of Mechanical Engineering which are
recommended by VTU Board of studies as reference books. The
department offers courses such as Robotics, Artificial Intelligence,
Additive manufacturing, Nano Technology, which meets the needs of
the present-day industry scenario. A Centre for Advanced Materials
Technology has been established for multi-disciplinary research and
innovations in materials, Nano materials and processes. It is equipped
with latest sophisticated high-end equipment’s such as XRD, FTIR,
UV-Vis, DSC, TGA and NDT tester etc. The students are motivated in
addition to their regular curriculum to involve in high quality research
with faculty. Number of research clubs are actively engaged in
different domains of mechanical engineering and cutting-edge
technology. 4 International Conferences (ICRAES) have been organized
for the department at a frequency of 2 years and also 15 Faculty
Development Programme in the last 3 years.
Society of Mechanical Engineers (SME) – A Society promoted by the
department and enlisted active faculty & student members, promotes
co-curricular activities among students such as guest lectures,
industrial visits, technical paper presentations and technical quizzes
for the students. Activities related to material characterization,
composite materials, Nano materials, Robotics and AI, Energy
Engineering, Aeronautics and Automobile Engineering are carried out.
Students from the department participate both at National and
International level competitions. Dr. Raji George Professor & Head
MECHANICAL ENGINEERING ACTIVITIES PAPER PRESENTED
National and International journals and conferences – 600 papers
published in the last five years.
Dr. Raji George
Professor & Head
MECHANICAL
ENGINEERING
ACTIVITIES
PAPER PRESENTED
National and International journals and conferences – 600 papers
published in the last five years
PROFESSOR & HOD
Dr. Raji George - M.E, Ph.D
PROFESSORS
Dr. Putta Bore Gowda - M.Tech, Ph.D
Dr. K.R. Phaneesh - M.E, Ph.D
Dr. K.R.V. Subramanian - M.E, Ph.D
ASSOCIATE PROFESSORS
Dr. C M Ramesha - M.Tech, Ph.D
Dr. P B Nagaraj - M.E, Ph.D
Dr. B P Hari Chandra - M.E, Ph.D
Dr. Niranjan Murthy - M.Tech, Ph.D
Dr. Mohandas K N - M.E, Ph.D
Dr. Sunith Babu L - M.Tech, Ph.D
Dr. T Anil Kumar - M.Tech, Ph.D
ASSISTANT PROFESSORS
Dr. Nagesh S N - M.Tech, Ph.D
Dr. Vishwanath Koti - M.Tech, Ph.D
Dr. Jyothilakshmi R - M.Tech, Ph.D
Dr. Siddaraju C - M.Tech, Ph.D
Dr. R. Kumar - M.Tech, Ph.D
Mr. Naveenkumar B K - M.Tech
Dr. Jaya Christiyan K G - M.Tech, Ph.D
Dr. Aruna Kumar P C - M.Tech, Ph.D,
Dr. Rajeesh S - M.Tech, Ph.D
Mrs. Bijayalakshmi Das - M.Tech, (Ph.D)
Dr. D. K. Vishwas - M.Tech, Ph.D,
Dr. Mahantesh S Matur - M.Tech, Ph.D
Dr. Girish V. Kulkarni - M.Tech, Ph.D
Dr. K. Lokesha - M.Tech, Ph.D
Mr. Bharath M R - M.Tech, MBA, (Ph.D)
Mr. Rajendra P - M.Tech, (Ph.D)
Mr. Pradeep Kumar K V - M.Tech, (Ph.D)
Mr. Ashok Kumar K - M.Tech, (Ph.D)
Dr. Balasubramanya H S - M.Tech Ph.D
Mr. Vinayak Talugeri - M.Tech, (Ph.D)
Mr. Nishanth R Acharya - M.Tech, (Ph.D)
Mr. Gururaj Lalgi - M.Tech, (Ph.D)
Dr. Prakrathi S - M.Tech, Ph.D
Mr. Pavankumar M V - M.Tech
Dr. Sriharsha Sripathi - M.Tech, Ph.D
Mr. Nandeesha H L - M.Tech, (Ph.D)
Mr. Deepak S - M.Tech, (Ph.D)
FACULTY
FUNDED PROJECTS
The department continuously encourages both faculty and
students to engage in Research and Consultancy. Faculty have
obtained external funded research projects and some of them
are listed below:
Performance evolution of biodegradable orthopaedic implants
under flow, load and biomolecules chelation, Science &
Engineering Research Board (SERB), New Delhi- sanctioned
amount of Rs.29.806 lakhs.
Study of Fatigue Crack Growth of AI 6061 - T6 Welds Obtained
by Gas Metal Arc Welding Technique, Armament research
board, DRDO–sanctioned amount of Rs.27.06 lakhs.
Experimental investigation of low Velocity impact and Damage
Studies of Hybrid Composite Inter / Intra layered with Glass
Carbon Kevlar fibers for aerospace application. - AICTE – RPS,
sanctioned amount of Rs.21.64 lakhs.
Analysis of Cooling strategies for controlling dimensional
accuracy during milling of Titanium alloy – SERB, New Delhi,
under Teachers Associateship for Research Excellence (TARE),
sanctioned amount 18.3 Lakhs.
Damage Studies on Sandwich Composites, Boeing India (P) Ltd,
Sanctioned amount of $ 11,000. • Characterization of LM
reinforced with TiB2 Subjected to wet/dry abrasive wear for
Industrial/Automotive applications – Funded by AICTE under
RPS - sanctioned amount of Rs. 11.58 Lakhs.
Synthesis and Characterization of Copper reinforced Carbon
nanotube composite – Funded by VTU - sanctioned amount of
Rs. 7.5 Lakhs.
Synthesis and Characterization and Modelling of functionally
graded ceramic composites – Funded by AICTE - sanctioned
amount of Rs. 8 Lakhs.
AWARDS AND CITATIONS
Department has obtained Two Indian Patent to its credit and 7
more are in the pipeline.
Two faculties of the department have been listed in the AD
Scientific Ranking list for 2021 & 2022 based on the Google
Scholar Profiles of scientists.
Many faculties of the department have won Best Research
Paper Presentation Awards in leading National and
International Conferences.
The Research Centre of the Department has so far facilitated
35 candidates, both faculty and industrial professionals,
towards obtaining their doctoral degree.
STUDENTS ACHIEVEMENTS
EDHITHA and QUATLAS, two teams which build Unmanned
Aerial Vehicles from the Department, participated in the
Annual SAE global level Competitions held in USA. EDIHTHA
won the prestigious award in the competition during 2015
outscoring 55 international teams in recent years they have
secured good positions in the competition also. Team
QUATLAS was placed 15th position internationally at the SAE
Aero Competition in 2018 and placed 4th internationally in
Technical presentation in the Virtual Competition held during
Team Stier Racing were placed overall Runner-Up in an
All-India competition held at Noida in 2019.
Team Volante were placed 1st in Endurance testing in Bharat
Formula Karting at Coimbatore, India in 2019.
QUATLAS Unmanned Air Vehicle participated in the
competition SAE Aero Design West 2019 in USA and was
ranked no.1 in Asia while being placed number 5 in the world.
Team VELOCITA from the Department participated in the
Formula Bharath competition in the IC Engine category and
placed 21st position in Pre-registration quiz among 118 teams.
Team Stier Racing won formula Green 2020 competition held
at KARI MOTOR Speedway in Coimbatore in 2020 (Under
Electric Vehicle category) and won best battery design, in the
4th Annual FSEV Concept Challenge (FSEV 2020).
Team CONCEPT 4 has been selected for NASA’s Human
Explration Rover Challenge which is going to be held in
November 2021 in USA.
INDUSTRY COLLABORATIONS
The Department has close associations with organizations such as HAL,
BHEL, MICO, HMT and National Laboratories like NAL, CPRI, Boeing,
ACE Manufacturing Systems (AMS) and FANUC. The department has
entered into MoU’s with FANUC India, M/s GOODWILL Industries, M/s
SNAM Alloys Pvt Ltd, University of Agriculture sciences, M/s TOYOTO
KIRLOSKAR MOTOR Pvt Ltd, M/s ACE Manufacturing systems Ltd, M/s
BOEING India Pvt Ltd, M/s UAS Associates and M/s SUZLON Industries.
The MoU with FANUC facilitates certification courses in FANUC CNC &
FANUC Robot to the students, which is widely recognized by CNC
machine manufacturers and developers across the country. Centre for
Advanced Materials Technology (CAMT) is established by the
Department in collaboration with Boeing India Pvt. Ltd.
Vertical Milling Machine-Spark-XL (4 Axis) FFT Analyzer [ 4 Channel] 6- Axis M10iD12 Fanuc Robot

Machine Shop UAV Student Team
Toyota Innova cut Section of Engine &
Gear Box – Toyota Engine Lab
The Department of Electrical and Electronics Engineering was started
in the year 1962 along with the institute. Subsequently, in the year
2004, and M.Tech program in Computer Applications in Industrial
Drives was started. Further, the department has been recognized as a
Research Centre in the year 2003 and has produced 11 doctorates and
2 MSc (Engg. by Research) in last 19 years. The department is actively
involved in R&D activities in the areas of High Voltage Engineering,
Lightning Protection, Power Electronics & Drives, Power Systems and
Renewable Energy Sources. The Department is accredited by NBA
since 2001.
Dr. Pradipkumar Dixit
Professor & Head
ELECTRICAL & ELECTRONICS
ENGINEERING
ACTIVITIES
PAPER PUBLISHED (LAST 3 YEARS)
National and International Journal/Conference Publications: 123
FUNDED PROJECTS
Design & Development of IVG and HCG Systems at CABS funded by
Centre for Air Borne Systems, Bengaluru. Sanctioned amount:
Rs.44.49 Lakhs.
Development of Prosumer driven Integrated Smart Grid funded by
DST, New Delhi. Consortia Project with IIMA, IITG & FIU (US),
Sanctioned amount: Rs.33.32 Lakhs.
Smart Watering System with the Internet of Things funded by TIH IoT
CHANAKYA Intern, Bombay. Sanctioned amount: Rs 4.8 Lakhs
AWARDS/CITATIONS RECEIVED BY THE DEPARTMENT (3 YEARS)
Dr.Pradipkumar Dixit Awarded Fellow of Institute of Engineers (I)
Awarded Charted Engineer(I)
Five faculty members of the department are elevated to Senior
members from IEEE USA.
STUDENTS’ ACHIEVEMENTS
Keerthana.S VII sem , part of RIT Judo team in 70 kg category , Won
3rd Place in Inter zone competition held at SJCIT, Bangalore, under
Department of physical education and sports, VTU, Belagavi
September, 2019.
Prateek Kumar, Krishna Kant and Sourabh Kumar Secured first place
in golden probe (online E-hackathon) which was by IEEE PES UVCE
during July 2020.
Shwethaa Rajagopalan of IV sem. has successfully completed the
circuit simulation of Narrow Band Reject Filter (notch Filter) under
eSim Circuit Simulation Project, conducted IITB, Mumbai during July
Darshan.R of IV sem Winner, National Level in SWACHTAPAKHWADA
2021” Organised by CMTI, Bengaluru for proposing concept “Waste
Disposal in Railway Compartment”.
Akshat G, Aviral A, Nishnat S, Sripad K, Chalukya B, Abhijit S, Aditya
R and Hruday R have won 1st Position HACKATHAON-22 organized
By HMT in association with IISc, Bangalore April,2022.
PROFESSOR & HOD
Dr. Pradipkumar Dixit – M. Tech., Ph.D, CEngg(I)
PROFESSOR (EMERITUS)
Dr. G.R. Nagabhushana – Ph.D
PROFESSOR
Dr. B.V. Sumangala – ME, Ph.D
ASSOCIATE PROFESSORS
Dr. Chandrashekhar Badachi – M.Tech, Ph.D
Dr. Kodeeswara Kumaran G - M.Tech., Ph.D
Dr. Sridhar S - M.Tech., Ph.D
Dr. S. Dawnee - M.Tech, Ph.D
ASSISTANT PROFESSORS
Sri. Victor George - M.Tech, (Ph.D)
Sri. Vinayaka V Rao - M.Tech, (Ph.D)
Sri. K. Ramakrishna Murthy - M.Tech, (Ph.D)
Smt. Kusumika Krori Dutta - M.Sc (Engg.) (Ph.D)
Smt. Mamatha G M - M.Tech
Dr. Nagaraj C - M.Tech, Ph.D
Dr. S. Poornima - M E, Ph.D
Dr. Binshati Chatterjee - M.Tech, Ph.D
Dr. Hemachandra Godimandala - M.Tech, Ph.D
Dr. Neelamsetti Kiran Kumar - M.Tech, Ph.D
Dr. R. Subha - M.Tech, Ph.D
FACULTY
Keerthana.S VII sem, Judo 3rd Place
INDUSTRIAL COLLABORATIONS
The department has forged strong associations with leading
organizations such as IISc, CPRI, PRDC, ABB, ADA and DRDO on R&D
and consultancy activities.
The department has an MOU with Schneider Electric Company and a
Centre of Excellence has been established in 2010 for Automation
and Process Control, consisting of advanced equipment and facilities.
The department has signed an MOU with National Instruments in
2015 and established NI Labview Academy.
The department has signed an MOU with Axxonet and Ramaiah
Medical College in 2018
The department has signed MOUs with YASKAWA India Pvt. Ltd.,
Bengaluru and LeeP eDrive Pvt. Ltd., Hosur during 2019.
Team EDITHA- Adithya.S , Tomin Joseph, Murali .M (VIII
sem) at the student UAS Design Competition 2018 held at
Maryland, USA
Darshan G.K is selected for Saregamapa by
Zee Kannada, season 17

S.Vatsalya (VIII sem).Winner of
Fashion Show, National Level
Techno cultural Fest at Nitte,2019
Lochan .A (IV sem), Winner in South Zone Inter
university Cricket Tournament, Belagavi, 2019
An industrial visit to BHEL,
Yeshwantapura was organized for
6th sem. Students on 16th Nov. 2019.
An Industrial Visit to LM Wind
power blades Nelamangala,
Bengaluru was organized for 5th
Sem. Students on 9th December 2022.
TEAM STIER - Electric vehicle racing car: Pratik Khot (VI
sem.), Neeraj Yadav (VI sem.) and Shantanu Datar (VI
sem.) Secured overall champion in 5th Formula Green
Event organized by Indian Society of New Era Engineers,
Coimbatore in February 2020.
Hari.R and Parv.M VII Sem , Part of the RIT Quiz team which
won 1st place in 20th VTU Youth Festival , “INSIGNIA”, held
at SDMCE , Dhrawad, October, 2019
Supreeth.R of VII sem, winner National Level “SMART INDIA
HACKATHON-2022”, Organized by Ministry of education, Govt of India.
Darshan R of VII sem, runner up at V-Guard Big-idea and Tech
challenge 2022 and won Rs.50,000 cash prize for Electrical vehicle
battery pack fire suppression system
The Department of Civil Engineering was started as the third
department in the institute with an intake of 60 students in the year
In the year 1984, Structural Engineering was first Post Graduate
program to be started in the institute with an intake of 10 students. The
UG program has been accredited by NBA for four times and recently it
was accredited for three years (from 2021 to 2024). The PG program
(Structural Engineering) was also accredited by NBA for three years
(from 2019 to 2022). After obtaining the autonomous status in the year
2007, the department focused towards providing state of the art
curriculum development, offering electives of the present day need and
techno-innovative projects. These initiatives resulted in enhanced
performance of the students in terms of increase in placement, increase
in the number of students writing competitive examinations and
pursuing higher education in the foreign
universities.
Further, the department of Civil Engineering was recognized as a
research centre in the year 1994 leading to PhD/MSc in Civil Engineering
under State Technological University-VTU. The research centre has 30
research scholars pursuing their PhD degree from this research centre
and 19 research scholars have been awarded PhD degree. The areas of
research include Structural Engineering, Transportation Engineering,
Geo-Technical Engineering, Water resources Engineering and
Environmental Engineering.
The Department has close interaction with a number of reputed
industries, Government agencies through R&amp;D, and consultancy
works. It also has MOU’s with industries, professional bodies and other
institutes in areas related to academics, research and consultancy.
Dr. I. Venugopal
Professor & Head
CIVIL
ENGINEERING
ACTIVITIES
INDUSTRIAL COLLABRATIONS
Bhagirath Construction Company
Manya Associates
Glass Academy
Swifterz Creative Services (LLP)
RESEARCH COLLABRATIONS
Indian Institute of Remote Sensing (IIRS)
NIT Suratkal, Karnataka (For Virtual Lab)
IISc (Research Projects)
NIT Trichy
PROFESSIONAL BODIES (STUDENTS’ CHAPTERS)
Indian Concrete institute (ICI)
Indian Society for Technical Education (ISTE)
Indian Geotechnical Society (IGS)
Royal Society of Civil Engineers (internal)
PROFESSOR & HOD
Dr. I. Venugopal - M.Tech, Ph.D
PROFESSORS
Dr. M. C. Nataraja - M.Tech, Ph.D
Dr. Asha M Nair- M.E, Ph.D
ASSOCIATE PROFESSORS
Dr. R. Mourougane - M.E, Ph.D
Dr. J Sumalatha - M.Tech, Ph.D
Dr. T. Geetha Kumari - M.E, Ph.D
Dr. Jyothi Roopa S. K - M.Tech, Ph.D
Dr. N. Sreelatha - M.Tech Ph.D
Dr. Vivek R Das - M.Tech Ph.D
FACULTY
ASSISTANT PROFESSORS
Dr. B Suguna Rao - M.Tech , Ph.D
Smt. Jyothi M R - M.Tech, (Ph.D)
Sri. R. Manjunath - M.Tech, (Ph.D)
Dr. Anil Kumar R – M.Tech, Ph. D
Sri. Niranjan G Hiremath - M.Tech , (Ph.D)
Dr. Raghavendra H U - MSc , Ph.D
Sri. Basavana Gowda G M - M.E, (Ph.D)
Sri. Santhosh D - M.E, (Ph.D)
Sri. Nambiyanna B - M.Tech, (Ph.D)
Sri. Raje Gowda - M.Tech, (Ph.D)
Sri. Harish M L - M.Tech, (Ph.D)
Sri. Charan Prasad M - M.E (Ph.D)
Smt. Shilpa D N - M.Tech
Smt. Nagashree B - M.Tech, (Ph.D)
Sri. Nandeesh M S - M.Tech, (Ph.D)
Dr. Santhosh L G - M.Tech, Ph.D
Smt. Lakshmi H S - M.Tech, (Ph.D)
Dr. Lakshmikanth S - M S, Ph.D
Dr. Addagada Lavanya – M.Tech, Ph.D
PAPER PUBLISHED (LAST 4 YEARS)
National and International Journal/Conference Publications: 166
FUNDED PROJECTS
“Studies on characterization of construction waste and tyre mixture
for train vibration isolation” funded with Rs 18,30,000, by SERB
(DST).
“Sustainable Utilization of iron ore tailing in smart dynamic concrete
for affordable housing systems”, funded with Rs 8,52,000 by VTU
“Utilization of Crumb Rubber, Arecanut Fiber and Coconut fiber in the
Controlled Low Strength Material for Backfilling the Trenches in
Expansive Soils” funded with Rs 2,20,000 by RIT
“Experimental studies on utilisation of bauxite mine residue in
production of sustainable ecofriendly bricks”, funded with Rs
2,00,000 by KSPCB.
“Study on environmentally friendly concrete- Alkali activated
concrete” & “Studies on production of sustainable green, cement
less concrete by utilizing slag from iron and aluminium industry”
funded with Rs 1,40,000, by KSTA.
ACTIVITIES OF STUDENTS AND FACULTY

Seminar on “Geo-environmental aspects of landfills and
Sustainability” was conducted on 3rd June 2022. Speakers: Prof.
Krishna R Reddy, University of Illinois, Chicago, USA, Prof G R
Dodagoudar, Professor, IIT Madras, & Dr Vishwas Sawant, Professor,
IIT Roorkee.
FDP on “Advance in Highway Technology and Traffic Systems” was
conducted from 7th Feb 2022 to 11th Feb 2022.
Technical talk on “Innovative Testing Devices for Forensic
Investigation in Civil Engineering” was conducted on 18th May 2022.
The survey camp for the students of 6th semester was organized
from 17th - 23rd April 2022.
Memorandum of Understandings

M/s Swifterz Creative Services, Bangalore
CNS Group of Companies, Bangalore
M/s ECOPARADIGM, Bangalore
National Highway Authority of India- South region
Glass Academy
M/s Bhagirathi Construction, Bangalore
M/s Maanaya Associates, Bangalore
SURVEY CAMP 2022
SEMINAR ON 3rd JULY 2022
DEMONSTRATION OF NEW EQUIPMENT
INDUSTRIAL TRAINING
ICI STUDENT CHAPTER - RIT
TECHNICAL TALK ON “MATERIALS OF
CONSTRUCTION FOR REPAIR AND REHABILITATION”
INDUSTRIAL TRAINING ON GROUND PENETRATION
RADAR AND TACHOMETRY
STUDENT CHAPTER ACTIVITIES
PAPER PRESENTED
National/International Journals and Conferences – 80 (for last 3 years)
CONSULTANCY
18 Ongoing consultancy projects for a total of Rs. 33.75Lakhs
The Department of Electronics and Communication was started in
1975 and has grown over the years in terms of stature and
infrastructure. The department has well equipped simulation and
electronic laboratories and is recognized as a research center under
VTU. The department currently offers a B.E program with an intake of
120, and two M.Tech programs, one in Digital Electronics and
Communication, and one in VLSI Design and Embedded Systems, with
intake of 30 and 18 respectively. The department has a Center of
Excellence in Food Technologies sponsored by VGST, Government of
Karnataka. The department is equipped with numerous UG and PG
labs, along with R&D facilities. Past and current research sponsoring
agencies include DST, ISRO, VTU, VGST, AICTE, KSCST and FAER. The
department has research ambitions to develop innovative solutions
and products for various research activities focused towards national
development in various advanced fields such as Signal Processing,
Embedded Systems, Cognitive Sensors and RF Technology, Software
Development and Mobile Technology. The department is also actively
involved in IEEE activities at the student and faculty levels, and is host
to an IEEE Signal Processing Society Student Chapter. The
Department has recently initiated space related technology in the form
of a student club – Stardust RIT.
Dr. Maya V Karki
Professor & Head
ELECTRONICS & COMMUNICATION
ENGINEERING
ACTIVITIES
FUNDED PROJECTS
“Thermal Profiling and Performance Evaluation of Micro Climate
Garment through Embedded Electronic Module” LSRB, DRDO,
Rs.51.34 Lakhs,2022
“Assistive System for Parkinson Patients”, VTU Research grants, Rs
10 Lakhs, 2022
“Development of an AI based embedded system for prediction of
preterm childbirth during pregnancies”, AICTE, Rs.12.19 Lakhs, 2021
“Customized Reconfigurable platform for Image/Video Compression
based on Deep Learning Algorithm for Hyperspectral image”, ISRO,
Rs. 29.3 Lakhs, 2021
“Violence Detection in Drone Surveillance Videos”, ARTPARK(IISc),
Rs. 6.05 Lakhs, 2021
“Modernization of Wireless Communication Lab”, funded with Rs.
7.69 Lakhs, by AICTE MODROBS, 2019
“Deep Neural Networks for Cancer Detection”, funded with Rs. 1.25
Lakhs by NVIDIA GPU Grant, 2017
INDUSTRIAL COLLABORATIONS
MoU with Samsung Research Institute, B
MoU with Photonics India Ventures Private Ltd., Bangalore
MoU with Gallant Electronic Controls
Collaboration with Karnataka Veterinary, Animal and Fisheries
Science University
MoU with Gemini Electro Corporation, AMD India Private Limited and
Leotechsa Robotics Pvt. Ltd., Pune
PROFESSOR & HOD
Dr. Maya V Karki, Ph. D
PROFESSORS
Dr. S. Sethu Selvi, Ph. D
Dr. K. Indira, Ph. D
Dr. T. D. Senthilkumar, Ph. D
ASSOCIATE PROFESSORS
Dr. B. Sujatha, Ph. D
Dr. S. Lakshmi, Ph. D
Dr. V. Anandi, Ph. D
Dr. Raghuram S, Ph. D
Dr. Deepali B Koppad, Ph. D
Dr. C.G. Raghavendra, Ph. D
Dr. Lakshmi Shrinivasan, Ph. D
Dr. Suma K.V, Ph. D
ASSISTANT PROFESSORS
Smt. H. Mallika, M. S (Ph. D)
Dr. M. Nagabhushanam, Ph. D
Sri. Sadashiva V Chakrasali, M. Tech (Ph. D)
Dr. Mamtha Mohan, Ph. D
Sri. V. Nuthan Prasad, M. Tech (Ph. D)
Dr. Reshma Verma, Ph. D
Smt. Flory Francis, M. Tech (Ph. D)
Dr. Punya Prabha V, Ph. D
Smt. Jayashree S, M.S (Ph.D)
Sri. Manjunath C Lakkannavar, M. Tech
Smt. Chitra M, M. Tech (Ph.D)
Smt. Veena G.N, M. Tech
Smt. Pavitha U.S, M. Tech (Ph. D)
Smt. Sara Mohan George, M. Tech (Ph. D)
Dr. Imaculate Rosaline S, Ph. D
Smt. Chethana Gosal S, M. Tech (Ph.D)
Smt. C. Sharmila Suttur, M. Tech (Ph. D)
Dr. Roshan Zameer Ahmed, Ph. D
Dr. Rajendra Prasad P Ph. D
FACULTY
STUDENT ACHIEVEMENTS
Prakhar Awasthi, Pavithraa S, Anaghaa R, Ayush
Kumar Kesari, Ishita Gupta & Keerthana J, has won
1st prize Rs. 1 Lakh in Smart India Hackathon 2022
under the theme, “Smart Automation (Defence
Research and Development Organisation (DRDO),
Ministry of Defence.)”, was held at ACS College of
Engineering, Bangalore on 26th August 2022
HMT IIsc SURGE Hackathon
Shreeshma Hegde with Raksha Mantri (2021) IEEE SPS Chapter Inauguration (2020)
SAE Aero Design Nest – 2018, California, USA
1st prize Rs. 1 Lakh in Smart India Hackathon 2022
2nd Place in Sovereign
Nature Initiative hackathon
held at De Ceuvel,
Amsterdam, Netherlands
Tarrun Datwani and team has won 1st prize Rs. 1
Lakh in Smart India Hackathon 2022 under the
theme, “Agriculture, FoodTech and Rural
Development”, was held at Prin. L.N. Welingkar
Institute of Management Development and
Research (PGDM), Mumbai, Maharashtra August
25th 2022.
Ashish Gurram and team has won 1st prize Rs. 1
Lakh in Smart India Hackathon 2022 under the
theme, “Fitness and Sports”, SCMS School of
Technology and Management, Ernakulam, kerala
August 25th 2022
Three teams different comprising of 7 ECE students
won HMT IIsc SURGE Hackathon of Rs.0.9Lakhs was
held at MSRIT on 22nd April 2022.
Ayush Kesari, Dharini Raghavan, Harshavardhan G,
Ishita Gupta, Pavithra Satchithanatham, Preetham
Reddy won Runner ups (2nd place) Rs. 1.38 Lakhs in
Sovereign Nature Initiative (SNI) hackathon was held
at De Ceuvel, Amsterdam, Netherlands on 4th-6th
February 2022.
Dharini Raghavan and Lekhashree B (V Semester),
awarded the Mitacs Globalink Research Internship
2022
Shreeshma Hegde, I year ECE student received
Raksha Mantri commendation during the Republic
Day camp, for her exemplary performance and
devotion to duty as an NCC cadet. She led the NCC
marching contingent as the All India NCC Rajpath
Parade Commander
Nikhil Agarwal, “Waste Sank”, Winner of Waste Knot
& IEEE RIT Hackathon, 2021
Dharini Raghavan, “Implementation of Residual
Dense Networks for 3D deconvolution”, awarded
Fellowship of Indian Academy of Sciences/ Indian
Institute of Science, 2021
Manor BR (VII Semester) was awarded Mitacs
Globalink Research Internship 2021
Sumith G S, Rishabh Bhatt, Yash Bagri & Shrinivas S
V secured 1st position in NMIT Hacks 2021,
conducted by Dept of CSE, NITTE, Yelahanka
Bangalore, on 20th and 21st March 2021.
Manoj B R, Neeraj Hebbar, Komal G Naik, Jyothindra
Gunjan were placed 2nd in National level Robotics
Competition EYRC organized by IIT Bombay
Manoj B R, Winner, KiCad PCB designing
Competition 2020, organized by Institute of
Engineering and Technology
Instituted in 1978, the Department was the first to offer a course in
Chemical Engineering by a self-financing engineering institution in
Bangalore and the fifth in RIT. Since its inception the department has
moved steadily towards the fulfilment of its mission and is emerging as
a significant player in the academic landscape of Chemical Engineering
education in our country. The Department is certified four times in
succession by the National Board for Accreditation. Over 2000 students
have graduated in 33 batches. The Department offers excellent
infrastructure and students have won various prestigious awards,
international internships and high accolades for innovative projects. The
expertise of the faculty cover a wide range of disciplines and they are
engaged in cutting edge technological research. The average experience
of faculty in the department is more than twenty years and they are
alumni of IISc, IIT and NITs. Enriching insights by eminent dignitaries
from the practicing world are arranged under the activities of IIChE
Student Chapter at the Department. The Department is approved as
Research Centre by VTU for M.Sc. Engg. (By Research) and Ph.D.
degrees. Department has Research projects funding from DRDO, VTU
and DST. The Annual Technical Symposium organized by the
department for students – RASAYAN encompasses a plethora of events.
The Bangalore Regional Centre of the Indian Institute of Chemical
Engineers is functioning from this department for more than two
decades. The country’s most prestigious event in Chemical Engineering
Indian Chemical Engineering Congress - CHEMCON-2011 was
organized here. The event invited the top chemical engineers of the
nation to our Institute and hosted a joint session with Canadian
Universities in the area of Energy and Environment.
Dr. Archna
Professor & Head
CHEMICAL
ENGINEERING
ACTIVITIES
PAPER PRESENTED (In last 10 years)
National/International journals – 130
National/International Conferences - 90
FUNDED PROJECTS
Development of Energy Efficient Prototype Device for
Electrochemical Synthesis of Ammonia: Investigating Pathways to
Enhance Ammonia Production – Funded by SERB, DST. (Rs.43.9
lakhs).
Development of fast curing sealant composition and materials
Funded by Boeing. ( Rs.16.7 lakhs).
Design and Development of Carbon dot (C-dot) Based Nanosensors:
Detection of Environmentally and Biologically Relevant Metal Ions –
Funded by VTU (Rs. 7.0 lakhs)
Novel Enzymatic Route for Valorisation of Biodiesel Derived Glycerol
to Fuel Additives – Funded by VGST (Rs. 5 Lakh).
Nano Engineered Submerged Ceramic Membrane Bioreactor for
Waste Water Purification - Funded by DST. (Rs.24.4 lakhs).
Studies on Epoxy Based Nano Polymer Composites with Enhanced
Mechanical, Electrical, Chemical and Optical Properties - Funded by
DST. ( Rs.24.4 lakhs).
Enzymatic Conversion of Bio Diesel Derived Glycerol to Acetins -
Funded by Institution of Engineers. (Rs. 1,5 Lakh)
Utilization of Vermiculate and Anatase for Treating Effluents
Containing Complex Pollutants- Funded by AICTE –Completed year
2006.(Rs. 9 Lakhs).
PROFESSOR & HOD
Dr. Archna, M.E, Ph.D.
PROFESSOR (EMERITUS)
Dr. Rammohan. T.R, Retd. Chief Scientist CSIR - 4PI
PROFESSOR
Dr. G.M. Madhu, ME., Ph.D
ASSOCIATE PROFESSORS
Dr. Brijesh, M.Tech., Ph.D
Dr. Rajeswari M Kulkarni, M.Tech., Ph.D
ASSISTANT PROFESSORS
Dr. Ramasivakiran Reddy, M.Tech., Ph.D
Dr. Sravanthi Veluturla, M.Tech., Ph.D
Dr. Koteswara Rao Jammula, M.Tech., Ph.D
Sri. Sagar J S, M.Tech (Ph.D)
Dr. Ravi Sankannavar, M.Tech, Ph.D
Dr. Ranjeet Kumar Mishra, M.Tech, Ph.D
Dr. D Jaya Prasanna Kumar, M.Tech, Ph.D
FACULTY
STUDENTS ACHIEVEMENTS
39 funded projects awarded to students of UG
program by Karnataka State Council of Science
and Technology, Indian Institute of Chemical
Engineers, BRC and MSRITAA from 2012-2021.
Many Students are Awarded with National &
International Internship from reputed Industries
and Institutes.
► Shriya Rambhia, selected to 2022 MITAC’S
Research Fellowship at Canada for a Research
Project at University of British Columbia,
Vancouver, Canada.
► Saddam Shariff worked from June to August 2019
as a Summer Research Fellowship Program at
Indian Institute of Science, jointly sponsored by IASc
& INSA and NASI.
► Adam R Samuel was awarded internship at
Oklahoma State University during 24th June 2019
to 09th August 2019.
► Dheer A Rambhia worked as a Visiting Research
Student (VRS) at the University of Saskatchewan,
Canada under the guidance of Dr. Ajay Dalai.
► H S Meghana Jois and Apurv Dwivedi is got
Summer Research Fellowship Programme 2018 in
Indian Academy of Science.
► Rupa Ragavan winner of the Avery Dennison
Foundation (INVENT) Scholarship programme
2018-19 ($1,300).
► Jayanth Reddy, selected to 2016 MITAC’S Research
Fellowship at Canada for a Research Project at
Lakehead University, Thunder Bay, Ontario Canada.
► Y Surya Mitra, internship in Arizona State
University from 15th May 2015 to August 3rd 2015.
► Ananya Mohanty completed Go Green in the City
2015-the global business case challenge at Paris.
► Vandana Reddy winner of the Avery Dennison
Foundation (INVENT) Scholarship program 2015-16
($1,300).
► Neelam R Khot, Summer Internship program in
Kashiwa, University of Tokyo.
► Gorthi Apurupa, Summer Internship program in
Kashiwa, University of Tokyo.
► Sarayu R, UG Research in McGill University, Canada
► Jeevitha, Internship VME Process, Inc., Kuala
Lumpur, Malaysia.
► Gaurav Das, vocational internship at the Laser
Zentrum Hannover e.V. within the framework of the
DAAD –IAESTE’ program.
Seminar on “Climate Change and Role of Engineers” by Dr. Bipin
V Vora, Adjunct Professor, Biological and Chemical Engineering,
Illinois Institute of Technology, Chicago VTU Fest - 2022

R & D Laboratory R & D Laboratory
R & D Laboratory CRE Laboratory
Momentum Transfer Lab Momentum Transfer Lab
Life cycle symposium - 2022
The department was established in the year 1979 as Industrial &
Production Engineering and renamed as Industrial Engineering &
Management in the year 1992, with an intake of 60 students. It has
consistently bagged university ranks in Bangalore University & VTU. It
has set a unique record of achieving 1st rank eleven times. M.Tech
program in Industrial Engineering commenced in the year 2012. The
department has well modernized laboratories like Industrial & Quality
Engineering lab, Computer Lab and Mechanical Measurement &
Metrology lab to name a few. The department is having highly qualified,
motivated and result oriented faculty members. All faculties are
actively involved in research and technical paper publications in
reputed journals & conferences. The department was accredited by
the NBA in 2001, 2004, 2010 & reaccredited in year 2015 and 2018.
The department has successfully conducted faculty development
programs, seminars & workshops for academicians as well as industry
personnel, students and technical staff. Several funded research
projects are executed which are sponsored by UGC, AICTE, DST, VTU
and VGST.
Dr. G.S. Prakash
Professor & Head
INDUSTRIAL ENGINEERING &
MANAGEMENT
ACTIVITIES
PAPER PRESENTED:
International Journals – 162
National Journals – 22
International Conferences – 114
National Conferences – 71
WORKSHOPS ORGANIZED:
International Conference – 05
National Conference – 02
Faculty Development Programme – 17
National Workshop – 09
National Seminar – 02
Management Development Programme – 01
Staff Development Programme – 04
RESEARCH AND CONSULTANCY
The Department has well equipped R&amp;D lab. Research scholars
numbering 14 are carrying out their research work for Ph.D degree.
PROFESSOR & COE
Dr. G.S. Prakash – M.Tech, Ph.D
PRINCIPAL & PROFESSOR
Dr. N.V.R. Naidu, M.Tech, Ph.D
ASSOCIATE PROFESSORS
Dr. M. Shilpa – M.E, Ph.D
Dr. R. Shobha – M.Tech, Ph.D
Dr. M. Rajesh – M.Sc (Engg)., Ph.D
ASSISTANT PROFESSORS
Dr. Sridhar B S - M.Tech, Ph.D
Dr. M.R. Shivakumar – M.E, Ph.D
Dr. Hemavathy S - M.Tech, Ph.D
Sri. Sudheer Kulkarni – M.Tech., (Ph.D)
Smt. Hamritha. S – M.Tech
Dr. Niranjan C A – M.Tech, Ph.D
Dr. Sidhartha Kar – M.Tech, Ph.D
FACULTY
ASSOCIATION & MOU’S
Industry Institute Interaction – Memorandum is signed
with Cimtrix Systems Pvt., Ltd., Stayra Mobility Pvt
Ltd., Bengaluru. Also has collaborated with Columbia
/ Stanford University – USA and National University of
Singapore, Business Excellence Inc., USA., 2M
Engineers, Coco Eco Innovations Inc. & Kenna Metals,
Bengaluru.
INDEMAN SOCIETY
The society of Industrial Engineering and
Management, “INDEMAN”- a student body was
established in the year 1996. It was formed with the
intention of bringing the hidden talents of the
students to expose them to latest technology
developments. The society organizes regular
industrial visits, guest lectures, technical events like
quiz, paper presentation competition etc.
Computer Lab
Nurturing today’s learners to
become tomorrow’s leaders
to face global challenges
ATAL SPONSORED ONLINE
FACULTY DEVELOPMENT PROGRAM
ON
13th - 17th Sep 2021
Organized by
Dept. of Industrial Engineering & Management
in association with IQAC
M S Ramaiah Institute of Technology
Bengaluru
Calibration Lab

Calibration Lab Workstudy Lab
Measurements and Metrology Lab
The Department of Computer Science and Engineering (CSE)
was established in the year 1984 to meet the needs of the
emerging IT industry and research. The department has
well-qualified, experienced, and dedicated teaching and
non-teaching staff. In the year 1998, the department started
M.Tech in Computer Science and Engineering and in 2014 the
department started M.Tech in Computer Networkand
Engineering. The curriculum for both UG and PG at the
department of CSE provides both breadth and depth across the
range of engineering and Computer Science topics with industry
standards. The department conducts vocational courses and
proficiency courses during the summer term on the various
subjects pertaining to Computer Science, both for our students
and students of other colleges in the state. These courses are
conducted by the faculty of the department. The department
has state-of-the-art laboratories like SAP, and IBM Centre of
Excellence. The department was accredited by the Nation
Board of Accreditation (NBA) for 6 years from July 2022 to
The department of CSE has a greater than 95%
placement track record every year. The students of the CSE
department have bagged an average package of 9 lakhs per
annum in the academic year 2021 - 2022 with highest package
of 48 lakhs.
Dr. Annapurna P Patil
Fellow IETE, Senior Member IEEE,
Member ACM, LMCSI, LMISTE
Professor & Head
COMPUTER SCIENCE AND
ENGINEERING
ACTIVITIES
PAPER PRESENTED
Publications in Journals and Conference Proceedings by faculty and
students in 2022 ~> 110 articles.
FUNDED PROJECTS AND CONSULTANCY
VTU Competitive Research Grant ~ 2 Lakhs
VGST ~ 3 Lakhs
CySeck ~ 12 Lakhs
VGST CISEE ~ 30 lakhs
AWARDS
CMI Level 5 Award in Leadership and Management.
Outstanding Medium Student Branch Counselor, IEEE Bangalore
Section.
“Protsahan award”, for contributions through publications, IEEE
Faculty Mentor Award by Samsung and IEEE
NPTEL award for Best SPOC
STUDENT ACHIEVEMENTS
Winners of CODEFURY4.0 IEEE UVCE Computer Society (Rs. 1,00,000/-)
Winner of VNRVJIET Hyderabad VJ Hackathon
Smart India Hackathon – Winners (2 Teams won 1 st prize of 1 Lakh)
INDUSTRY COLLABORATIONS
IBM and SAP
Cisco, MicroFocus, Uipath
Project Implementation-Samsung, UNISYS, SARCII
MOU- Hewlett Packard Enterprises, Simplify3X,
Garuda Aerospace Pvt Ltd
PROFESSOR & HOD
Dr. Annapurna P Patil – Ph.D
PROFESSOR (EMERITUS)
Prof. Naghabhushan A M – M.Tech
PROFESSORS
Dr. Monica R Mundada – Ph.D
Dr. Jayalakshmi D S – Ph.D
SENIOR LECTURER
Smt. Mamatha A - M.Tech
Smt. Pallavi N - M.Tech
ASSOCIATE PROFESSORS
Dr. Shilpa S Chaudhari – Ph.D
Dr. T N R Kumar – Ph.D
Dr. S Rajarajeswari – Ph.D
Dr. Sangeetha J – Ph.D
Dr. A Parkavi – Ph.D
Dr. J Geetha – Ph.D
Dr. Dayanand R B, – Ph.D
Dr. Sangeetha V - Ph.D
ASSISTANT PROFESSORS
Smt. Veena G S - M.Tech, (Ph.D.)
Sri. Mallegowda M - M.Tech, (Ph.D.)
Smt. Chandrika Prasad - M.Tech, (Ph.D.)
Sri. Pradeep Kumar D - M.Tech, (Ph.D.)
Dr. Ganeshayya I Shidaganti - M.Tech, Ph.D
Smt. Darshana A Naik - M.Tech, (Ph.D.)
Ms. Jamuna S Murthy - M.Tech (Ph.D.)
Smt. Sushma B - M.Tech (Ph.D.)
Smt. Nandini S B - M.Tech (Ph.D.)
Smt. Chetan D S - M.Tech (Ph.D.)
Smt. Soumya C S - M.Tech (Ph.D.)
Smt. Manjula L - M.Tech (Ph.D.)
Smt. Akshata S Bhayyar - M.Tech (Ph.D.)
Sir. Vishwachetan D - M.Tech (Ph.D.)
Smt. Akshatha Kamath - M.Tech
FACULTY
The Dawn Jaeger Tenacity
IEEE Stem Activities 2022 Award 2022
SIH Winners- 2 teams won 1st prize of 1 Lakh each in August, 2022
Interaction with Delegates From Japan,
Suzuki India Digital, May 2022
Talk on Recommender Systems for Cyber Infrastructure Management
and Domain Knowledge Discovery by Dr. Prasad Calyam, University of
Missouri, Columbia, June 2022

Hewlett Packard Enterprises, MoU, June 2022 Sociallygood.com – Alumni/ Star Evolute Awardee August, 2021
PAPER PRESENTED
National / International Journal & conference – 112, most of the works
are published in quality peer reviewed journals.
PATENT GRANT/FILED: 6
The Department was established in the year 1992 as Instrumentation
Technology and was renamed as Electronics and Instrumentation
Engineering (EIE) in the year 2014 by VTU. The department offers UG
course which is recognized by AICTE and accredited by NBA, four times
(up to 2022). The department is recognized as a Research Centre by
VTU, Belagavi and offers Ph.D and MSc.(Engg.) by research programs.
All the faculty members are doctorates and are actively engaged in
R&D activities. The department is focused on empowering the
students with technical knowledge and practical skills in the areas of
Instrumentation Technology and Industrial Automation System in line
with Industry 4.0. The department is equipped with modern
laboratories including Allen Bradley PLCs, SCADA from Schneider
Electric, Ocean Optics Optical Spectrometer and research software
such as Neuroshell predictor and classifier to name a few.
The course and curriculum is basically multi-disciplinary in nature and
revolves around electronics, computers and embedded systems. The
focus is on the design and control of automated systems with Industry
4.0 standards. The emphasis is on hands on training with PLCs,
SCADA, Robotics, Automation and IoT. With wide exposure the
students are well equipped to get into core industries and/or higher
studies in India and abroad. Our Board of Studies involves experts from
IISc, HAL, ISRO, DRDO and our alumni giving inputs to the curriculum
design and modifications. The department has an MoU with Mitsubishi
Electric India Private Limited and SM Electronics and has several
consultancy projects and linkages with industries. The department
also has an active membership in International Society of Automation
(ISA) and the Society of Instrumentation Professionals (ISOI-IISc).
Students are active in both extra-curricular and co-curricular activities.
They have published papers in conference/journals, applied/awarded
patents, participated and won prizes in many national events as
Mitsubishi cup, Avery Dennison foundation innovation event. The
students build innovative final year projects and have won prizes every
year. Selected student projects have received KSCST and Alumni
funding. Students are also in Skating, cricket, swimming, basketball
etc at both state and national level.
ELECTRONICS & INSTRUMENTATION
ENGINEERING
ACTIVITIES
AWARDS/CITATIONS RECEIVED BY THE DEPARTMENT (5 YEARS)
Dr. M K Pushpa - Awarded Fellow of Institute of
Engineers
Dr. H S Niranjana Murthy - Awarded Fellow of IETE
Student Chapter: Department has organized several
guest Lectures, industry visits, and activities under
Innovation and Training Club–RIT in association with
Instrument Society of India, ISOI - Student Chapter.
ASSOCIATE PROFESSOR & HOD
Dr. M K Pushpa, M.Tech., Ph.D, FIE
PROFESSOR
Dr. M Jyothirmayi, M.E, Ph.D
ASSOCIATE PROFESSORS
Dr. G Shiva Prakash, M.Tech. Ph.D
Dr. H S Niranjana Murthy, Ph.D, FIETE
ASSISTANT PROFESSORS
Dr. M D Nandeesh, M.Tech. Ph.D
Dr. Elavaar Kuzhali S, M.S. Ph.D
Dr. J V Alamelu, M.S. Ph.D
Dr. A Saravanan, Ph.D
Dr. K M Vanitha, M.Tech. Ph.D
Dr. Christina Grace Charlet, Ph.D
Dr. Nishi Shahnaj Haider, PhD
INDUSTRIAL COLLABORATIONS
Department has an active MOU with S M Electronics
and Renesas synergy boards of worth INR 3,75,000
has been contributed. As part of MoU, hands on FDP
on Renesas synergy has been organized.
FUNDED AND CONSULTANCY PROJECTS
Funded project titled “Estimation of Post-partum
blood loss using optical fiber sensor and its
correlation to shock index” sanctioned for funding
amount of Rs. 18.22 Lakhs by DBT, India. Principal
Investigator is Dr. Christina Grace.
Industry Consultancy work worth Rs.6,84,000/- has
been sanctioned. The faculty members
Dr.M.Jyothirmayi, Dr. G Shivaprakash, Dr. H S
Niranjana Murthy, Dr.M.D.Nandeesh, and Dr. A
Saravanan are involved.
STUDENTS ACHIEVEMENTS (NATIONAL &
INTERNATIONAL LEVEL)
Students of EIE Department are participating in
several Co-curricular and Extra curricular events and
won prizes at college, state, national and international
level events.
FACULTY
Dr. M K Pushpa
Associate Professor & Head
Prithvi Jagadeshan, Rafay umar, Poojitha, Parasumaram, Sanshrit
Bakshi, Anwesha, Sahil Roy final year project titled, ‘Smart bed for
ulcer prevention and remote monitoring’, has been sanctioned for Rs.
4,500 by KSCST, Karnataka.
KSCST–SPP-student fund of Rs.8,000 was sanctioned for students
for their project “Detection of parkinsons disease with analysis of
motor skills”
Alumni (MSRIT) fund of Rs 10,000 was sanctioned for students
Sidarth M, Vijay B, Ritik, Raju for their project “Anxiety detection using
electrodermal activity” guided by Dr.M.Jyothirmayi.
Deepak Joshi received prestigious Dawn Jaeger Tenacity award
2022 for exhibiting autonomous unmanned air system at SAUS
competition, USA.
Bharath Gowda, received cash prize of Rs.12,000 for the project
showcased on Practical aspects of computational intelligence for the
project titled “Deep learning based recycle waste classification and
comparison between different Machine Learning Algorithms”
conducted by IEEE-CIS vocational course by Mind Tree.
Ketan Anand was awarded Best outgoing student of the Institute and
has completed the requirements of B.E.Honors as per VTU
regulations.
Vedya Janardhanan, was an adjudicator in ‘smart debates’ 2020
organized by smart club in collaboration with Youth Initiative Nepal
and Debate Network Nepal.
Madhuvanthi, student of EIE received USD 1300 as scholarship from
Avery Dennison foundation for the year 2021.
Muskan Walia of I sem, selected as a Women Techmakers
Engineering Fellow, formerly known as WE TalentSprint
Scholaramong the top 250 participants consisting of over 55,000+
applicants across India. Recieved 100% scholarship.
Arundathi Deshpande, won Gold medals, Silver medals and bronze
medals in Swimming state level and VTU competitions.
Basketball state level-won by RIT team.
Ghanashama Prabhu, Won at state level and bronze medal in
1000Mts at National Games, Gujarat, India.
The Department of Information Science and Engineering (ISE) was
established in the year 1992 with an objective of producing high quality
professionals to meet the demands of the emerging field of
Information Technology. Department offers Bachelor’s program in
Information Science and Engineering (B. E), Master’s program in
Software Engineering (MTech) and Doctoral program (Ph.D.). The
Department of Information Science and Engineering, is a progressive
department that has made significant contributions to Academics,
Research and Innovation. The Department UG program as been
accredited by National Board of Accreditation (NBA) for 6 years
from 2022 to 2028. The department has highly qualified and
competent faculty members committed to innovative teaching
learning and quality research. Department has 8 well-equipped state
of the art laboratories which meets the requirement of curriculum,
innovation and research. Collaboration with industries such as Apple,
Unisys, Mindtree, Intel, Google, SECO, IBM, NVIDIA etc, has a significant
impact on the curriculum, computing infrastructure, teaching &
learning and research. The curriculum is centred around Data Science,
Artificial Intelligence, IOT, Cloud & Distributed Computing, System
Programming, Computer Security and Software development.
Curriculum and the teaching learning process ensure that the students
demonstrate technical competence, ethical reasoning, creativity in
identification & formulation of the problems and develop solutions by
using appropriate tools & techniques. Department has established
technical clubs/ professional student chapters to provide collaborative
learning platform for the students. Echo system has been built to
initiate start-ups/Innovation at the department level along with the
mentorship program. The activities of the Department led to high
profile placements, motivation to become an entrepreneur, and
encouragement for higher learning.
INFORMATION SCIENCE AND
ENGINEERING
Executed 10+ Funded Research and Consultancy Projects from
ISRO, ARTPARK (IISc), IBM, UGC, AICTE, VGST, VTU and other
Industries amounting to Rs. 1 Crore till date.
200 Research publications in reputed journals/ conferences/
edited books indexed in SCI/WoS/ SCOPUS/Google Scholar from
2018
2500+ Citations
65 publications with minimum 10 citations
8 filed/published Indian Patents from 2018
Use of Artificial Intelligence / Expert Systems/Machine Learning in
Mission Operations – ISRO
Sign Language Translator for vocally challenged using Sensor
based hand gesture Recognition(HGR)- IISc
Anomaly Detection Using Machine Intelligence Techniques For
Mobile Computing Networks - AICTE
Understanding the facial phlebotomy and developing
Computer-Aided Diagnostic tool for screening of common
congenital malformation - ICMR
PROFESSOR & HOD
Dr. Sanjay H A - M.Tech, Ph.D (IISc)
PROFESSORS
Dr. Vijay Kumar B P - M.Tech(IITR), Ph.D(IISc)
Dr. Yogish H K - M.Tech., Ph.D
ASSOCIATE PROFESSORS
Dr. Megha P Arakeri - M.Tech, Ph.D, SMIEEE,
Fellow IETE
Dr. Krishna Raj P M - M.Sc Engg, Ph.D
Dr. Sumana M - M.Tech Ph.D
Sri. Shashidhara H S - M.Tech (Ph.D)
Dr. Geetha V - M.Tech, Ph.D
FACULTY
ASSISTANT PROFESSORS
Smt. Savita K Shetty M.Tech (Ph.D)
Dr. Lincy Meera Mathews M.Tech, Ph.D
Ms. Rajeshwari S B M.Tech (Ph.D)
Smt. Prathima M N BE, M.E
Dr. Pushpalatha M N M.Tech, Ph.D
Sri. Prashanth K M M.Sc. Engg.
Sri. Jagadeesh Sai D M.Tech (Ph.D)
Dr. S R Mani Sekhar M.Tech, Ph.D
Sri. Suresh Kumar K R M.Tech (Ph.D)
Smt. Shruthi G M.Tech (Ph.D)
Smt. Evangeline D M.E
Smt. Vathsala.M K M.Tech (Ph.D)
Smt. Ashwitha A ME, (Ph.D)
Sri. Karthik V M.Tech (Ph.D)
Dr. M Sinthuja ME, Ph.D
Dr. P Anita M.Tech, Ph.D
Sri. Mushtaq Ahmed D M M.Tech (Ph.D)
Smt. Kusuma S M.Tech (Ph.D)
Dr. Sanjay H A
Professor & Head
Design and Development of Head Mounted
Assistive Device for the Blind – IEEE.
Development of prototype for detecting snakes in
farm land using Edge computing algorithms –
VGST.
Developing Teaching Learning Apps for differently
abled students - Saroj R Dsad Trust, New Delhi.
RESEARCH STATISTICS

RESEARCH PROJECTS

INTERNATIONAL AWARDS

UNESCO India Africa Hackathon-2022
RAPID – A global Open API Challenge Virtual Event -2021
ASEAN India Hackathon-2021
Microsoft Imagine Cup –2020
Hedera Hashgraph-2018
NATIONAL AWARDS

Smart India Hackathon – 2022/2020/19/18
Matlab Hackathon – 2022
Code Fury 3.0 - 2020/19
Solve for India Hack -2021
Technical Festival, IIT-Goa – 2021
NEC Travel Hack – 2019
Global gaming hackathon– 2019
Cognizant Master code – 2019
Hackman 5.0 -2022
AI Hackothon.-2022
HUL BFS Hackathon- 2019
GitHub Hackathon- 2018
ISKCON Hackathon– 2019
Manipal Hackathon– 2019
Code Hackathon, IBM– 2019
ACTIVITIES WITH INDUSTRIES

Campus Research Projects
Monthly Talks
Faculty interaction Program
Industry Tour
Career Readiness Program
Students Training Program
Consultancy
Curriculum Design
Partial delivery of Course
Internship/ Placements
Workshop
STUDENT CENTRIC ACTIVITIES

Long/Short term Internship
Immersion Program
Research Paper Publications
Student Driven Technical Clubs
e-Learning through Impartus
Eco-system for inter-disciplinary projects
Outcome Based Teaching Learning Process
Counselling on career choice
“Honors” degree
INDUSTRY COLLABORATION

PAPER PRESENTED
Paper Presented: National and International Journals & Conferences:
220
The department of Electronics & Telecommunication Engineering was
established in 1996 to address the increasing demand for professionals
with expertise in communication and networking technology in India. The
department has state of the art laboratories, equipment’s, resources and
committed faculty having best of the academic and industry recognition.
The department started a M.Tech program in Digital Communication in the
year 2004. The department started a Research Centre in the year 2012 and
currently has 12 Research Scholars carrying out their Research.
Department has collaborations with some of the leading industries like
Ansys, Rohde & Schwarz, JV Micronics, Nokia, Samsung, ABB and with
leading national and international universities like Bradley University,
Stanford University, IIT-M, enabling the department to focus on R&D, and
thus providing new avenues for PG/UG students for placement and higher
studies. Department is accredited by the National Board of Accreditation
under AICTE. There are 5 Funded Research projects (Industry and
Government) ongoing in the department involving students to carry out
innovative projects. Many professional activities are organized regularly to
the students under various professional societies like IEEE Sensors
Council, IEEE Communication Society, IEEE Antenna and Propagation
Society, IEEE MTTs and IETE Bangalore.
The department of ETE has established the Centre of Excellence – Center
for Antennas and Radio Frequency Systems jointly with ECE department on
24 th March 2021 to engage in advanced research leading to innovation on
the areas of Antennas & RF Systems. The CARFS has the state of art
facilities to collaborate with Researchers in other institutes across the
state.
Dr. B.K. Sujatha
Professor & Head
ELECTRONICS & TELECOMMUNICATION
ENGINEERING
ACTIVITIES
FUNDED PROJECT
Department of Electronics and Telecommunication Engineering has
received various funded projects from reputed Organizations like DST,
VGST K-FIST, AICTE, ABB, BOEING, KSCST, NPMASS, Stanford
University and so on.., amounting to more than 2 Crores. The projects
received are in the domain of Internet of Things, Wearable devices,
Wireless Networks, Antenna Design, MEMS etc.
ONGOING
Project titled “Design, Development and Prototyping of High Accuracy NavIC
Receiver for Rapid Topographic Survey” sponsored by DST – Device
Development Programme Rs.53 lakhs. November 2021 under the guidance
of Dr Shobha K R, Principal Investigator, Dr Parimala P, CO-PI, Nisha SL,
CO-PI.
Project titled “Enabling Functional Mobility through Advanced Gait Analysis
and Virtual Reality”, under BIRAC- Promoting Academic Research
Conversion to Enterprise (PACE) scheme during Jan 2021for Rs. 21.4 lakhs
under the guidance of Principal Investigator Dr.Viswanath Talasila
Project titled “Centre of Learning for setting up Microwave and Antenna Lab”
sponsored by VGST K-FIST Level 2 under the guidance of Dr. B.K. Sujatha,
Principal Investigator and Co-PI Dr. Swetha Amit.
Project titled “Development of a Prosumer Driven Integrated SMART Grid”
sponsored by DST under the guidance of Dr.Viswanath Talasila.
STUDENTS ACHIEVEMENTS
Mayur Gowda was awarded Best Outgoing Student
for the batch 2018-2022.
Vikash Kumar, Kumar Vaibhav and Vibha Narayan
were awarded first prize for Final year UG project
2022 by RIT for the project Titled “Virtual Reality
environment development for physical
rehabilitation” under the guidance of Dr. Viswanath
Talasila, Professor
Abhishek J, Purneeth Banerjee and Kushal CP were
awarded Second Prize for Final year UG project
2022 by RIT for the project Titled “IOT Based
Hydroponics System” under the guidance of Dr.
Arvind Kumar G, Assistant Professor.
Ms. Vanishree R Nawati was awarded the best PG
project for the project titled, “An electrically small,
probe – fed Parasitically coupled antenna for breast
Cancer detection”, guided by Dr. B. K. Sujatha and
Dr. Karthikeya G. S
FACULTY ACHIEVEMENTS
Dr. B K Sujatha, Head, and Professor, Dept of
Electronics and Telecommunication Engineering,
Ramaiah Institute of Technology have received the
Distinguished Woman Researcher in Electronics
Engineering Award in the 7th Venus International
Women Awards (VIWA 2022).
Dr. Viswanath Talasila, Professor, Dept of
Electronics & Telecommunication Engineering,
Ramaiah Institute of Technology has delivered a
video lecture on "Control Engineering" for NPTEL.
This series of video lectures are been extensively
utilized by most academicians students, research
scholars, and Industries working in the domain of
Control Systems.
Dr. K R Shoba, Associate Professor, Dept of
Electronics & Telecommunication Engineering,
Ramaiah Institute of Technology has received the
Lifetime Achievement Award from Novel Research
Academy.
PROFESSOR & HOD
Dr. B. K. Sujatha, M.E., Ph.D
PROFESSOR
Dr. Viswanath Talasila, PhD, Post Doc
ASSOCIATE PROFESSORS
Dr. Shobha K. R., M.E., Ph.D
Dr. Satish Tunga, M.E., Ph.D
Dr. S. G. Shivaprasad Yadav, M.Tech, Ph. D
ASSISTANT PROFESSORS
Dr. Parimala P, M. E., Ph. D
Dr. Venu K.N, M.Tech, Ph. D
Dr. Ramya H. R. , M.Tech, Ph. D
Smt. Nisha S.L., M.Tech, (Ph. D)
Smt. Kusuma S. M., M.Tech, (Ph. D)
Dr. Arvind Kumar G, M.Tech, Ph. D
Mrs. Akshata S Kori, M.Tech, (Ph. D)
FACULTY
Ms. Vanishree R Nawati was awarded the best PG project
Industry visit to BEL
Microwave Lab
Anechoic Chamber- Centre for Antennas and Radio Frequency Systems
Analog Circuit Design Lab Communication Lab

FACULTY PUBLICATION
Number of National and International Journals (Jan-Dec’2021): 24
Number of National and International Conferences (Jan-Dec’2021): 07
The Medical Electronics Engineering department at M. S. Ramaiah
Institute of Technology (MSRIT), Bangalore was started in the year
The department offers 4-year full time U. G. Degree - B. E in
Medical Electronics Engineering, affiliated to VTU, Belagavi,
recognized by Government of Karnataka, approved by AICTE, New
Delhi and accredited by NBA. In the year 2012, the department was
recognized as research centre by VTU and is actively involved in R & D
activities in the area of Biomedical Signal Processing, Image
Processing and Instrumentation.
The department has 10 experienced Faculty members and is located at
Lecture Hall Complex of MSRIT Campus. It is uniquely connected to
MSR Medical College, Teaching and Memorial Hospitals as well.
Funded projects under the department include IEEE Foundation, DBT,
DST, IGCAR and VGST.
These projects focus on the advances that improve human health and
health care at all levels through application of the principles and
problem-solving techniques of engineering to biology and medicine.
The department has significant publications to its credit.
The current curriculum is reviewed by experts from GE Healthcare,
Samsung Research, Forus Healthcare, Philips and M.S.Ramaiah
Medical College & Hospital. The department conducts workshops,
various skill based training programs and industry visits for giving the
students an exposure to the latest developments in the industry. This
also includes a mandatory 4-week internship at industry or hospital
between III and IV year.
Dr. C.K. Narayanappa
Associate Professor & Head
MEDICAL ELECTRONICS
ENGINEERING
ACTIVITIES
RESEARCH & DEVELOPMENT
The Department’s R & D focuses on three areas such
as system design, system software and system
interface. Faculty and students of the department
have 45 publications in peer-reviewed international
journals and conferences in the last two years. The
total number of Ph.Ds awarded from the department
research centre is 05 and M.Sc.(Engg.,) by Research
is 01.
STUDENT ACHIEVEMENTS
The students are encouraged to participate in co-curricular and extra-curricular
activities at the department level, institute level and beyond. There is active participation
by the students for various competitive technical and sporting events.
Co-curricular Activities:
Sheik Mohammed Maaz, USN:1MS20MD027, “Agriculture in New Era”, ICRITCSA-2022
Arshya Loomba, USN:1MS19ML011, “Assessment of the effect of meditation in
healthy human beings with the aid of auditory intensity discrimination aided
psychophysics”, ICRITCSA 2022
Sheik Mohammad Maaz, USN:1MS20MD027, has won first prize in Hackathon on
Innovation Project “Surge India” 22nd Apr 2022 conducted at RIT, Bangalore
Sheik Mohammad Maaz, USN: 1MS20MD027, has won startup Fellowship – Amount of
$200,000 to build technical and marketing credits at International Level.
Extra-curricular Activities:
Amitha A, 1MS19ML007, has won first prize in event “Cooking without Fire” in RIT
campus
Gonugunta Shreya, 1MS19ML020, has secured second place in classical vocal at VTU
Festival 2022
Shashank Gautam, 1MS21MD036, has secured third place in group song (INDIAN) at
VTU Festival 2022
V P Aishwarya, 1MS20MD037, has won Second Place in Choreography in Haicyon
2022 at State level, conducted on 16-18, June 2022
V P Aishwarya, 1MS20MD037, INTERACT – 2022, Western Group dance, Winner
conducted by University level, GAT, Bangalore
V P Aishwarya, 1MS20MD037, third prize in Western Group dance at State level,
conducted in Presidency University, Bangalore
ASSOCIATE PROFESSORS
Dr. Prabha Ravi - M.Sc., Ph.D.,
Dr. Uma Arun - M.S., Ph.D.,
ASSISTANT PROFESSORS
Dr. S J Mahendra - M.Tech. Ph.D.,
Dr. Basavaraj Hiremath - M.Tech., Ph.D.,
Dr. Tejaswini S - M.Tech., Ph.D.,
Dr. Sweeti - M.Tech., Ph.D.,
Dr. Y S Sumathy- M.Tech., Ph.D.,
Dr. Lakshminarayana M - M.Tech., Ph.D.,
FACULTY
ASSOCIATE PROFESSOR & HOD
Dr. C K Narayanappa - M.Tech., Ph.D.,
PROFESSOR
Dr. N Sriraam - M.Tech., Ph.D.,
VISITING FACULTY
Dr. Anupama - MBBS, Ph.D
Dr. Zaina P - MBBS, Ph.D
Diagnostic & Therapeutic Laboratory
Medical Electronics Laboratory
Medical Electronics Engineering students won
Kabaddi women at Intra collegiate level
Medical Instrumentation Laboratory
Medical Software Laboratory
Project -R & D Laboratory
One Week FDP On “Artificial Intelligence in Medical Imaging -
Fundamentals and Innovative Applications” from 19.09.2022-24.09.2022

Research Publications (June 2021 – October 2022)
Publications in SCI & WoS indexed journals–53
The Department of Biotechnology established in 2002 offers a four
year B.E. Biotechnology Program with an intake of 60 students and a
two-year M.Tech. Biotechnology Program with an intake of 18
students. The UG and PG curriculum emphasizes on
biology-engineering interface bringing together engineering principles
and life sciences to impart knowledge in core areas of Biotechnology.
Both UG and PG Programs are accredited by the National Board of
Accreditation (NBA). The Department is a recognized Research Centre
by VTU, Belgaum, offering M.Sc (Engg.) by research and PhD
programs. The Department also offers a Post Graduate Diploma in
Biopharmaceutical Technology under the Biotechnology Skill
Enhancement Programme (BiSEP), supported by the Department of IT
& BT, Government of Karnataka.
The Department has 15 faculty members, of them 14 are Ph.D holders.
The faculty members have competence in core areas of Biotechnology
viz. Food and Agricultural Biotechnology; Health and Medical
Biotechnology; Environmental Biotechnology and Bioprocess
Engineering. The faculty members have expertise in diverse disciplines
of Biotechnology with focused research funded by national/state
funding agencies (DST, AICTE, KBITS, VGST, VTU, RGUHS etc.). The
average publications of the department in SCI and SCOPUS indexed
journals is 30/year.
The Department has well equipped academic laboratories and
state-of-the art research laboratories. High quality research-based
in-house projects guided by the faculty have attracted state funding,
resulted in publications in high impact journals and won Best project
awards at the state level. Students carry out their internships at
various premier institutes in India and abroad. Several students receive
the prestigious Indian Science Academies Fellowship (INSA) and
Jawaharlal Nehru Centre for Advanced Scientific Research (JNCSAR)
Summer research fellowship. Every year, a sizeable number of
graduate students pursue their higher education at various premier
Institutes in India and abroad after qualifying GATE, GRE & TOEFL
exams. The Department has established student clubs and
professional student chapters to provide collaborative learning
platform for the students. Students at Department of Biotechnology
not only excel in academics but also have received awards and
recognitions in various extra-curricular activities.
Dr. Chandraprabha M N
Professor & Head
BIOTECHNOLOGY
ACTIVITIES
ASSOCIATE PROFESSORS
Dr. Dhamodhar P, Ph.D
Dr. Ahalya N, Ph.D
Dr. Y S Ravikumar, Ph.D
Dr. Prabha M, Ph.D
ASSISTANT PROFESSORS
Dr. Lokesh K N, Ph.D
Dr. Samrat K, Ph.D
Mr. M Gokulakrishnan, (Ph.D)
Dr. Bhavya S G, Ph.D
Dr. T P Krishna Murthy, Ph.D
Dr. Abhijith S R, Ph.D
Dr. Roshni Ramachadran, Ph.D
Dr. Priyadarshini Dey, Ph.D
FACULTY
PROFESSOR & HOD
Dr. Chandraprabha M N, Ph.D
PROFESSORS
Dr. Bindu S, Ph.D
RESEARCH PROJECTS
COMPLETED PROJECTS
Genetic Profiling of Candida tropicalis (5,000 USD)
(Bristol - Myers Squibb, (NJ, USA)
Development of an extraction process to increase
the yield of natural indigo dye from Indigofera
tinctoria:Increasing profit margins and promoting
the use of natural dye among traditional ilekal
artisans in Karnataka. (3.25 lakhs) (DST).
Characterization and control of Candida sp.,
associated polymicrobial biofilms causing
reproductive tract infections and fouling of
prosthetics in women (16.89 lakhs) (DST).
Control of Candida biofilms causing vulvovaginitis
in women using household spices and herbs.
(24.74 lakhs) (DST).
In Vitro studies on effects of carbon nanotubes on
antioxidant mechanism in human neuronal cells
(0.8 Lakhs) (IEI).
Inhibitory effect of fruit extracts on the formation
of heterocyclic amines in meat. (4.0 lakhs) (VGST).
Development of sustainable bioreactor technology
for removal of arsenic by Desulfovibrio
desulfuricans. (10.5 lakhs) (AICTE).
Bioremediation of arsenical mine wastes by
Acidithiobacillus ferrooxidans: A lab based study.
(7.84 lakhs) (VTU).
Development of Sulphate Reduction Technology in
an anaerobic digester for abatement of acid mine
drainage. (29.75 lakhs) (DST).
Molecular analysis of Enterococcus fecalis
associated with endodontic infections in Bangalore
urban population (0.40 lakhs) (RGHUS).
Isolation and characterization of Microflora
associated with Dental Caries and their Molecular
analysis. (0.50 lakhs) (RGHUS).
ONGOING PROJECTS

Development of an antimicrobial lock therapy solution for control of
candida albicans under flow conditions (4.5 Lakhs) (KSCST).
Coffee Waste Utilization for the production of food oligosaccharides
(3.30 Lakhs). (RIT Seed Fund).
Development of a Biocompatible Poly (L-Latic Acid)- Chitosan
hydrogel scaffold for neuronal regeneration(32.90 Lakhs), (DST).
An investigation of the role of S-acylation in cardiac hypertrophy –
proteomics, site-specific mutation and molecular dynamics
simulations approach(18.30 Lakhs), (DST).
A biological strategy to enhance chronic wound healing in patients
using Human Autologous Platelet –Rich Plasma (2.60 Lakhs), (RIT
Seed Fund).
Design of structurally modified nanoceria with enhanced
haloperoxidase activity to combat sulphate reducing bacteria (SRB)
induced biocorrosion: A biomimetic approach to combat
microbilogically –influenced corrision (MIC) of marine(41.83 Lakhs),
(DST).
Designing of novel biocompatible and multifunctional nano ceramic
coatings for medical implants (30.0 Lakhs), (VGST).
Stimuli responsive polymeric particles containing iron (iii) chelating
bioactive ligands for mitigation of intracellular labile iron pool (LIP)
(18.30 Lakhs), (DST).
Biotechnology Skill Enhancement Programme
(BiSEP)–Biopharmaceutical Technology (162.5 Lakhs), (KBITS).
Enhanced production of Indican(precursor of Indigo Dye) from cell
suspension culture of Indigofera tinctoria and its up scaling through
bioreactor. (23.72 Lakhs) (DST).
Student Achievements (2021-2022)

Student Publications in Scopus indexed Journals -07
International Internships – 02
International scholarship for higher studies – 06
National Scholarship for Higher studies – 02
Nimsha Kamala N S, VI semester, Ramaiah Institute of Technology has
received INSA Summer Research Fellowship.
Nimsha Kamala N S, VI semester, Ramaiah Institute of Technology is the
2nd runner up of the South Zone Public Speaking Contest “Voice of BT”
held on 30 September 2022 at Sastra University, Thanjavur, Tamil Nadu.
Events Organised
Fourth International Conference onRecent Advances in
Engineering Sciences”was organized by in
collaborations with Department of Biotechnology,
Mechanical Engg, IEM, Civil Engg & Chemical Engg, RIT,
13-14 Oct 2022.
Five Days Hands-on Training Program on “Cancer Tools
and Techniques”in collaboration with Mercklife Science
Pvt Ltd &Department of Biotechnology, RIT, 22 - 26
August 2022
Three-dayImpact Lecture Series on “World
Environmental Day” Collaboration with Department of
Biotechnology & Department of Mechanical
Engineering, RIT, 7–9 June 2022.
Lecture Series on “"Industrial perspectives on
Biopharmaceutical processes and applications”
Collaboration with Mercklife Science Pvt Ltd &
Department of Biotechnology, RIT, March -May 2022.
One Week Workshop on “Advances and Applications of
Nanobiotechnology” organized under Indian Institute
of Chemical Engineers (IIChE), RIT, October 2021.
One Week Faculty Development Programme on “Recent
Advances and Opportunities in Industrial
Biotechnology” organized under Association of
Biotechnology Led Enterprises (ABLE), India, RIT, 4 – 9
October 2021.
Pooja G, VIII semester, won Best paper presentation award, Oral
Presentation at International Conference on Functional Materials,
Energy, Environment and Biomedical Applications, Bishop Heber
College.
Trupthi Joshi, received Full EMJMD scholarship $1125 per month,
Erasmus Mundus scholarship by European Union for higher studies at
University of Groningen, Netherland.
Janvi Tirlapur& group - VIII semester BE project funded under Karnataka
State Council for Science & Technology (KSCST) 45th SPP Scheme 2022.
Niyati Navaneeth, won 2nd place in solo dance, “Prathidhwani”, Inter
collegiate cultural fest, UTSAV-ENVISAGE held on 27th of May 2022.
Harini Satish, VI Semester, won 3rd place in “Basketball’ Inter Collegiate
zonal tournament held at JSSATE Bangalore on 17-18 December 2021.
MOUs/ INTERACTION WITH INDUSTRIES
Merck Life Science Pvt Ltd, Biocon Private Limited,
Himalaya Drug Company, Sartorious Stedim Biotech India
Private Limited, Beckman Coulter, Hindustan Unilever
Limited, Biocon/ Bristol Meyers Squibb India Limited, Sami
Labs, Genotypic Technologies, GanGagen
Biotechnologies, Aristogene Biosciences, Celest Pharma,
ReaGene Biosciences, Acquity Labs, Kemwell Biopharma
Pvt. Ltd, Nestle India Pvt Ltd& Novozymes India Pvt
Ltd.Bioman Technology, Beckman Coulter Life Sciences &
Bionovid Technology Pvt Ltd.
Harini Satish, VI Semester, won 4th place in “Tennis’ Inter
Collegiate zonal tournament held at JSSATE Bangalore
on 31st December 2021 and 1st January 2022.
Soumya Sakshi , VI semester, won 2nd place in a group
dance, Step up group dance event at Utsaha Vaibhava,
BMS Institute of Technology & Management, Yelahanka
on 24th and 25th July 2022
PAPER Published:
Twenty-four research papers were published in national/international
journals/conferences.
FUNDED PROJECTS AND CONSULTANCY:
Development and Demonstration of smart hybrid solar-biomass cold
storage system for Agricultural products Co-Investigator VTU-Belagavi
23/02/2022, INR.700000/-.
Consultancy Project on Predictive Analytics on agglomerated data for
WeOne Solutions from March-July 2021 with sanctioned amount Rs.
35000+GST.
The Department of Computer Science and Engineering (AI & ML) and
Department of Computer Science and Engineering (Cyber Security)
were established in 2021 to meet the needs of the emerging IT industry
and research.
The departments have eminent professors and faculty with doctorate
degrees. The faculty have been publishing research papers in refereed
journals and in conference proceedings. The departments have
state-of-the-art laboratories and class rooms. The departments
conducts Technical seminars, workshops and hackathons regularly for
students. The departments encourages the students to conduct and
participate in extra- curricular/sports activities. The departments
conducts courses with more hands- on sessions and encourages
students to take up MOOC based online courses in NPTEL,
IITBombayX, Coursera, Udacity, Udemy and edX.
ACTIVITIES
FACULTY
PROFESSOR & HOD
Dr. M N Thippeswamy - Ph.D.
ASSOCIATE PROFESSOR
Dr. Mohana Kumar S - Ph.D.
Dr. Sini Anna Alex - Ph.D.
ASSISTANT PROFESSOR
Mrs. Akshatha G C - M.Tech (Ph.D.)
Mrs. Pallavi T P - M.Tech
BOOKS PUBLISHED
Advanced Engineering Research and Applications Aera,
Dankan V Gowda, Ramachandra A C, Thippeswamy M N,
Pandurangappa C, 1st Edition.
Handbook on Computer and Information Technology’ VOL.II
HCIT’, 1ST EDITION, Dankan V Gowda, Ramachandra A C,
Thippeswamy M N, Pandurangappa C, 1st Edition.
Dr. Siddesh,Et al, Society 5.0: Smart Future Towards
Enhancing the Quality of Society, Springer Nature.
Dr. Siddesh Et al, Artificial Intelligence for Information
Management: A Healthcare Perspective, Springer Nature.
Dr. Siddesh Et al, Statistical Modelling and Machine Learning
Principles for Bioinformatics Techniques, Tools, and
Applications, Springer Nature.
Dr. Siddesh Et al, Network Data Analytics: A Hands-On
Approach for Application Development, Springer Nature.
Dr. Siddesh Et al, Internet of Things, Cengage Learning.
Dr. Siddesh Et al, The Rise of Fog Computing in the Digital
Era, IGI Global.
Dr. Siddesh Et al, Statistical Programming in R, Oxford
University Press.
Dr. Siddesh Et al, Cyber Physical Systems: A Computational
Perspective, CRC press, Taylor & Francis Group.
AWARDS
Dr. M N Thippeswamy received CMI Level 5 Award in Management and
leadership on 29-10-2021 AICTE, CMI, U.K.
Dr. Sini Anna Alex received RULA Research Ratna Award, for International
Innovation and Betterment Excellence in Technical Research titled
“Innovative Researcher in Pervasive Computing”, IJRULA Best Paper Award.
INDUSTRY COLLABORATIONS
Koo India, Bangalore
Pinaacle Technologies Pvt Ltd, Bangalore
SUBEX
IBM India
FlyCamp
Project Implementation and training – SAMSUNG, UNISYS, Bionaltek
Training- Wondersys, SAP
Dr. Thippeswamy M N
Professor & Head
COMPUTER SCIENCE AND ENGINEERING

(Artificial Intelligence and Machine Learning)

&

COMPUTER SCIENCE AND ENGINEERING

(Cyber Security)

PROFESSOR
Dr. Siddesh G M - Ph.D
Students who participated in the Smart India
Hackathon - 2022 in Mumbai.
CSE(AI&ML) students have attended the drone technology
workshop
CSE(AI&ML) students are attending Mr. Devesh talk on Drone
Technology
STUDENT ACHIEVEMENTS
Ansh Singhal (1MS21CI006) was certified as the "best overall
performer" in Tersho's python course.
Ansh Singhal (1MS21CI006) was the winner of the 6-month Replit
HackerPlan.
Venkatesh R, Kushal S Ballari, Jedi Samy and Jeswin MS, CSE(AI&ML),
2nd year, have secured 1st place in the competition "Let's Find Out"
conducted on November 21 2022.
Venkatesh R, Kushal S Ballari, N Sudharshan Reddy and Aniruddh
Mantrala, CSE (AI&ML) 2nd year, have secured 1st place in the
competition "Hackaphasia".
Shravan was selected for an internship at a startup as a full-stack web
developer and received special recognition at an ideathon competition.
He developed a website for the IEEE Bangalore chapter, showcasing
their events, initiatives, and contributions to the field of technology and
engineering.
Yash Gupta (1MS21CY062), H M Navneet (1MS21CY044), Rohan
Santhosh (1MS21CY017) Surya K (1MS21CY056) has participated in
Smart India Hackathon -2022.
Abhishek M (1MS21CY004) participated in the RVITM Fantom code
2022 and cleared round 1 in the national Engineering Olympiad 6.0,
securing 712th Rank at the All India level.
Rohan Santhosh (1MS21CY044) from the CSE (Cybersecurity) won a
video editing competition conducted by ECell RIT.
M Dinesh Gokul Das (1MS21CY029) of the CSE(Cyber security) finished
as a semi-finalist in the Innovative Entrepreneurship competition
conducted by Avery Dennison Foundation.
CSE (AIML) & CSE (Cyber Security) students visited the SAP on 9 December 2022
Mr. Harsh Singhal, Head, ML, Koo, India
delivering talk to CSE(AI & ML) and
CSE(Cyber security) Students.
CSE (Cyber Security) and CSE(AI&ML)
students are interacting with Mr. Upen
Pradhan, Subex, Bangalore
Dinesh, winner Avery Dennison Foundation
Competition & represented institute in kho
kho and athletics 800m.

CSE (Cyber Security) students with Dr.
Manoj CEO Pinnacle Consulting Ltd.
PAPER Published (For AY 2021-22)
Twenty-five articles were published in national/international
journals/conferences.

The Department of Artificial Intelligence and Data Science was
established in 2021 to meet the needs of the emerging IT industry and
research.
The department has eminent professors and faculty with doctorate
degrees. The faculty has published research papers in refereed
journals and conference proceedings. The department has
state-of-the-art laboratories and classrooms. The department
conducts Technical seminars, workshops and hackathons regularly for
students. The department encourages the students to conduct and
participate in extracurricular/sports activities. The department
conducts courses with more hands-on sessions and encourages
students to take up MOOC-based online courses in NPTEL, IIT Bombay,
Coursera, Udacity, Udemy and edX.
ACTIVITIES
FUNDED PROJECTS AND CONSULTANCY

Consultancy Project on Development of a full stack web application
solution for companies in shipping domain by Leoxipraade Pvt. Ltd.
Bangalore with sanctioned amount Rs. 15000+GST
Consultancy Project on Web Interface Development for CBTAS
(Cloud Based Thermal Analysis System) by SNAM Alloys Pvt. Ltd,
Hosur, Tamil Nadu with sanctioned amount Rs. 8.25 Lakhs.
Funded Project on Technology Development and Automation of
Hydroponic Farms in Urban areas using enhanced precision farming
by incorporating loT and Cyber Physical System by VGST with
sanctioned amount Rs. 3.00 lakhs.
Consultancy Project on Identification and Analysis of Performance
indicators of waste processing, integrated with the design of
corporate website to auto-update the indicators by Swachha Eco
Solutions, Bangalore with sanctioned amount Rs. 61,000.
Consultancy Project on Search and Rescue using Drones by Fly
Camp Bangalore with sanctioned amount Rs. 20,000.
Consultancy Project on AI and ML Training by Wondersys
Automation, Bangalore with sanctioned amount Rs. 15,000.
ASSISTANT PROFESSOR
Mr. Vinay T R - M.Tech(Ph.D.)
Mrs. Swetha B N – M.Tech
FACULTY
PROFESSOR & HOD
Dr. Anita Kanavalli - Ph.D.
BOOKS PUBLISHED
Statistical Programming in R, Oxford University Press.

INDUSTRY COLLABORATIONS
CISCO
SUBEX
IBM India
FlyCamp
Project Implementation and training– SAMSUNG,
UNISYS, Bionaltek
Training- Wondersys
STUDENT ACHIEVEMENTS
The Students from Artificial Intelligence and Data
Science department department have participated
and won in many technical events like Hackathon,
and Ideathon.
The students Deepak Dhakad and Riddhi Rai won
the Mathematics Quiz.
Riddhi Rai participated and presented their
innovative ideas at the 73rd International
Astronautical Congress conference held from 18th
to 22nd September 2022 in Paris.
The Students have excelled in the co-curricular
activities.
Yashashwini Singh represented Ramaiah in VTU
Bangalore Zone CHESS Tournament 2022
organized by TOCE.
ASSOCIATE PROFESSOR
Dr. Sowmya B J - Ph.D.
Dr. Anita Kanavalli
Professor & Head
ARTIFICIAL INTELLIGENCE AND DATA SCIENCE

Dr. Jagadish S Kallimani
Professor & Head
ARTIFICIAL INTELLIGENCE AND MACHINE LEARNING

PAPER Published (For AY 2021-22)
Twenty-one articles were published in national/international
journals/conferences.

The department of Artificial Intelligence & Machine Learning was
established in the year 2021 to meet the needs of the emerging IT
industry and research. The department has eminent professors and
faculty with doctorate degrees. The faculty has publishing research
papers in refereed journals and in conference proceedings. The
department has state-of-the-art laboratories and class rooms. The
department conducts Technical seminars, workshops and hackathons
regularly for students. The department encourages the students to
conduct and participate in extra- curricular/sports activities. The
department conducts courses with more hands-on sessions and
encourages students to take up MOOC based online courses in NPTEL,
IIT Bombay, Coursera, Udacity, Udemy and edX.
ACTIVITIES
FUNDED PROJECTS AND CONSULTANCY

Development and Demonstration of smart hybrid solar-biomass
cold storage system for Agricultural products Co-Investigator
VTU-Belagavi 23/02/2022, INR.700000/-
Consultancy Project on Identification and Analysis of Performance
Indicators of Waste Processing, Integrated with the Design of
Corporate Website to Auto-update the Indicators by Swachha Eco
Solutions, Bangalore with sanctioned amount Rs. 61,000/-
Consultancy Project on Search and Rescue using Drones by Fly
Camp Bangalore with sanctioned amount Rs. 20,000.
ASSISTANT PROFESSOR
Mrs. Megha J - M.Tech (Ph.D)
FACULTY
PROFESSOR & HOD
Dr. Jagadish S. Kallimani - Ph.D.
INDUSTRY COLLABORATIONS
Fly Camp.
Project Implementation and training– SAMSUNG,
UNISYS.
STUDENT ACHIEVEMENTS
Aayush Shukla, A Strategic Approach To Tackle
Interplanetary Communication Delay: Exploiting
Artificial Intelligence Solutions For Future Space
Exploration, Presented paperin 73rd International
Astronautical Congress (IAC), Paris, France, 18-22
September 2022
Students participated in many technical events like
Hackathon, and Ideathon.
The students participated and won the
Mathematics Quiz.
The Students have excelled in the co-curricular
activities.
ASSOCIATE PROFESSOR
Dr. Meeradevi - Ph.D.
Industrial Visit to Aerospace Park
Riddhi Rai Presenting her research article in
International Astronautical Congress conference held
from 18th to 22nd September 2022
Aayush Shukla Presenting her research article in
International Astronautical Congress conference held
from 18th to 22nd September 2022

Our Students at Project Exhibition presenting their
Innovative Ideas
Java Training by GDSC for 3rd semester
Students at CentuRITon Students at NSS Activities.
PAPER PRESENTED
National and International Journals and conferences – 20
The School of Architecture in MSRIT is instituted in 1992. Addressing
the growing needs of the metropolitan city, it caters to the demand of
Architectural education. The SOA – RIT currently offers 5 years
Bachelor in Architecture (B.Arch), 2 years Masters in Architecture
M.Arch (Landscape Architecture) program and Research Program in
Architecture. These programs are recognized by COA and AICTE. The
School of Architecture is part of Ramaiah Institute of Technology, an
Autonomous institution from 2007 affiliated to Visveswaraya
Technological University. With successful completion of more than 30
years of its existence, School of Architecture has made its presence
felt in the area of Architectural Education in India. The Department
executes various research and consultancy projects. The faculty
consists of senior professionals and various expertise with good
experience in industry and academics. Students across India and
Abroad enrol for the course and many have been recognized for their
academic achievements. The School of Architecture encourages
students to think outside the box, and gives them ample opportunities
to do so.
‘INSPIRIT’- an annual intercollege fest organized by the students and
faculty of the School paves way for excellence in creative fields.
Nationally and Internationally renowned architects are invited to
present best world to inspire and motivate the students. The annual
magazine of the School of Architecture, ‘RENDER’, brings forward the
literary, artistic talent and creative abilities of the Students.
All allied and supporting subjects related to Architecture and allied
field are covered and through conducting regular workshops, guest
lectures, conferences, faculty development programs as part of the
development and progress of the school for the benefits of students,
faculty and professor.
Annual study tours, both national and international, sites/field visits
are conducted to expose students to exposed due to outer world of
Architecture
The School has faculty, expertise in areas like Architecture,
Professional Practice, Construction & Project Management, Building
Engineering & Management, Interior Design, Urban Design, City
Planning, Urban Planning, Urban Design, Product Design, Landscape
Architecture, Environmental Planning, Conservation, Housing, Fine
Arts, Habitat Design, Infrastructure System and Advanced
Architectural Design, and Many more
Prof. Pushpa Devanathan
Professor & Head
ARCHITECTURE
ACTIVITIES
ASSOCIATE PROFESSORS
Dr. Rashmi Niranjan - MFA (Fine Arts), Ph.D
Dr. Monalisa - M Arch, Ph.D
Ar. Surekha R - M Arch (Landscape Arch.) (Ph.D)
Ar. Lavanya Vikram - M Arch (Landscape Arch.) (Ph.D)
Ar. Sudha Kumari G - M Arch (Habitat Design)
Ar. Meghana K Raj - M Arch (Landscape Arch.) (Ph.D)
Ar. Tejaswini H - M Arch (Landscape Arch.) (Ph.D)
Ar. Reema Harish Gupta - M Arch (Urban Design
VISITING FACULTY
Ar. Meghana Vikram - B Arch
Ar. Shalini Srikanth - B Arch
Ar. Prethish Chandrasekaran - B Arch
Ar. Prathibha Ramesh - B Arch
Ar. Santhosh N Madbhavi - B Arch
Ar. Sowmya R - M Arch (Landscape Arch.)
Ar. Deepthi C B - M Arch (Landscape Arch.)
Ar. Bijoy Chacko - M Arch (Landscape Arch.)
Ar. Nina Chandavarkar - M Arch (Landscape Arch.)
Ar. Girish S - B. Arch
Ar. Gurukiran Sanga - B.Arch
Ar. Shreedhar K Mobar - B Arch
Ar. Ashwini Ashwath K - M Arch (Urban Design)
Ar. Shivaraj V Bhnsanur - B Arch
Ar. Naveen K V - B Arch
Ar. Deepa Rabindra - M Arch (Landscape Arch.)
TENURE FACULTY
Ar. Prasad G - M Arch (Landscape Arch.)
Ar. Mallika P V - M Arch (Landscape Arch.)
Ar. Sudhir Chougule - M Arch (Landscape Arch.)
Ar. Nikhil V Wodeyar - P G (Urban Design)
Ar. Aswini Mani - M Arch
FACULTY
PROFESSOR & HOD
Prof. Pushpa Devanathan - M.Arch(Hab Des), P.G.D.I (Ph.D)
PROFESSOR & HEAD - M. Arch (Landscape Architecture)
Dr. Rajshekhar Rao - M Arch (Landscape Arch.), Ph. D
PROFESSORS
Prof. Vishwas Hittalmani - M Des
Prof. Jotirmay Chari - M Arch (Ph.D)
ASSISTANT PROFESSORS
Er. M Vijayanand - M Tech (PhD)
Er. Aruna Gopal - B.E (M.Sc.)
Ar. Kriti Bhalla - B Arch
Ar. Aishwarya Yoganand - M.Sc.(Sustainable Building Systems)
Ar. Divya Susanna Ebin - M Arch (Urban Design)
Ar. Ranjitha Govindaraj - M Arch (Landscape Architecture)
Ar. Theju V Gowda - M.Sc. (Architecture)
Ar. Akshata Shagoti - M Arch (Architectural Design)
Ar. Amala Anna Jacob - M Arch (Urban Design)
Ar. Meghana M - M A (World Heritage Studies)
Ar. Megha Ann Jose - M Arch (Interior Architecture & Design)
Ar. Pooja M Naik - M Arch (Urban Planning & Management)
Ar. Anupama D - M.Plan (Masters of Urban Regional Planning)
Ar. Katre Tanvi Sanjeev - M. Plan (Masters of Environmental Planning)
Ar. Vidya Mohan - M Arch (Urban Planning & Refurbishment)
Ar. Sreesha S Bhatt - M Arch (Urban Design)
Ar. Harshitha D - M Arch (Urban Design)
Ar. Joyce Sequeira - M Plan (Urban Planning)
Ar. Shwetha P E - M Arch (Urban Design)
Ar. Pinki Bose - M Arch (Urban Design)
Ar. Sruti R - M Arch (Urban Design)
PAPER PRESENTED
In the last one year, 30 research articles have been published by the
faculty members in the peer reviewed International journals of high
impact factor.
Two research projects funded by VGST and SERB to the tune of Rs.
45 Lakhs are ongoing in the department.
12 Ph.D. degrees are awarded by the Physics R & D centre and
currently 9 research scholars are pursuing their Ph.D.
EVENTS CONDUCTED IN THE PREVIOUS ACADEMIC YEAR
AICTE Sponsored One-week Faculty Development Programme (FDP)
on “Research challenges in Atmospheric sciences with a Computing
Edge” during 20 – 24 December 2021.
“International Conference on Applied Research in Engineering
Sciences (ICARES-2022)” on 24 & 25, November 2022.
ACTIVITIES
Physics, Chemistry and Mathematics are the constituent subjects of basic sciences, common to all branches in the initial
semesters. Each of the departments imparts effective subject knowledge supported by qualified and experienced staff. The
departments are recognized as research centres by VTU and offer a Ph.D degree in the respective subjects.
Physics department of RIT has well qualified and motivated faculty
members who are actively engaged in teaching and research work. The
mission of the department is to provide the best training through
teaching and research to enable the students to master the concepts
in Physics and kindle their interest in cutting edge research areas. The
Department is recognized as a research Centre by VTU since 2008.
BASIC SCIENCES
Dr. A. Jagannatha Reddy
Professor & Head
PHYSICS
ASSOCIATE PROFESSORS
Dr. Seema Agarwal - Ph.D
FACULTY
PROFESSOR & HOD
Dr.A. Jagannatha Reddy - Ph.D
ASSISTANT PROFESSORS
Dr. Ravindra M Melavanki - Ph.D
Dr. K.L. Sandhya - Ph.D
Dr. B. V. Nagesh - Ph.D
Dr. G. N. Anil Kumar - Ph.D
Dr. B. Siddlingeshwar - Ph.D
Dr. S. Vaijayanthimala -Ph.D
Dr. Kalpana Sharma - Ph.D
Dr. Ambika M R - Ph.D
Physics Lab
Physics Lab
PAPER PRESENTED
National and International Journals and Coferences - 600

FUNDED PROJECTS
6 numbers

Awards/Citations
20 Best paper awards
7 Best Reviewer award
Google Scholar Citations - 13800

Industrial Collaborations
Established MoU with Sreram Institute of Industrial Research (SRI)
Bangalore

Department of chemistry was established in the year of 1962. The
department consists of team of nine well qualified teachers with PhD,
one visiting professor and one Research Scientist. The main activity of
the department since its inception has been teaching chemistry (both
theory and lab) to students of I and II semester of all the branches, III
chemical engineering students and open electives for 6th and 8th
semester BE students. Facility provided by the management of RIT and
funding by TEQIP a modest research lab has been set up which has
been recognised by VTU as a research centre.
Department is actively involved in guiding Ph.D, UG and PG final year
projects for RIT and also out side RIT research scholars. At present
active research in the department involves (i) Synthesis,
characterization and study of properties of nano-materials, trasition
metal complexes and their applications. (ii) Photocatalysis (iii)
Photoluminescence studies (iv) Synthetic Organic chemistry. There are
20 Ph.D’s are awarded. Last five years the department published
around 400 research articles in international peer reviewed journals.
Dr. B.M. Nagabhushana
Professor & Head
CHEMISTRY
ACTIVITIES
ASSOCIATE PROFESSOR
Dr. Nagaraju Kottam, M.Sc., Ph.D
ASSISTANT PROFESSORS
Dr. M.N.Manjunatha, M.Sc., Ph.D
Dr.P. Murali Krishna, M.Sc., Ph.D
Dr. Basappa C Yallur, M.Sc., Ph.D
Dr. Maalathi C, M.Sc., Ph.D
Dr. Sharanabasappa Patil, M.Sc., Ph.D
Dr. R Hari Krishna, M.Sc., Ph.D
Dr. Gurushantha K, M.Sc., Ph.D
Dr. Sampath Chinnam, M.Sc., Ph.D
FACULTY
PROFESSOR & HOD
Dr. B.M. Nagabhushana, M.Sc.,Ph.D
Half yearly ‘Research Review Meetings (RRM)’ by
Department of Chemistry
Department of Chemistry regularly organizing ‘Research
Orientation for Research Aspirants (ROPRA)’
Papers published in National / International journals: 144 since
Papers presented in National / International conferences: 85
Ph.D. awarded: 20 Research Scholars: 06
Industrial collaborations : 02
Snam alloys private limited, Hosur, Tamil Nadu along with
Mechanical department.
Established MoU with The Bangalore Kidney Stone
Hospital Bangalore
Annual Event:
RIT slice of Pi – Quiz for 12th standard students
Maths Quiz MQ & MQ+ for 1st & 2nd year B.E. Students
respectively.
The department came into existence in the year 1962. The major focus
of the department is to inculcate mathematical thinking in engineering
students. For this, we teach core mathematics courses to students at
undergraduate and postgraduate level as well as offer electives in
mathematics.
The department has a staff strength of 23 members. At present, there
are 22 Ph.D. holders. Current expertise of the faculty covers a broad
range of areas including Fluid mechanics, Linear Algebra, Numerical
Methods, Number Theory, Probability, Statistics and Queueing Theory.
The department faculty have published many papers in national and
international journals. In addition, the faculty members have also
obtained extramural support to carry out research activities and
projects sponsored by VTU, UGC, DST and TEQIP.
Dr. N. L. Ramesh
Professor & Head
MATHEMATICS
ACTIVITIES
ASSOCIATE PROFESSORS
Dr. Monica Anand - M.Sc., Ph.D.
Dr. Dinesh P A - M.Sc., M.Sc., (IT),M.Phil, Ph.D
PROFESSORS
Dr. S H C V Subba Bhatta – M.Sc., M.Phil, Ph.D
Dr. G Neeraja - M.Sc., Ph.D
FACULTY
PROFESSOR & HOD
Dr. N L Ramesh – M.Sc., Ph.D
ASSISTANT PROFESSORS
Dr. M V Govinda Raju - M.Sc., Ph.D
Dr. Vijaya kumar - M.Sc., M.Phil, Ph.D
Dr. A Sreevallabha Reddy - M.Sc., Ph.D
Dr. Suresh Babu R - M.Sc., M.Phil, Ph.D
Dr. M S Basavaraj - M.Sc., B.Ed, M.Phil, Ph.D
Mr. B Azghar Pasha - M.Sc., (Ph.D)
Dr. Aruna A S - M.Sc., M.Phil, Ph.D
Dr. Girinath Reddy M - M.Sc., M.Phil, Ph.D
Dr. Uma M - M.Sc., Ph.D
Dr. Ram Prasad S - M.Sc., M.Phil, Ph.D
Dr. Kavitha N - M.Sc., Ph.D
Dr. Sushma S - M.Sc., Ph.D
Dr. Y S Kalyan Chakravarthy - M.Sc., Ph.D
Dr. Shashi Prabha Gogate S - M.Sc., Ph.D
Dr. Praveena M M - M.Sc., Ph.D
Dr. Veena B N - M.Sc., Ph.D
Dr. Srikantha N - Ph.D
Dr. Sowmya G - Ph.D
RIT Slice of Pi - 2019
Mathematics Quiz MQ - 2019 Mathematics Quiz MQ+ - 2019
Papers published in National / International journals: 24
Books / Book Chapters Published : 11
The Department of Humanities has seven faculty members, with three
doctorates. The department engages in teaching Communicative
English, Constitution of India, Kannada, Communication skills for
BE/BArch students. Apart from this the department runs special
classes/bridge courses in Communicative English to train NRI and rural
students in English language usage. The faculty members engage in
teaching-learning activities, research publications and conducting
workshops for students to build social skills and broaden critical and
creative competencies.
The department is also equipped with an English Language lab located
in LHC block. First Year BE students take this course as a part of the
subject Communicative English, Building Vocabulary, Grammar,
Listening, Speaking skills, Power Point presentations and Group
activities form integral part of the course.
Dr. N. L. Ramesh
Professor & Incharge HOD
HUMANITIES
ACTIVITIES
FACULTY
PROFESSOR & INCHARGE HOD
Dr. N L Ramesh – M.Sc., Ph.D
ASSISTANT PROFESSORS
Dr. Premila Swamy D, M A, Ph.D
Mrs. Kanya Kumari, M A
Dr. Udaya Kumar H M, M A, Ph.D
Sri. Diwakar P, M A, (Ph.D)
VISITING FACULTY
Smt. Sukanya, M A
Ms. Nimmy V S, LLB
Dr. Kiran Magavi, M A, Ph.D
Smt. A R Annapurna, M A
R&D LAB
MCA LAB
The Department of Master of Computer Applications was established
in the year 1997 with the objective of producing high quality
professionals to meet the demands of the emerging field of Computer
Applications. A team of experienced staff members are dedicated to
teaching and developing academic activities in the department. The
department got academic autonomy in the year 2007 and is accredited
by NBA. The Department of Master of Computer Applications is
recognized as a Research Centre under Visvesvaraya Technological
University in 2012. Department has well qualified and experienced
eleven faculty members with seven Ph.D.’s. The department has well
equipped Laboratories, it also has the facility to conduct specialized
labs in –IOT, Cyber Forensics, Data Analytics, AWS, and Blockchain.
The Department is actively involved in Industrial Consultancy and
Research work. The faculty have published more than 400 research
papers in National/International Journal / conferences. Totally 23
research scholars are pursuing Ph.D. The department is actively
associated with industry partnership, organizes Industry visit and
interactions. Department regularly conducts Faculty/Student
Development Programmes, Workshops, Seminars, Conferences on
latest topics in the area of Computer Applications. Department
conducts annual department technical fest-Abhyuday. Students
actively participate in extracurricular and co-curricular activities and
also contribute to the department Magazine(yearly)-Nalanda.
The Department is excelling in Research and Development Activities in
the core areas such as Cloud computing, Data science, Blockchain,
Artificial Intelligence, IOT, Cyber Forensics, and Software Engineering.
Dr. Seema S
Professor & Head
MASTER OF COMPUTER APPLICATIONS
(MCA)
FACULTY
PROFESSOR & HOD
Dr. Seema S – Ph.D
ASSISTANT PROFESSORS
Dr. Madhu Bhan - MCA, Ph.D
Dr. M Mrunalini - MCA, Ph.D
Dr. Manish Kumar - MCA, Ph.D
Sri. Chethan Venkatesh - MCA, (Ph.D)
Ms. B N Nithya - MCA, (Ph.D)
Mr. Abhishek K L - M.Tech
Smt. Geetanjali R - MCA
ASSOCIATE PROFESSORS
Dr. S Ajitha – MCA, Ph.D
Dr. S Jagannatha - MCA, Ph.D
Dr. D Evangelin Geetha - MCA, Ph.D
MCA LAB - 3
PAPERS PRESENTED
National and International Journals and Conferences – 170
FUNDED PROJECTS
Research - 07
Sponsored Seminars - 02
Students Publications (National & International level) : 60
The Department of Management Studies (MBA Programme) was
established in 1998 with an objective of creating high quality
professional managers to meet the emerging and ever growing
demands and challenges of the industry in an ethical and responsible
manner. Over the years, the Department has built a strong reputation
for its program. The graduating students of the Department are placed
in reputed institutions and leading corporations. The Department
offers a 2 year MBA degree course of Visvesvaraya Technological
University (VTU). The Department is a recognized Research Centre of
VTU. At present there are 12 Faculty Members of whom 11 are
Doctorates and 23 Research Scholars are pursuing their Ph.D under
their guidance. Recognizing the quality of management education
imparted by our Institution, the Department was the first in Bangalore
Region to receive academic autonomy from VTU in the year 2007.
The Faculty members of the Department have rich academic and
industry experience. Many of our faculty members have authored
books and published papers in leading journals and they have
participated in national and international conferences and seminars.
The Department has well qualified industry professionals as visiting
faculty who share their professional upgradations with the students on
a continuing basis. The Department believes in enhancing the expertise
of the faculty by deputing them to various workshops and faculty
development programs. The Programme is accredited by the National
Board of Accreditation, New Delhi for a period of 3 years
Dr. P V Raveendra
Professor & Head (Incharge)
MASTERS OF BUSINESS ADMINISTRATION

(MBA)
ACTIVITIES
FACULTY
PROFESSOR & HOD (Incharge)
Dr. P V Raveendra – B.E, M.B.A, Ph.D
ASSISTANT PROFESSORS
Dr. G. Vijaya Kumar- M.B.A, Ph.D
Dr. Pallavi .B- M.B.A, Ph.D
Mrs. S.B. Rashmi- M.B.A, (Ph.D)
Dr. Arun Kumar .D.C- M.B.A, Ph.D
Dr. Adarsha .K- M.B.A Ph.D
Dr. Vaijanath Babshetti – M.B.A, Ph.D
PROFESSOR
Dr. Y.M. Satish - M.B.A, Ph.D.
ASSOCIATE PROFESSORS
Dr. M. Rizwana - M.B.A, Ph.D
Dr. A. Mahalakshmi - M.B.A, Ph.D
Dr. T. Mohanasundaram - M.B.A, Ph.D
Dr. Deepak R - M.B.A, Ph.D
“WE CREAT A RECORD AND BREAK OUR RECORD”
MSRIT is always the preferred academic institutes for a large number
of organizations for recruiting our graduates. The biggest names in the
corporate world visit the campus on a regular basis, with enviable
recruitment offers. Most of the top companies across the nation, visit
us for Campus Recruitment. There is tremendous competition
amongst companies to visit the Campus to recruit the best talent of the
institution. MSRIT has been the traditional recruitment destination for
many organizations. The institution stands as the most preferred
destination for students who aspire to grow, learn and reach beyond
the ordinary, reason why some of the world’s finest companies visit us
and discover the best minds available.
Dr. Savitha Rani.M
Placement & Training Officer
PLACEMENT &
TRAINING
Campus Recruitment in process
Amazon International Offer - 2021 Batch

Name : Abhay Desalli
USN : 1MS171S003
Location : Poland
For the batch 2022
1329 offers were made in season Placement.
Highest CTC was Rs. 31,37,930 LPA, by Apple India.
International offer by Sobha Contruction, Sobha Hartland, Dubai
with CTC AED 5,000.
Highest stipend during internship Rs. 90,000/- month by Walmart.
For the batch 2021
1217 offers were made in season Placement.
Highest CTC was Rs. 30 LPA by MuSigma.
International offer Amazon, Poland.
Highest stipend during internship Rs. 87,000/- month by Morgan
Stanley.
For 2020 batch, a total of 213 companies visited and 947 offers were made. Highest CTC for 2020 batch Rs. 43.17 LPA
For 2021 batch, a total of 216 companies visited and 1217 offers were made. Highest CTC for 2021 batch Rs. 30 LPA
For 2022 batch, a total 242 companies visited and 1698 offers were made. Highest CTC for 2022 batch Rs. 31.37 LPA

Recruiters Speak
It has always been a refreshing and pleasant experience visiting MSRIT,
Bangalore, for campus placements. We are impressed by the
enthusiasm and intellect displayed by the students. We are delighted
that we have been visiting MSRIT, Bangalore regularly.
— Mr. Satyanarayana, Director, Open Stream
MSRIT, Bangalore is one of the preferred Engineering Institutes for
TDPS, for recruiting campus graduates. Many of the MSRIT graduates
are employees of greater TDPS and have contributed significantly for
TDPS success.
The fact still remains, the name MSRIT stands for Placements!!
— Mr. P.G. Manjunath, Head-HR, TDPS
Real talent is available at MSRIT
— Mr. Radhakrishnan, Managing Director, Walmart
It is always a great experience to hire students from RIT.
— Dr Suniel Jaljit, VP HR, Titan
Students of RIT participate actively in a variety of sports and a
dedicated department led by Dr. H.K. Kiran Kumar, Director of Physical
Education, manages this activity. The Department has the best of
infrastructure and facilities with quality equipment for sports including
cricket, basketball, football, badminton etc. The campus has a
dedicated basketball and Tennis court and a gym with high-tech
equipment that enables students to keep in shape.
Annually, RIT hosts various sports events - M.S. Ramaiah Memorial
Cricket Tournament, M.S. Ramaiah Memorial Basket ball (M&W)
Tournament, VTU Inter-college Tournaments, Inter-Branch matches
and an Annual Athletic Meet for boys and girls. These tournaments
attract participation from various other engineering colleges across
Karnataka and have a high level of recognition. RIT's students have
represented the state and India in several sports activities, winning
many individual/team events.
PRATYANSHU TOMAR
VIII SEMESTER MECHANICAL ENGINEERING
Represented the Indian Sr. Basketball Team as
player in FIBA Asia Cup 2021, Qualifying
Tournament held at Jeddah, Saudi Arabia from
20th to 22nd August 2021 and also represented
Indian Sr. Basketball Team in Fiba Asia Cup 2022
held at Jakartha, Indonesia from 12th to 24th July.
BADMINTON [MEN]
WINNERS - VTU Bangalore Central Division Badminton
Tournament held at BMSCE, Bangalore on 6th Nov.2022
WINNERS - VTU State Level Badminton Tournament
held at BMSCE, Bangalore on 8th & 9th Nov.2022
TABLE TENNIS [MEN]
WINNERS - VTU Bangalore Central Division Badminton
Tournament held at HKBKCE, Bangalore on 3rd Nov.2022
RUNNERS - VTU State Level Badminton Tournament held at
VVCE, Mysore on 5th & 6th Nov.2022
Dr. Kiran Kumar H K
Director of Physical Education
CO CURRICULAR
ACTIVITIES
BASKETBALL [MEN]
WINNERS - VTU Bangalore Central Division BASKETBALL
Tournament held at NHCE, Bangalore on 29th & 30th Nov.2022
WINNERS - VTU STATE LEVEL BASKETBALL Tournament held
at NMIT, Bangalore on 2nd & 3rd Dec.2022
WINNERS – BMSCE - STATE LEVEL BASKETBALL Tournament
held on 28th & 29th Dec.2022

Dr. Kiran Kumar H K
Director of Physical Education
IN HOUSE ACTIVITIES
Organized VTU Bangalore Central Division Football (Men) Tournament on 25th & 26th Nov.22 in M S Ramaiah Ground
Mr. I Ganashyama Prabhu of VII Semester EIE took part
in 36th National Games Competitions held at
Ahmedabad, Gujarath from 26th Sept. to 3rd Oct. 2022
and participated in Roller Skating Event and Won Bronze
Medal 1000 Mtrs Relay Event
HOCKEY [MEN]
WINNERS - VTU Bangalore Central Division Badminton
Tournament held at CMRIT, Bangalore on 10th & 11th Nov.2022
FOOTBALL [MEN]
WINNERS - VTU Bangalore Central Division Football
Tournament held at MSRIT, Bangalore on 25th & 26th
Nov.2022
RUNNERS - VTU State Level Football Tournament held
at GNDEC, Bidar on 3rd to 5th Dec.2022
At MSRIT we believe in the holistic development of students in a way
that they evolve into full-fledged and confident professionals by the
time they graduate. This can be made possible by encouraging them to
engage in various extra-curricular activities such as music, theatre,
literary, visual and fine arts, apart from sports, NSS and other similar
pursuits.
Extra-curricular activities are not just about entertainment, they help
molding the personality of the students in the following ways:
Enhancing soft skills such as communication skills, etiquette and
confidence levels.
Helping them in the areas of time management, emotion
management, success (and failure) management, crisis management
and more importantly people management.
While good grades equip students to get their first jobs,
extra-curricular activities equip students with skills for their whole
lives.
They help inculcating in students, values such as empathy,
broad-mindedness, team-spirit, self-control, ethics, acceptance of
pluralities in society, corporate social responsibility, and so on.
MSRIT is the only college to have a separate department for cultural
activities, known as the Department of Extra-Curricular Activities
(DECA). There are 21 Student-driven Clubs active on campus under the
guidance and direction of DECA. Apart from Cultural Activities there are
Clubs which involve themselves in Finance, Japanese culture, Gaming,
Video-editing, Photography, etc. There are hosts of activities throughout
the year such as Ice-Breaker (introduction of all Clubs to freshers), All
India level Quiz and Debate Competitions, Shoutout (an exclusive
intra-mural Theatre competitions), Kannada Rajyotsava, TEDx MSRIT,
UDBHAV (inter-collegiate Cultural Festival), etc. Please join and
discover yourselves!
EXTRA-CULTURAL
ACTIVITIES
The National Service Scheme (NSS) is a Government of India initiative launched in 1969 to promote social consciousness,
responsibility, discipline and dignity of labour among college students, encouraging them to utilize their leisure time in various social
service activities.
The NSS unit was started at MSRIT in 1999 and since then, several programs have been initiated with about 450 students as
volunteers. Students participate in a variety of activities including conservation of the environment, water, sanitation, health issues,
family welfare and nutrition, AIDS awareness, anti-drugs drive and so on. Government Primary/ High schools and a few slums were
selected for community service and educational programmes. Students attending the camp are issued a certificate and also eligible
for grace marks in seeking admission to higher classes. NSS Volunteers conducting Blood donation camp every year in the Memory
of our late founder chairman Dr. M S Ramaiah.
NATIONAL SERVICE
SCHEME
NCC Day
Blood Donation
Camp
Dr. Puttabore Gowda
NSS Officer, MSRIT
honored as Best NSS Officer
by Governor, Karnataka State
Distribution
of Spectacles
Orphanage
Visits
SLUM Visit

Dr. Monica R Mundada
Chief Proctor - RIT
Professor, Department of Computer Science & Engineering
BEST
PRACTICES
The Proctorial Process is introduced with an objective of providing
supportive care, guidance and mentoring to students to help them
with their academic progress while at the campus. Every teaching
department implements this process through its faculty and the
faculty members are called proctors.
The proctors closely monitor the student’s performance and interact
with students and their parents/guardians. This system would help
the students to complete their studies comfortably andsuccessfully.
PROCTORIAL SYSTEM
Ramaiah Institute of Technology has in place a web enabled
Student Information System (SIS) http://parents.msrit.edu that
offers students and their parents/guardians up-to-date
information about attendance status, marks scored, time table
and other information about the student. A Login ID and
password is provided to help them access this information from
anywhere across the globe.
Progress Reports of each student are sent to
his/her parents/guardians furnishing the details
of Attendance & CIE marks. These reports are
sent twice in a semester (at the end of 45 days
and 90 days).
SMS are also sent to parents/guardians about
Attendance and CIE marks twice in a semester.
Every Friday the students interact a with their
respective proctors between 02:40 pm -
04:30 pm to discuss their academic progress.
Parents/guardians are welcome to schedule
a meeting with the proctors to discuss any
concern with respect to their wards.
Counseling facility is available to the student.
Students can avail this facility by registering
themselves at the Chief Proctor’s office.
Counseling facility is open to the students every
Friday between 02:00 PM – 04:30 PM
The Chief Proctor office is situated in Apex
Block, level 2 and is open for all students and
parents for interactions.
STUDENT INFORMATION SYSTEM

Student Counseling
Dr. S C SharmaDirector, NAAC
Professional education today is all about working in synergy
with the industry to ensure a maximum fit with their
requirements and expectations and MSRIT has been working
towards achieving that objective. The college has established
close working relationships with some of the world's leading
names in technology.
The Intel Centre of Excellence has been established at MSRIT
with the purpose of training in multi-core architectures and
parallel programming. The objective of this centre is to provide
training to faculty members from various colleges in South
India. Experts from Intel and leading professors from IISc are
involved in the training activity. The centre is equipped with the
best of infrastructure and several students carrying out
projects in high performance computing and allied areas use
the centre.
Adobe Systems has set up the MSRIT Abode RIA Lab to cater
to the needs of academicians and industry professionals in
web-related applications. The lab imparts knowledge to
faculty from various engineering colleges in the streams of CS,
IS, and IT on Web 2.0 and Rich Internet Applications (RIA), and
enable faculty to guide students on RIA.
EMC2 and MSRIT have entered into a relationship to create the
EMC2 Knowledge Centre. EMC2 provides MSRIT's ISE
Department, access to relevant materials, demos, white
papers, videos and books on Information Storage Management
and 'Storage Area Networks'. The Department offers
Information Storage and Management as one of the electives
for the 6th Semester autonomous B.E. degree program.
INDUSTRY - INSTITUTE
BRIDGING THE GAP BETWEEN INDUSTRY AND ACADEMIA

IBM has established a Centre of Excellence at the MSRIT
campus to provide training to faculty/ students and placement
opportunities to students.
Schneider Electric and MSRIT have set up a Centre of
Excellence in the areas of Industrial Process Automation and
Controls. Industry oriented courses are offered in consultation
with Schneider Electric.
The Department of Telecommunication, MSRIT has entered
into an MOU with Honeywell Technologies Solutions Lab.
Private Ltd, Bangalore to set up a stateof-the-art laboratory for
Condition Monitoring and Testi ng the Conveyor Belt & Idler
system (Test-rig) using embedded computing and wireless
sensor networks for remote monitoring - an effective
test-platform for students in academic projects, interns,
placements and also Faculty Research, Publications, and
developments in the areas of communication, computer,
electrical, civil and mechanical engineering.
ALUMNI
ASSOCIATION
MSRIT's students have always been sought after by the best names in
the industry and occupy responsible positions in various organizations
across the globe. These students continue to have a strong affinity for
the institution long after they graduate and move on, a bond that has
resulted in the creation of a vibrant and growing alumni association.
This group participates actively interacting with present students,
offering scholarships to deserving students and helping in
entrepreneurial efforts, campus placements and guest lectures.
Shri. Tallam Venkatesh, renowned industrialist, and Treasurer,
Karnataka State Cricket Association is the current President of the
MSRIT Alumni Association whose activities include but are not
confined to:
► Scholarship Schemes
Merit and Means Scholarship Program (MMS)
Shri Krishna P. Godasi Scholarship -
by Maganti Foundation
► MSRIT Alumni Association Book Bank
► Project Funding
► Best Project Awards
► Alumni Mentoring Scheme
► Awarding Top Rankers
► Bus Pass Scheme
► Research Fellowship Grant
► 3-D Printing Facility
► Distinguished Alumni Lectures
► Honouring Distinguished Alumni
► Mid day Meals Programs
Sri Sajjan Jindal Managing Director,
JSW Steel Works Limited, Bellari
Dr. Thomas OommenAssociate Professor,
Michigan Technology University
Dr. Karthik SridharanAsst. Professor,
Cornel University
Dr.Sundararajan MadihallyAssociate Professor,
Oklahoma State University
Mr. Girish R.Tanti Director,
Suzlon Energy Limited
Vice Chancellor, Visvesvaraya Dr. Vidyashankar S
Technological University
Sri Mahesh Madhavan CEO Designate,
Bacardi
Distinguished MSRIT Alumni

ENTREPRENEURSHIP DEVELOPMENT CELL (EDC)
Entrepreneurship Development Cell (EDC) was established in July 2003.
EDC is a spring board for the RIT students dedicated to development of multidimensional skills. Creating a forum where we can bring
Interdisciplinary students to bring the heterogeneous culture together. It invites various eminent entrepreneurs to deliver lectures to
educate students about the joys and hardships of entrepreneurship. Guest Lectures, Workshops, Case Study, Group Discussions are
conducted throughout the year to involve students in activities that are essential to be an entrepreneur. E-Cell also actively incubates
start-up ideas by creating required eco system to be an entrepreneur. Entrepreneurship Development Cell basically aims at
recognizing and developing soft skills of individuals. To be a successful entrepreneur it is important for an individual to be a leader, a
team player and a risk taker. He should also be an excellent judge of opportunities and recognize the potential a market can offer. A
good entrepreneur has to analyse the market, plan and implement his ideas for a better society. Keeping these objectives in mind
E-Cell functions to guide the budding Entrepreneurs in their endeavour.
ECO DRIVE - A technology driven startup which aims to provide
modular electric bicycle conversion kits to improve the lifestyle.
STARYA MOBILITY - Produces electric two-wheelers to reduce
pollution and help city dwellers commute via smarter and
healthier ways.
PRADARSHANA - JULY 2022 - All the projects displayed are
having high utility value which can help the society in one or the
other way. There were around 420 exhibits from different
departments.
H.O.P.E or Hitech OMR Pen for Exam - is a product that caters
to students writing entrance exams. The pens have dual
functionality that it can be used a normal pen and that it has a
stamp end that helps colour an OMR bubble in one go.

Facilities offered by EDC at MSRIT for Innovation and Incubation.
► Incubation space of 5000 sq ft for startups.
► Annual budget of 20.0 lacs for seed funding of new ideas and innovation.
► Exposure to all Modern Laboratories and makerspace facilities.
► Provision to access 100mbps internet and computer lab facilities.
► Free mentorship from senior professors of MSRIT.
► Connecting to the Industry diaspora in the silicon city of Bangalore
► Linking startups to the highly functional Alumni of MSRIT for Financial, Technical and Marketing Support.
► Registering and Exposing startups to the annual pradarshana/Investors meet at MSRIT
EDC is a platform to organize entrepreneurial Conclaves/ Ideathon / Hackathon / Competitions, to generate new and innovative
ideas and to encourage start-ups and its ecosystem.
RAMAIAH EVOLUTE
Ramaiah Evolute is the product of a vision to create and
nurture innovative unmatched entrepreneurship skills in the
country. To make this vision tangible, the Ramaiah Group of
Institutions decided to set up a novel innovative start-up
infrastructure centre at its University campus, aided by a
strong mentoring team. The objective was to create a
unique holistic environment to incubate start-ups where
basic to intelligent infrastructure and essential services
along with industry focused mentoring and funding is
available.
Ramaiah Evolute will incidentally be the first
cross-disciplinary start-up ecosystem in the country,
leveraging successfully on the access to 11 diverse
academic disciplines in the campus. Setting up this
ecosystem in a multi-disciplinary campus also precludes
the conventional hurdles faced in innovation such as lack of
holistic domain and application expertise and
understanding of industry from a business, technology and
standards perspective.
Bengaluru, November 9, 2022: The Ramaiah Group of
Institutions, as part of its Ramaiah Evolute program, gave
away the Star Start-up Awards to 18 selected start-ups that
were picked for recognition after a gruelling process of
selection from an extensive number of applicants across
the country. The Star Start-up Award is in line with the
Group’s vision of recognising and encouraging innovation
and coming up with products and processes using next
generation technology while giving a fillip to emerging
entrepreneurs.
The 18 Star Start-ups were recognised for their incredible
innovative spirit and techniques, the clean green technology
solutions offered, the sustainable features of the products and
processes developed and the diverse domains that they
related to where some of them entered into segments that
were direly needed but had so far seen negligible or nil
ventures. Also, there was showcasing of the selected startups
from Evolute Cohorts 1 & 2 to an elite panel of investors.
The 18 selected start-ups received the award certificates of
recognition and citations from Mr M R Jayaram. The Star
Start-up Award is part of the initiative of the Ramaiah Group to
recognise the best cross disciplinary start-ups using high
technology and high level of innovation where the end product
or process has a significant impact on society.
Star Start up Award on Wednesday 9th November 2022
DISC 4 Challenge from iDEX India
The team from M S Ramaiah Institute of
Technology, Bangalore; Dr.Swetha Amit, Dr.
Viswanath Talasila, Mr. P M Premnath,
Department of Electronics & Telecommunication
and Bangalore based Startup company Avgarde
Systems jointly defended a challenge at the 4th
edition of Defence India Startup Challenge (DISC)
on “Reduction of RCS (Radar Cross Section) for
Naval warships” launched by iDEX (Innovations
for Defence Excellence) India and have won the
challenge. They were felicitated by the
Honourable Raksha Mantri, Mr Rajnath Singh,
during the StartUp Manthan event at Aero India in
Bangalore on 5th February 2021.
This year 2022 witnessed the 7th Formula Green Competition,
2022, organized by the Indian Society of New Era Engineers and
held at Aruani grid, Bangalore from 22nd to 25th August 2022,
Team Stier Racing of Ramaiah Institute of Technology,
Bangalore, were placed 1st in Best Design winners Award,
1st in Business Plan winners Award. And Enthusiastic captain
token of gratitude. This competition saw twenty teams from all
over the country vying for the top honours while only seven
teams made the cut to the second round. And among them,
Team Stier Racing from RIT romped home in style. It has to be
noted here that Team Stier Racing were placed champions in
the 2020 edition and the students worked hard to keep the
consistency this year.
TEAM STIER RACING- Formula Green
competition organized by ISNEE
Motorsports Private Limited at Aruani
grid, Bangalore-August-2022
After a year of hard work, continuously improving on the design,
making leaps and jumps in manufacturing, team Velocita Racing
has made it. We are proud to present VRF2. This year, we have
participated in Formula Bharat 2022, which was held in Kari
Motor Speedway during 20th Jan -25th Jan 2022. The event
was organized by Curiosum tech Pvt Ltd governed by FSAE
rules and regulations. Team was Placed 9th Overall
(Combustion Class). This is out of 85 competing team
participating from across the country.
TEAM VELOCITA RACING – Formula
Bharat January- 2022
TEAM QUATLAS -SAE Aero Design West held at USA-April 2022
Team Quatlas is the official Aero modelling team of Ramaiah Institute of
Technology, Bangalore. This Team participates in the SAE Aero-Design
Competition held every year in USA. Our team continues to grow and learn
while showing a positive trend since 2015. The team comprises of
passionate and hard-working students from multiple disciplines of
engineering. Our cohesive team structure facilitates hands-on learning and
inter-departmental coordination. Team Quatlas was ranked Crowned
Overall 9th Place Internationally, 1st among Teams from Asia and 2nd rank
in Technical Design Report world amongst 43 international teams from
countries such as Poland, Canada, Mexico, China etc., in the last year’s
competition.
TEXAS INSTRUMENTS INNOVATION AWARD
Inauguration of Boeing Research and Technology Lab in M. S.
Ramaiah Institute of Technology, Department of Electronics and
Communication, VI semester students Anoop Kulkarni,
Karthikeshwar Varma and Rakshit Ramesh have won the Texas
Instruments Innovation Challenge Chairman’s Award for their
innovative idea to reduce fatalities due to car accidents. The
device uses a radar technology to detect and assess distances so
as to avoid accidents due to vehicle collision. The project was
mentored by Prof. M. S. Srinivas. The award is worth $10,000 and
this year about 11,000 engineering students from across India
participated in this contest with the aim to solve real world
problems and create lasting social impact. Our former President
and an inspiring scientist Dr. A. P. J. Abdul Kalam presented the
awards and speaking on the occasion, he highlighted his vision of
innovation such as the one demonstrated by our students as a key
to national development.h Institute of Technology Premises
TEAM EDHITHA-Unmanned Aerial
Vehicle System (UAVs)- held at USA -
June 2022
TEAM VOLANTE- Mega ATV

held at Pilan held at Goa- May 2022

Team Edhitha, Group of multidisciplinary undergraduate
students of Ramaiah Institute of Technology were judged and
awarded the first Indian team to win the prestigious Student
Unmanned Aerial System (SUAS) competition, in Maryland,
USA, in 2015. This year 2022, Team Editha has been taking part
in SUAS competition organized by Seafarer Chapter., held at
USA between15th -18th June 2022. The team Editha from RIT
won Dawn Jaeger Tenacity Award.
Team Volante has been taking part in Mega ATV competition
organized by Autosports India in Pilan Goa,. The team placed 1st
Place in Drag Race and crowned Overall Runner-up. The team
also taken part in numerous Electric oriented competitions
namely National Kart Racing Championship (NKRC), Indian Solar
Vehicle Championship (ISVC), Bharath Formula Karting powered
by CADD Technologies (e-BFKCT). Team Won the 2nd prize in the
Mud Racing Round of the Solar Electric at Pithampur.

TEAM ALBATROSS-Unmanned Aerial
System
Team Albatross is an interdisciplinary team started by students
of Department of Mechanical engineering. The team has
participated in prestigious competitions like Boeing
Aeromodelling Competition held at IIT Techfest. Team
Albatross is currently preparing to participate in SAE Aero
design challenge 2021.
E-Learning Centre
World class E-Learning Studio is established at Ramaiah
Institute of Technology for recording and live streaming of online
classes simultaneously. The Studio has totally 2 Interactive
panels, 1 Chroma screen, 3 high end PTZ cameras to capture
videos and 2 video monitors that allows the resource person to
see themselves while recording lectures. This space also has a
podium that offers a digital tablet along with a digital stylus for
writing on presentation that is displayed on the Chroma screen.
The studio has a PCR room - programme and technical staff will
watch a series of preview monitors and the output of the vision
mixing desk, which will appear on the ‘Transmission’ monitor for
preparing the final studio output. Desk ‘talkback microphones’
and loudspeakers are available to pass and receive instruction
and guidance between the studio and PCR staff. The studio has a
Green Room.
TEAM CONCEPT 4 - DIY Astrover
Challenge
Team Concept 4 is a dedicated group of multidisciplinary
students from RIT who aim to develop a no-power-consumption
vehicle i.e. Human Powered Rover. In 2021, The team is planning
to take part in Human Exploration Rover Challenge organized by
NASA which has been conducting this competition for more
than 20 years. This Competition will be held at NASA Rocket
and Space Research Center, Huntsville, USA for University and
Higher school students during summer 2021.
Centre of Excellence for Imaging Technologies

The Centre of Excellence for Imaging Technologies (CIT) M S
Ramaiah Institute of Technology was inaugurated on 13th March
2019 by Sri. M R Seetharam, Hon’ble Vice Chairman, GEF and
attended by delegates from IGCAR.
CIT aims at developing competencies in the field of Imaging
Sciences and Technologies in collaboration with IGCAR,
Kalpakkam. The Centre is committed to leveraging and creating
new technologies, cost-effective solutions and methods, to
address the challenges faced by the country.

Schneider Centre of Excellence

Schneider Facility has been established by MSRIT. This facility is
being utilized across Departments of Circuit Branches and
Mechanical Engineering. The modules include, Home and
Building Installation, Home and Building Application, Home
Automation and Building Management system.

Centre for Advanced Materials Technology

A Centre for Advanced Materials Technology is established in
collaboration with BOEING. This will help in interdisciplinary
study and synthesis of advanced materials and polymer
composites. The facility has been created with analytical
facilities such as Non Destructive Ultrasound Setup, TGA/DSC,
Impedance Analyzer, UTM, FTIR, XRD, etc.
Boeing Research and Technology Centre at MSRIT

The Boeing Research and Technology Lab was inaugurated by
Dr. Greg Hyslop, Chief Technical Officer of Boeing, USA at
MSRIT in January 2017. The research facility has
Instrumentation lab, Production system lab, Material lab, NDT
lab and Tear down lab. Boeing research facility provides
Internships to student, collaborative research for faculty,
projects for students & faculty and joint reserach publications.
Centre for Antennas and Radio Frequency Systems

(CARFS)
The Centre for Antennas and Radio Frequency systems
(CARFS) at M S Ramaiah Institute of Technology Bangalore
was inaugurated on 24th March 2021 by Sri. M R Seetharam,
Vice-Chairman, (GEF), Director, RIT. The Centre includes
design, simulation, fabrication and testing of Antenna and RF
devices to indigenously design and develop wireless systems
(including 5G systems). The Centre has state of the art Vector
Network Analyzer from Rohde & Schwarz operating from
100KHz to 40GHz and Anechoic Chamber operating from
700MHz to 40GHz

Centre for Cyber Physical Systems

This Centre of Excellence is envisaged to conduct research
into the design and development of advanced systems
interacting with each other directly and through the Internet. It
is being set up in collaboration with NVIDIA Corporation &
Indian Institute of Science, Bangalore. The Centre has a major
objective:
To initiate collaborative research among different
departments
To set up high-end AI capabilities for use in research and
consultancy activities
Foster research partnership with Industries and research
organizations, leading to collaborative research and
consultancy service.
Centre for Bio & Energy Materials Innovation

The Centre for Bio and Energy Materials Innovation
has been established through research funding from
DST, VGST, VTU, AICTE with a funding of 150 lakh.
This interdisciplinary research center works on
cutting edge research at the interface of physical,
biological, chemical and engineering sciences in
collaboration with external partners from IISc, IITM,
NAL, MSRMC etc. The theme of the centre is to design
functional materials for biomedical, environmental
and energy applications. Some of the key focus areas
include antibacterial nanomaterials for medical
implants, nanomaterials for bio-corrosion inhibition,
nanomaterials for wound healing, nanotoxicology,
electrochemical sensors, novel high performance
energy storage systems etc. The centre offers
hands-on training workshops, short term courses and
provides training and internship to UG/PG students.

On the occasion of the birth centenary of our Founder Dr. M S Ramaiah, as well as the Diamond Jubilee Celebrations of Ramaiah Institute
of Technology, we have conducted CentuRITon, Ramaiah Institute of Technology’s first ever National Level Hackathon organized from
25th-27th Nov, 2022. This hackathon is powered by Major League Hacking (MLH) and Devfolio. Event is technically supported by Unisys,
Dish Network Technologies, IBM, NFThing and IEEE-Computer society Bangalore chapter.
4th International Conference on Circuits, Control, Communication
and Computing I4C-2022, was organized by all the Circuits
departments of RIT from 21st to 23rd December 2022. The
Conference was technically co-sponsored by IEEE Bangalore
Section

MSRIT in association with Boeing India organized 3 days ASME- AM 3D
AERO 2022 Conference from 7th to 9th December 2022. Hon’ble Vice
Chairman, Sri. M R Seetharam, Dr. Melissa Orme, VP Boeing Additive
Manufacturing, Mr. Thomas Costabile, CEO & ED ASME, Dr Om Prakash,
AM 3D Aero 2022 Chair, Dr V K Aatre, ex DG DRDO & Scientific Advisor to
Defence Minister, Ahmed Elsherbini, Mr Steve Chisholm, VP Boeing
Commercial Aircraft, Michael Johnson, Dr. NVR Naidu, Principal, RIT
inaugurated the Conference.
MSRIT conducted the fourth International Conference on Recent
Advances in Engineering Sciences (ICRAES-2022) from 13th to
14th October, 2022. The two-day international conference was
jointly organized by Department of Mechanical Engineering, Civil
Engineering, Chemical Engineering, Biotechnology and Industrial
Engineering & Management with focus on New Generation
Materials.

MSRIT conducted the International Conference on Applied Reserch
in Engineering Sciences (ICARES-2022) from 24th to 25th
November, 2022. The two-day international conference was jointly
organized by Department of Physics, Chemistry, Mathematics &
Humanities. Padmabhushan Prof. P Balaram, Chief Guest
inaugurated the Conference and motivated the participants.
The management has always identified and rewarded individual excellence be it in studies, sports or cultural activities. MSRIT's
students have displayed all round excellence and the performance of the students in the examinations has been way above
average. Students are awarded the 'Founder-Chairman's Award' for Excellence in Academics. The 'Outstanding Graduation
Student of MSRIT Award' is presented to best student taking into consideration the all round performance - academics, sports,
cultural and other extra-curricular activities. There is also a department level 'Best Achiever Award' presented annually to
deserving students.
PERFORMANCE RECOGNITION
Graduation Day - 2022
Presentation by Maj. Gen. Charles Frank Bolden, Jr., Ex-administrator, NASA
on “Engineering Challenges looking to future Space Exploration and Travel” at MSRIT on 7th March 2019
Dr. M S Ramaiah Memorial Lecture, Delivered by Bharat Ratna Dr. C N R Rao FRS on 17th May 2017
The institute is celebrating 60 years (Diamond Jubilee) and the 100th Birth Anniversary of our Founder Chairman
Late. Dr. M S Ramaiah this year. A Spectacular and a grand Inaugural Function for Diamond Jubilee Celebrations was
held on the 16th October 2022.

The Hon’ble Minister of Parliamentary Affairs, Coal & Mines GoI inaugurated the celebrations. He appreciated that
the founder Chairman and GEF have contributed immensely to the society by establishing many outstanding
educational institutions which are engaged in imparting quality technical education to millions of students.

Dr. Ashwath Narayan C N, Hon’ble Minister of Higher Education, GoK released the documentary and said the
sustained growth of society is possible only through quality education. Ramaiah institutions have provided good
quality technical education to many students across the globe. He also said that the students need to utilize the
facilities & equip themselves with employable skills for the future challenges.

DIAMOND JUBILEE INAUGURATION
His excellency Hon’ble Governor of Karnataka participated virtually and delivered the presidential address. In his
address he highlighted the need of sincere efforts to nurture the talents of today’s youth. He congratulated & wished
the institution for its future endeavors.

Hon’ble Chief Minister of Karnataka Sri. Basavaraj S Bommai in a video message hoped that the tradition of giving
back to the society at M S Ramaiah continues while Dharmendra Pradhan, Union Minister for Education, in a note said,
“It is imperative that our centers of higher learning lay great focus on high-end innovation & research in science &
technology”.
The function was attended by distinguished members from premier educational institutions, industry, alumni, and
heads of sister institutions. Hon’ble Chairman, Vice Chairman, Secretary, Dr. V K Aatre, Dr. H P Khincha & Dr. J N
Reddy participated in the function.

M S Ramaiah Nagar
MSRIT Post
Bangalore 560 054
T 080 2360 3122 / 8445 / 2360 0822 Extn. 338
T 080 2360 7902 (Admission)
E admn@msrit.edu/principal@msrit.edu
W http://www.msrit.edu
FOR FURTHER DETAILS CONTACT ON

VARIOUS INSTITUTIONS / CENTRES UNDER GOKULA EDUCATION FOUNDATION (GEF)

Ramaiah Vidyaniketan

Ramaiah High School

Ramaiah Institute of Technology

Ramaiah Polytechnic

Ramaiah College of Arts, Science & Commerce

Ramaiah Composite Pre-University College

Ramaiah College of Education

Ramaiah Institute of Management

Ramaiah College of Law

Ramaiah Medical College

Ramaiah Institute of Physical Medicine & Rehabilitation (Physiotherapy)

Ramaiah International Medical School
Ramaiah Institute of Nursing Education & Research Ramaiah INDIC Speciality Ayurveda

Ramaiah Medical College Hospital

Ramaiah Memorial Hospital

Ramaiah Advanced Testing Laboratory

Ramaiah Clinical Research Centre
Ramaiah Harsha Hospital
Ramaiah Leena Hospital
Ramaiah Neha Prakash Hospital
Ramaiah Clinic
Ramaiah Public Policy Centre
Ramaiah Innovation Centre for Healthcare Technologies
Ramaiah Sunshine Ayurveda Centre, Penang, Malaysia
Ramaiah Officers IAS Academy
Ramaiah Quality Assurance Cell
Ramaiah International Centre for Public Health Innovation
Ramaiah University of Applied Sciences
Member of Study India
Accredited by
NAAC with Grade A

- 21 Programs
  Accredited
  This is a offline tool, your data stays locally and is not send to any server!
  Feedback & Bug Reports

# Ramaiah Institute of Technology

# B.E. in Computer Science and Engineering

## An exclusive Guide by

**Disclaimer:** This PDF is auto-generated based on the information available on Shiksha as on 03-Mar-2025.

## Overview

Duration **4 ye ars**
Course Level **UG De gre e**
Mode of Course **Full T im e**

###### Total Tuition Fees INR 10 .4 6 Lakh

###### Average package INR 7 .6 6 Lakh

Seat breakup **19 8**
Type of University **Privat e ,Aut o no m o us**

## Fees

##### Fee components Amount (4 years)

###### Tuition Fees INR 10.46 Lakh

## Total fee INR 10.46 Lakh

_\*These are based on information available on various sources. Latest values may differ._

## Rankings

###### At the UG level, MSRIT provides a 4 years B.E. in Computer Science and Engineering

###### course to the students. To get admission to this course, aspiring students must meet

###### the minimum eligibility requirements - 45.0% in 12th. The total cost for this course isINR 1045908. This course offers admission to 198 students. Check out other courses

###### available under B.E. / B.Tech at MSRIT.

```
The mentioned fee is as per Consortium ofMedical, Engineering and Dental Colleges of
Karnataka (COMEDK).
```

##### Rank Rank Publisher

### # 5 India T o day 2024

### # 6 Out lo o k 2024

### # 75 NIRF 2024

## Curriculum

### Latest curriculum for B.E. in Computer Science and Engineering at

### MSRIT can be downloaded from the below link. The curriculum PDF

### has semester wise course structure, electives and detailed course

### content. You can also check course curriculum of other

### specializations offered in B.E. / B.Tech at MSRIT

### Download Curriculum

## Scholarships

###### Institute offers various scholarships.

###### a) Post Metric Scholarship to SC/STs

###### b) Fee-reimbursements to SC/STsc) Fee- concession to Category-l, II, and III

###### d)Extra boarding and lodging allowance to Category-I, II, & IIIe) Defense Scholarship

###### f) MSRIT Alumni Scholarship

## Placements

##### Particulars Statistics (2023)

```
Average Salary INR 7.66 Lakh
Highest Salary INR 48.00 Lakh
Median Salary INR 8.00 Lakh
% Batch placed 95
```

###### T op Recruiters for MSRIT

```
99acres.com
Adobe
Cisco Systems
HDFC Bank
Hindustan Unilever
HSBC
IBM
Infosys
L&T Ecc
Microsoft
MU Sigma
Philips India
Qualcomm
```

```
Radio Mirchi
Robert Bosch
Virtusa
volvo
```


###### Requirements for 12th grade

### 45%

###### COMEDK UGET

### N/A

###### KCET

### N/A

###### Candidate must have passed 10+2 or equivalent examination with the mentioned

###### marks in Physics, Chemistry and Mathematics and should have passed these

###### subjects individually with English as a compulsory subject from recognized byState/Central Government. Physics and Mathematics are compulsory subjects

###### along with Chemistry or Bio Technology or Biology or Computer Science orElectronics as one of the optional subjects. Candidates belonging to OBC, SC

###### and ST must be domicile of Karnataka state.

###### Other eligibility criteria

### OBC

###### Requirements for 12th grade

### 40%

###### COMEDK UGET

### N/A

###### KCET

### N/A

###### Other eligibility criteria

### SC

###### Requirements for 12th grade

### 40%

###### Candidates passed Diploma are not eligible to take the Entrance Test as there

###### are no lateral entry admissions.

###### Candidate must have passed 10+2 or equivalent examination with the mentioned

###### marks in Physics, Chemistry and Mathematics and should have passed thesesubjects individually with English as a compulsory subject from recognized by

###### State/Central Government. Physics and Mathematics are compulsory subjects

###### along with Chemistry or Bio Technology or Biology or Computer Science orElectronics as one of the optional subjects. Candidates belonging to OBC, SC

###### and ST must be domicile of Karnataka state.

###### Candidates passed Diploma are not eligible to take the Entrance Test as there

###### are no lateral entry admissions.

### 40%

###### COMEDK UGET

### N/A

###### KCET

### N/A

###### Other eligibility criteria

### ST

###### Requirements for 12th grade

### 40%

###### COMEDK UGET

###### Candidate must have passed 10+2 or equivalent examination with the mentionedmarks in Physics, Chemistry and Mathematics and should have passed these

###### subjects individually with English as a compulsory subject from recognized by

###### State/Central Government. Physics and Mathematics are compulsory subjectsalong with Chemistry or Bio Technology or Biology or Computer Science or

###### Electronics as one of the optional subjects. Candidates belonging to OBC, SCand ST must be domicile of Karnataka state.

###### Candidates passed Diploma are not eligible to take the Entrance Test as thereare no lateral entry admissions.

###### Candidate must have passed 10+2 or equivalent examination with the mentionedmarks in Physics, Chemistry and Mathematics and should have passed these

###### subjects individually with English as a compulsory subject from recognized byState/Central Government. Physics and Mathematics are compulsory subjects

###### along with Chemistry or Bio Technology or Biology or Computer Science or

###### Electronics as one of the optional subjects. Candidates belonging to OBC, SCand ST must be domicile of Karnataka state.

## Admission Process

### Counselling

###### Admission is through counselling based on the rank obtained in KarnatakaCommon Entrance Test (KCET) or Consortium of Medical Engineering and Dental

###### Colleges of Karnataka (COMEDK).

## Important Dates

### N/A

###### KCET

### N/A

###### Other eligibility criteria

###### Candidates passed Diploma are not eligible to take the Entrance Test as thereare no lateral entry admissions.



MSRIT COLLEGE KCET CUTOFF - GENERAL:
| Course                                                              | 2022 | 2023   | 2024 |
|---------------------------------------------------------------------|--------|--------|--------|
| B.E. in Civil Engineering                                           | 46447 | 35217 | 33103 |
| B.E. in Mechanical Engineering                                      | 35226 | 27245 | 24096 |
| B.E. in Electronics and Communication Engineering                   | 3985 | 4094 | 4564 |
| B.E. in Industrial Engineering and Management                       | 43992 | 55277 | 37643 |
| B.E. in Electronics and Telecommunication Engineering               | 8977 | 7914 | 6551 |
| B.E. in Biotechnology Engineering                                   | 13775 | 15077 | 16766 |
| B.E. in Electrical and Electronics Engineering                      | 9893 | 7763 | 9339 |
| B.E. in Chemical Engineering                                        | 30946 | 26332 | 27194 |
| B.E. in Computer Science and Engineering                            | 1125 | 1171 | 1626 |
| B.E. in Medical Electronics Engineering                             | 23145 | 37624 | 37014 |
| B.E. in Information Science and Engineering                         | 2265 | 1995 | 3105 |
| B.E. in Electronics and Instrumentation Engineering                 | 12622 | 10794 | 10851 |
| B.E. in Artificial Intelligence and Data Science                    | 3239 | 2860 | 4371 |

MSRIT COLLEGE KCET CUTOFF - ST:

| Course                                                           | 2022   | 2023   | 2024   |
| ---------------------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Civil Engineering                                        | 80368  | 74724  | 47261  |
| B.E. in Mechanical Engineering                                   | 75164  | 105590 | 102510 |
| B.E. in Electronics and Communication Engineering                | 23597  | 26082  | 29184  |
| B.E. in Industrial Engineering and Management                    | 114110 | 117247 | 150686 |
| B.E. in Electronics and Telecommunication Engineering            | 50853  | 64345  | 52810  |
| B.E. in Biotechnology Engineering                                | 33641  | 52075  | 78737  |
| B.E. in Electrical and Electronics Engineering                   | 45030  | 46868  | 49051  |
| B.E. in Chemical Engineering                                     | 73921  | 153687 | 83266  |
| B.E. in Computer Science and Engineering                         | 6339   | 12563  | 14053  |
| B.E. in Medical Electronics Engineering                          | 111724 | 157206 | 116894 |
| B.E. in Information Science and Engineering                      | 14836  | 18851  | 26964  |
| B.E. in Electronics and Instrumentation Engineering              | 68159  | 81323  | 68718  |
| Bachelor of Architecture (B.Arch.)                               | – / –  | – / –  | 410    |
| B.E. in Artificial Intelligence and Data Science                 | 15859  | 25771  | 25646  |
| B.E. in Artificial Intelligence and Machine Learning             | – / –  | – / –  | 27283  |
| B.E. in Computer Science and Engineering (Cyber Security)        | – / –  | – / –  | 28625  |
| B.E. in Computer Science and Engineering (AI & Machine Learning) | – / –  | – / –  | 19046  |
| B.Tech. in Aerospace Engineering                                 | – / –  | – / –  | 47947  |


MSRIT COLLEGE KCET CUTOFF- SC:

| Course                                                                                | 2022   | 2023   | 2024   |
| ------------------------------------------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Civil Engineering                                                             | 80368  | 74724  | 47261  |
| B.E. in Mechanical Engineering                                                        | 75164  | 105590 | 102510 |
| B.E. in Electronics and Communication Engineering                                     | 23597  | 26082  | 29184  |
| B.E. in Industrial Engineering and Management                                         | 114110 | 117247 | 150686 |
| B.E. in Electronics and Telecommunication Engineering                                 | 50853  | 64345  | 52810  |
| B.E. in Biotechnology Engineering                                                     | 33641  | 52075  | 78737  |
| B.E. in Electrical and Electronics Engineering                                        | 45030  | 46868  | 49051  |
| B.E. in Chemical Engineering                                                          | 73921  | 153687 | 83266  |
| B.E. in Computer Science and Engineering                                              | 6339   | 12563  | 14053  |
| B.E. in Medical Electronics Engineering                                               | 111724 | 157206 | 116894 |
| B.E. in Information Science and Engineering                                           | 14836  | 18851  | 26964  |
| B.E. in Electronics and Instrumentation Engineering                                   | 68159  | 81323  | 68718  |
| Bachelor of Architecture (B.Arch.)                                                    | – / –  | – / –  | 410    |
| B.E. in Artificial Intelligence and Data Science                                      | 15859  | 25771  | 25646  |
| B.E. in Artificial Intelligence and Machine Learning                                  | – / –  | – / –  | 27283  |
| B.E. in Computer Science and Engineering (Cyber Security)                             | – / –  | – / –  | 28625  |
| B.E. in Computer Science and Engineering (Artificial Intelligence & Machine Learning) | – / –  | – / –  | 19046  |
| B.Tech. in Aerospace Engineering                                                      | – / –  | – / –  | 47947  |


MSRIT COLLEGE KCET CUTOFF - OBC:

| Course                                                | 2022  | 2023  | 2024  |
| ----------------------------------------------------- | ----- | ----- | ----- |
| B.E. in Civil Engineering                             | 46447 | 35217 | 33103 |
| B.E. in Mechanical Engineering                        | 35226 | 27245 | 24096 |
| B.E. in Electronics and Communication Engineering     | 3985  | 4094  | 4564  |
| B.E. in Industrial Engineering and Management         | 43992 | 55277 | 37643 |
| B.E. in Electronics and Telecommunication Engineering | 8977  | 7914  | 6551  |
| B.E. in Biotechnology Engineering                     | 13775 | 15077 | 16766 |
| B.E. in Electrical and Electronics Engineering        | 9893  | 7763  | 9339  |
| B.E. in Chemical Engineering                          | 30946 | 26332 | 27194 |
| B.E. in Computer Science and Engineering              | 1125  | 1171  | 1626  |
| B.E. in Medical Electronics Engineering               | 23145 | 37624 | 37014 |
| B.E. in Information Science and Engineering           | 2265  | 1995  | 3105  |
| B.E. in Electronics and Instrumentation Engineering   | 12622 | 10794 | 10851 |
| B.E. in Artificial Intelligence and Data Science      | 3239  | 2860  | 4371  |
