## #College Info for Engineering Colleges

#College 1: BMS College of Engineering

##BMS College Overview Duration **4 years**

Course Level **UG Degree**

Mode of Course **Full Time**

Total Tuition Fees INR **18.00 Lakh**

Type of Univers ity **Private,Autonomous**

##BMS College Scholarships Scholarship 1 The institute pro vides vario us go
vernment scho larships like :

1. DSW SC/ST scholarship
2. DSW SC/ST freeship,
3. LIG freeship
4. CAT I freeship
5. DBCM scholarship To get more detailed information regarding Scholarships,
   please visit: https://bmsce.ac.in/assets/f iles/scho larship2.pdf

## BMS College Placements

Particulars Statistics (2023) Median Salary INR 9 .0 0 Lakh **Top Recruiters for
BMS College of Engineering** Accenture Adecco Group Adobe Airtel Amazon Ericsson
India NOKIA Oracle PayTM Philips India

## Entry Requirements

1. General Requirements for 12th grade: 45% COMEDK UGET: According to Cutoff
   KCET: According to Cutoff

2. OBC Candidate must have passed 10+2 o r equivalent examinatio n with the
   mentio ned marks in Physics, Chemistry and Mathematics and sho uld have
   passed these subjects individually with English as a co mpulso ry subject f
   ro m reco gnized by State/Central Go vernment. Physics and Mathematics are co
   mpulso ry subjects alo ng with Chemistry o r Bio T echno lo gy o r Bio lo gy
   o r Co mputer Science o r Electro nics as o ne o f the o ptio nal subjects.
   Candidates belo nging to OBC, SC and ST must be do micile o f Karnataka
   state. Candidates passed Diploma are not eligible to take the Entrance Test
   as there are no lateral entry admissions. 12 statndard: 40% COMEDK UGET
   According to Cutoff KCET According to Cutoff

3. SC Requirements for 12th grade: 40% Candidate must have passed 10+2 or
   equivalent examination with the mentioned marks in Physics, Chemistry and
   Mathematics and should have passed these subjects individually with English
   as a co mpulso ry subject f ro m reco gnized by State/Central Government.
   Physics and Mathematics are compulsory subjects alo ng with Chemistry o r Bio
   T echno lo gy o r Biology or Computer Science or Electro nics as o ne o f the
   o ptio nal subjects. Candidates belo nging to OBC, SC and ST must be domicile
   of Karnataka state. Candidates passed Diplo ma are no t eligible to take the
   Entrance T est as there are no lateral entry admissio ns. COMEDK UGET: As per
   Cutoff KCET: As per Cutoff

4. ST

   Requirements for 12th grade: 40% COMEDK UGET: As per Cutoff KCET: As per
   Cutoff Candidates passed Diploma are not eligible to take the Entrance Test
   as there are no lateral entry admissio ns.

   Candidate must have passed 10+2 o r equivalent examination with the mentio
   ned marks in Physics, Chemistry and Mathematics and should have passed these
   subjects individually with English as a co mpulsory subject f ro m reco
   gnized by State/Central Go vernment. Physics and Mathematics are co mpulso ry
   subjects alo ng with Chemistry o r Bio T echno lo gy o r Biology o r Computer
   Science or Electronics as one of the optional subjects. Candidates belonging
   to OBC, SC and ST must be domicile of Karnataka state.

##BMS KCET CUTOFF - GENERAL

| Course                                              | 2022  | 2023  | 2024  |
| --------------------------------------------------- | ----- | ----- | ----- |
| B.E. in Electrical and Electronics Engineering      | 12295 | 11201 | 9150  |
| B.E. in Computer Science and Engineering            | 1075  | 1027  | 2950  |
| B.E. in Mechanical Engineering                      | 35080 | 20448 | 22923 |
| B.E. in Chemical Engineering                        | 35878 | 20694 | 21507 |
| B.E. in Civil Engineering                           | 54131 | 40554 | 49010 |
| B.E. in Biotechnology                               | 15519 | 14259 | 17103 |
| B.E. in Industrial Engineering and Management       | 48917 | 43572 | 40082 |
| B.E. in Electronics and Communication Engineering   | 4349  | 2392  | 5149  |
| B.E. in Aerospace Engineering                       | 7746  | 8163  | 9023  |
| B.E in Artificial Intelligence and Machine Learning | 2536  | 2399  | 4580  |

##BMS KCET CUTOFF - SC

| Course                                              | 2022   | 2023   | 2024   |
| --------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Electrical and Electronics Engineering      | 35227  | 54973  | 50740  |
| B.E. in Computer Science and Engineering            | 8512   | 13450  | 23700  |
| B.E. in Mechanical Engineering                      | 93746  | 102741 | 118785 |
| B.E. in Chemical Engineering                        | 92153  | 157451 | 127227 |
| B.E. in Civil Engineering                           | 78650  | 81416  | 97330  |
| B.E. in Biotechnology                               | 46185  | 49585  | 54918  |
| B.E. in Industrial Engineering and Management       | 136531 | 150342 | 151846 |
| B.E. in Electronics and Communication Engineering   | 29092  | 24731  | 43206  |
| B.E. in Aerospace Engineering                       | 33558  | 38975  | 48035  |
| B.E in Artificial Intelligence and Machine Learning | 21248  | 26254  | 31264  |

##BMS KCET CUTOFF - ST

| Course                                              | 2022   | 2023   | 2024   |
| --------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Electrical and Electronics Engineering      | 24436  | 51371  | 75397  |
| B.E. in Computer Science and Engineering            | 3898   | 14210  | 23627  |
| B.E. in Mechanical Engineering                      | 83659  | 131233 | 143009 |
| B.E. in Chemical Engineering                        | – / –  | 130077 | 84349  |
| B.E. in Civil Engineering                           | 77846  | 79398  | 94563  |
| B.E. in Biotechnology                               | – / –  | 56024  | 54406  |
| B.E. in Industrial Engineering and Management       | 112876 | 180250 | 173421 |
| B.E. in Electronics and Communication Engineering   | 20379  | 30602  | 44826  |
| B.E. in Aerospace Engineering                       | 28345  | 62903  | 27053  |
| B.E in Artificial Intelligence and Machine Learning | 12580  | 32443  | 31284  |

##BMS KCET CUTOFF - OBC

| Course                                              | 2022   | 2023   | 2024   |
| --------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Electrical and Electronics Engineering      | 24436  | 51371  | 75397  |
| B.E. in Computer Science and Engineering            | 3898   | 14210  | 23627  |
| B.E. in Mechanical Engineering                      | 83659  | 131233 | 143009 |
| B.E. in Chemical Engineering                        | – / –  | 130077 | 84349  |
| B.E. in Civil Engineering                           | 77846  | 79398  | 94563  |
| B.E. in Biotechnology                               | – / –  | 56024  | 54406  |
| B.E. in Industrial Engineering and Management       | 112876 | 180250 | 173421 |
| B.E. in Electronics and Communication Engineering   | 20379  | 30602  | 44826  |
| B.E. in Aerospace Engineering                       | 28345  | 62903  | 27053  |
| B.E in Artificial Intelligence and Machine Learning | 12580  | 32443  | 31284  |

---

#College 2: PES University

## PES University Overview

Duration **4 years**

Course Level **UG Degree**

Mode of Course **Full Time**

Total Tuition Fees INR **15.20 Lakh**

Average package INR **12.00 Lakh**

Seat breakup **540**

Type of University **Private**

## PES University Fees

**PES University** provides UG programmes for the duration of 4 years. The PES
University has been ranked ** #101-150** in the NIRF 2024 under the Engineering
category. The total tuition fee for the B.Tech. in Electronics and Communication
Engineering programme is around **INR 15,20,000**. Additionally, students must
also pay a hostel fee of **INR 2,31,000** , along with a one-time admission fee
of **INR 10,000**. The total seat intake for the B.Tech. in Electronics and
Communication Engineering course is 540. Students can check PES University
B.Tech. in Electronics and Communication Engineering details in the table below:

The PES University B.Tech. in Electronics and Communication Engineering fees are
inclusive of various components, such as examination, medical, seat rent, etc.
The tuition fee may subject to vary depending on the category a student belongs
to. Refer to the table below for a detailed break-up of PES University B.Tech.
in Electronics and Communication Engineering fees:

##### Fee components Amount (4 years)

Tuition Fees INR 15.20 Lakh Hostel Fees INR 2.31 Lakh One-time Payment INR 10,
Total fee: INR 17.61 Lakh

These are based on information available on various sources. Latest values may
differ.

## Scholarships

Rural Scholarships: PES University offers free engineering education for select
number of students coming from rural background every year. For more details
please visit the URL https://pes.edu/scholarships/

## Placements

##### Particulars Statistics (2024)

Average Salary INR 12.00 Lakh Highest Salary INR 68.00 Lakh Median Salary INR
8.00 Lakh

```

**Top Recruiters for PES University**
Amazon
Cisco Systems
Cognizant
Deloitte
Facebook
Flipkart
Google
HP
IBM
Infosys
Intel
Linkedin
Microsoft
SAP
Tata Power
Tata Technologies
tesco
Wipro

## Entry Requirements

### 1. General

    Requirements for 12th grade:45%
    JEE Main: As per Cutoff
    KCET:As per Cutoff
    PESSAT: As per Cutoff
    Other Criteria:
    Candidate must have passed in 2nd PUC / 12th Std / equivalent exam with Physics
    and Mathematics as compulsory subjects along with Chemistry / Bio- Technology /
    Biology / Electronics / Computer Science as optional subjects with English as
    one of the languages of study and obtained a minimum of mentioned marks in
    aggregate in the optional subjects in the qualifying examination, from a
    recognized Institute/ board. (40% of marksin qualifying examination is required
    for Cat-1, OBC (2A, 2B, 3A and 3B category candidates)). Result awaited
    candidates can also apply. NOTE: The SC / ST/Category-I / 2A, 2B, 3A and 3B and
    other eligibility criteria is applicable to Karnataka candidates who are
    eligible to claim eligibility for Government seats under clauses (a), (b), (f),
    (h), (j), (k) (l) and (o) and the same is not applicable to eligibility clauses
    (c), (d), (e), (g), (i), (m) and (n) to claim Government Seats and Government
    quota seats as per proviso of rule 9 (2) of CET-2006 Admission Rules.

    Candidate should be a citizen of India. NOTE: The candidates who have passed the
    qualifying examination other than the universities listed in the notification at
    VTU Website are NOT eligible and candidates who have passed from Karnataka State
    Open University (KSOU) are also NOT eligible.

### 2. OBC

```

Requirements for 12th grade: 40% JEE Main: As per Cutoff KCET:As per Cutoff
PESSAT: As per Cutoff Other Criteria: Candidate must have passed in 2nd PUC /
12th Std / equivalent exam with Physics and Mathematics as compulsory subjects
along with Chemistry / Bio- Technology / Biology / Electronics / Computer
Science as optional subjects with English as one of the languages of study and
obtained a minimum of mentioned marks in aggregate in the optional subjects in
the qualifying examination, from a recognized Institute/ board. (40% of marksin
qualifying examination is required for Cat-1, OBC (2A, 2B, 3A and 3B category
candidates)). Result awaited candidates can also apply. NOTE: The SC /
ST/Category-I / 2A, 2B, 3A and 3B and other eligibility criteria is applicable
to Karnataka candidates who are eligible to claim eligibility for Government
seats under clauses (a), (b), (f), (h), (j), (k) (l) and (o) and the same is not
applicable to eligibility clauses (c), (d), (e), (g), (i), (m) and (n) to claim
Government Seats and Government quota seats as per proviso of rule 9 (2) of
CET-2006 Admission Rules. Candidate should be a citizen of India. NOTE: The
candidates who have passed the qualifying examination other than the
universities listed in the notification at

### 3. SC

    Requirements for 12th grade: 40%
    JEE Main: As per Cutoff
    KCET:As per Cutoff
    PESSAT: As per Cutoff
    Other Criteria:
    VTU Website are NOT eligible and candidates who have passed from Karnataka
    State Open University (KSOU) are also NOT eligible.
    Candidate must have passed in 2nd PUC / 12th Std / equivalent exam with
    Physics and Mathematics as compulsory subjects along with Chemistry / Bio-
    Technology / Biology / Electronics / Computer Science as optional subjects with
    English as one of the languages of study and obtained a minimum of mentioned
    marks in aggregate in the optional subjects in the qualifying examination, from a
    recognized Institute/ board. (40% of marksin qualifying examination is required
    for Cat-1, OBC (2A, 2B, 3A and 3B category candidates)). Result awaited
    candidates can also apply. NOTE: The SC / ST/Category-I / 2A, 2B, 3A and 3B
    and other eligibility criteria is applicable to Karnataka candidates who are eligible
    to claim eligibility for Government seats under clauses (a), (b), (f), (h), (j), (k) (l)
    and (o) and the same is not applicable to eligibility clauses (c), (d), (e), (g), (i),
    (m) and (n) to claim Government Seats and Government quota seats as per
    proviso of rule 9 (2) of CET-2006 Admission Rules.

### 4. ST

    Requirements for 12th grade: 40%
    JEE Main: As per Cutoff
    KCET:As per Cutoff
    PESSAT: As per Cutoff
    Other Criteria:
    Candidate should be a citizen of India. NOTE: The candidates who have passed
    the qualifying examination other than the universities listed in the notification at
    VTU Website are NOT eligible and candidates who have passed from Karnataka
    State Open University (KSOU) are also NOT eligible.
    Candidate must have passed in 2nd PUC / 12th Std / equivalent exam with
    Physics and Mathematics as compulsory subjects along with Chemistry / Bio-
    Technology / Biology / Electronics / Computer Science as optional subjects with
    English as one of the languages of study and obtained a minimum of mentioned
    marks in aggregate in the optional subjects in the qualifying examination, from a
    recognized Institute/ board. (40% of marksin qualifying examination is required
    for Cat-1, OBC (2A, 2B, 3A and 3B category candidates)). Result awaited
    candidates can also apply. NOTE: The SC / ST/Category-I / 2A, 2B, 3A and 3B
    and other eligibility criteria is applicable to Karnataka candidates who are eligible
    to claim eligibility for Government seats under clauses (a), (b), (f), (h), (j), (k) (l)
    and (o) and the same is not applicable to eligibility clauses (c), (d), (e), (g), (i),
    (m) and (n) to claim Government Seats and Government quota seats as per
    proviso of rule 9 (2) of CET-2006 Admission Rules.

## PES College KCET Cutoffs

### PES COLLEGE KCET CUTOFF - GENERAL:

| Course                                                  | 2022  | 2023  | 2024   |
| ------------------------------------------------------- | ----- | ----- | ------ |
| B.Tech. in Mechanical Engineering                       | 9055  | 26736 | 19130  |
| B.Tech. in Electronics and Communication Engineering    | 16146 | 3803  | 8391   |
| B.Tech. in Electrical and Electronics Engineering       | 1698  | 6836  | 6613   |
| B.Tech. in Computer Science and Engineering             | 94746 | 1124  | 5241   |
| B.Tech. in Biotechnology                                | 9600  | 14206 | 13805  |
| Bachelor of Architecture (B.Arch.)                      | – / – | – / – | 195    |
| Bachelor of Pharmacy (B.Pharm.)                         | 32051 | – / – | 41351  |
| Doctor of Pharmacy (Pharm.D.)                           | 16775 | – / – | – / –  |
| B.Sc. in Nursing                                        | – / – | – / – | 128600 |
| B.Tech. in Artificial Intelligence and Machine Learning | 6644  | 1765  | 2641   |

### PES COLLEGE KCET CUTOFF - SC:

| Course                                                                                     | 2022   | 2023  | 2024   |
| ------------------------------------------------------------------------------------------ | ------ | ----- | ------ |
| B.Tech. in Mechanical Engineering                                                          | 37349  | 49447 | 95309  |
| B.Tech. in Electronics and Communication Engineering                                       | 86964  | 42845 | 62422  |
| B.Tech. in Electrical and Electronics Engineering                                          | 21917  | 56497 | 59225  |
| B.Tech. in Computer Science and Engineering                                                | 138274 | 18065 | 56705  |
| B.Tech. in Biotechnology                                                                   | 38789  | 86894 | 69650  |
| Bachelor of Pharmacy (B.Pharm.)                                                            | 32051  | – / – | 70489  |
| Doctor of Pharmacy (Pharm.D.)                                                              | 16775  | – / – | – / –  |
| B.Sc. in Nursing                                                                           | – / –  | – / – | 155074 |
| B.Tech. in Artificial Intelligence and Machine Learning                                    | 28137  | 33639 | 30341  |
| B.Tech. in Computer Science and Engineering (Artificial Intelligence and Machine Learning) | – / –  | – / – | 54289  |

### PES COLLEGE KCET CUTOFF - ST

| Course                                                  | 2022  | 2023   | 2024   |
| ------------------------------------------------------- | ----- | ------ | ------ |
| B.Tech. in Mechanical Engineering                       | 78185 | 113485 | 74760  |
| B.Tech. in Electronics and Communication Engineering    | 36160 | 48914  | 80979  |
| B.Tech. in Electrical and Electronics Engineering       | 11255 | 71453  | 74955  |
| B.Tech. in Computer Science and Engineering             | 99736 | 18416  | 56169  |
| B.Tech. in Biotechnology                                | – / – | 138596 | 18040  |
| Bachelor of Pharmacy (B.Pharm.)                         | 32051 | – / –  | 58662  |
| Doctor of Pharmacy (Pharm.D.)                           | 16775 | – / –  | – / –  |
| B.Sc. in Nursing                                        | – / – | – / –  | 147460 |
| B.Tech. in Artificial Intelligence and Machine Learning | 15551 | 43763  | 33100  |

### KCET CUTOFF - OBC:

| Course                                                  | 2022  | 2023  | 2024   |
| ------------------------------------------------------- | ----- | ----- | ------ |
| B.Tech. in Mechanical Engineering                       | 9055  | 26736 | 19130  |
| B.Tech. in Electronics and Communication Engineering    | 16146 | 3803  | 8391   |
| B.Tech. in Electrical and Electronics Engineering       | 1698  | 6836  | 6613   |
| B.Tech. in Computer Science and Engineering             | 94746 | 1124  | 5241   |
| B.Tech. in Biotechnology                                | 9600  | 14206 | 13805  |
| Bachelor of Architecture (B.Arch.)                      | – / – | – / – | 195    |
| Bachelor of Pharmacy (B.Pharm.)                         | 32051 | – / – | 41351  |
| Doctor of Pharmacy (Pharm.D.)                           | 16775 | – / – | – / –  |
| B.Sc. in Nursing                                        | – / – | – / – | 128600 |
| B.Tech. in Artificial Intelligence and Machine Learning | 6644  | 1765  | 2641   |

---

# College 3: MSRIT College

## Overview

    Duration **4 years**
    Course Level **UG Degree**
    Mode of Course **Full Time**

    ###### Total Tuition Fees INR 10 .46 Lakh

    ###### Average package INR 7 .66 Lakh

    Seat breakup **198**
    Type of University **Private ,Autonomous**

## Fees

    ##### Fee components Amount (4 years)

    ###### Tuition Fees INR 10.46 Lakh

    ## Total fee INR 10.46 Lakh

_\*These are based on information available on various sources. Latest values
may differ._

## MSRIT College Rankings

    At the UG level, MSRIT provides a 4 years B.E. Course
    course to the students. To get admission to this course, aspiring students must meet
    the minimum eligibility requirements - 45.0% in 12th. The total cost for this course isINR 1045908. This course offers admission to 198 students. Check out other courses
    available under B.E. / B.Tech at MSRIT.
    Rank 5 India To day 2024
    Rank 6 Outlook 2024
    Rank 75 NIRF 2024

## MSRIT College Scholarships

    ###### Institute offers various scholarships.

    ###### 1. Post Metric Scholarship to SC/STs

    ###### 2. Fee-reimbursements to SC/STsc) Fee- concession to Category-l, II, and III

    ###### 3. Extra boarding and lodging allowance to Category-I, II, & IIIe) Defense Scholarship

    ###### 4.  MSRIT Alumni Scholarship

## MSRIT College Placements Details

    ##### Particulars Statistics (2023)
    Average Salary INR 7.66 Lakh
    Highest Salary INR 48.00 Lakh
    Median Salary INR 8.00 Lakh
    % of Batch placed 95 for CSE and ISE Departments

    Top Recruiters for MSRIT:
    99acres.com
    Adobe
    Cisco Systems
    HDFC Bank
    Hindustan Unilever
    HSBC
    IBM
    Infosys
    L&T Ecc
    Microsoft
    MU Sigma
    Philips India
    Qualcomm
    Radio Mirchi
    Robert Bosch
    Virtusa
    volvo

## MSRIT College Admission Criteria:

### 1. General

    Requirements for 12th grade: 45%
    COMEDK UGET: As per Cutoff
    KCET: As per Cutoff
    Other Criteria:
    Candidate must have passed 10+2 or equivalent examination with the mentioned
    marks in Physics, Chemistry and Mathematics and should have passed these
    subjects individually with English as a compulsory subject from recognized byState/Central Government. Physics and Mathematics are compulsory subjects
    along with Chemistry or Bio Technology or Biology or Computer Science orElectronics as one of the optional subjects. Candidates belonging to OBC, SC
    and ST must be domicile of Karnataka state.

### 2. OBC

    Requirements for 12th grade: 45%
    COMEDK UGET: As per Cutoff or Not Needed
    KCET: As per Cutoff or Not needed

### 3. SC

    Requirements for 12th grade: 40%
    KCET: As per Cutoff or not needed
    ComedK: As per Cutoff or not needed
    Candidates passed Diploma are not eligible to take the Entrance Test as there
    are no lateral entry admissions.
    Candidate must have passed 10+2 or equivalent examination with the mentioned
    marks in Physics, Chemistry and Mathematics and should have passed thesesubjects individually with English as a compulsory subject from recognized by
    State/Central Government. Physics and Mathematics are compulsory subjects
    along with Chemistry or Bio Technology or Biology or Computer Science orElectronics as one of the optional subjects. Candidates belonging to OBC, SC
    and ST must be domicile of Karnataka state.
    Candidates passed Diploma are not eligible to take the Entrance Test as there
    are no lateral entry admissions.

### 4. ST

    Requirements for 12th grade: 40%
    COMEDK UGET: As per Cutoff or not needed
    CET: As per Cutoff or not needed
    Other Criteria
    Candidate must have passed 10+2 or equivalent examination with the mentionedmarks in Physics, Chemistry and Mathematics and should have passed these
    subjects individually with English as a compulsory subject from recognized by
    State/Central Government. Physics and Mathematics are compulsory subjectsalong with Chemistry or Bio Technology or Biology or Computer Science or
    Electronics as one of the optional subjects. Candidates belonging to OBC, SCand ST must be domicile of Karnataka state.
    Candidates passed Diploma are not eligible to take the Entrance Test as thereare no lateral entry admissions.
    Candidate must have passed 10+2 or equivalent examination with the mentionedmarks in Physics, Chemistry and Mathematics and should have passed these
    subjects individually with English as a compulsory subject from recognized byState/Central Government. Physics and Mathematics are compulsory subjects
    along with Chemistry or Bio Technology or Biology or Computer Science or
    Electronics as one of the optional subjects. Candidates belonging to OBC, SCand ST must be domicile of Karnataka state.

## MSRIT College Cutoff Details

### MSRIT COLLEGE KCET CUTOFF - GENERAL:

| Course                                                | 2022  | 2023  | 2024  |
| ----------------------------------------------------- | ----- | ----- | ----- |
| B.E. in Civil Engineering                             | 46447 | 35217 | 33103 |
| B.E. in Mechanical Engineering                        | 35226 | 27245 | 24096 |
| B.E. in Electronics and Communication Engineering     | 3985  | 4094  | 4564  |
| B.E. in Industrial Engineering and Management         | 43992 | 55277 | 37643 |
| B.E. in Electronics and Telecommunication Engineering | 8977  | 7914  | 6551  |
| B.E. in Biotechnology Engineering                     | 13775 | 15077 | 16766 |
| B.E. in Electrical and Electronics Engineering        | 9893  | 7763  | 9339  |
| B.E. in Chemical Engineering                          | 30946 | 26332 | 27194 |
| B.E. in Computer Science and Engineering              | 1125  | 1171  | 1626  |
| B.E. in Medical Electronics Engineering               | 23145 | 37624 | 37014 |
| B.E. in Information Science and Engineering           | 2265  | 1995  | 3105  |
| B.E. in Electronics and Instrumentation Engineering   | 12622 | 10794 | 10851 |
| B.E. in Artificial Intelligence and Data Science      | 3239  | 2860  | 4371  |

### MSRIT COLLEGE KCET CUTOFF - ST:

| Course                                                           | 2022   | 2023   | 2024   |
| ---------------------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Civil Engineering                                        | 80368  | 74724  | 47261  |
| B.E. in Mechanical Engineering                                   | 75164  | 105590 | 102510 |
| B.E. in Electronics and Communication Engineering                | 23597  | 26082  | 29184  |
| B.E. in Industrial Engineering and Management                    | 114110 | 117247 | 150686 |
| B.E. in Electronics and Telecommunication Engineering            | 50853  | 64345  | 52810  |
| B.E. in Biotechnology Engineering                                | 33641  | 52075  | 78737  |
| B.E. in Electrical and Electronics Engineering                   | 45030  | 46868  | 49051  |
| B.E. in Chemical Engineering                                     | 73921  | 153687 | 83266  |
| B.E. in Computer Science and Engineering                         | 6339   | 12563  | 14053  |
| B.E. in Medical Electronics Engineering                          | 111724 | 157206 | 116894 |
| B.E. in Information Science and Engineering                      | 14836  | 18851  | 26964  |
| B.E. in Electronics and Instrumentation Engineering              | 68159  | 81323  | 68718  |
| Bachelor of Architecture (B.Arch.)                               | – / –  | – / –  | 410    |
| B.E. in Artificial Intelligence and Data Science                 | 15859  | 25771  | 25646  |
| B.E. in Artificial Intelligence and Machine Learning             | – / –  | – / –  | 27283  |
| B.E. in Computer Science and Engineering (Cyber Security)        | – / –  | – / –  | 28625  |
| B.E. in Computer Science and Engineering (AI & Machine Learning) | – / –  | – / –  | 19046  |
| B.Tech. in Aerospace Engineering                                 | – / –  | – / –  | 47947  |

### MSRIT COLLEGE KCET CUTOFF- SC:

| Course                                                                                | 2022   | 2023   | 2024   |
| ------------------------------------------------------------------------------------- | ------ | ------ | ------ |
| B.E. in Civil Engineering                                                             | 80368  | 74724  | 47261  |
| B.E. in Mechanical Engineering                                                        | 75164  | 105590 | 102510 |
| B.E. in Electronics and Communication Engineering                                     | 23597  | 26082  | 29184  |
| B.E. in Industrial Engineering and Management                                         | 114110 | 117247 | 150686 |
| B.E. in Electronics and Telecommunication Engineering                                 | 50853  | 64345  | 52810  |
| B.E. in Biotechnology Engineering                                                     | 33641  | 52075  | 78737  |
| B.E. in Electrical and Electronics Engineering                                        | 45030  | 46868  | 49051  |
| B.E. in Chemical Engineering                                                          | 73921  | 153687 | 83266  |
| B.E. in Computer Science and Engineering                                              | 6339   | 12563  | 14053  |
| B.E. in Medical Electronics Engineering                                               | 111724 | 157206 | 116894 |
| B.E. in Information Science and Engineering                                           | 14836  | 18851  | 26964  |
| B.E. in Electronics and Instrumentation Engineering                                   | 68159  | 81323  | 68718  |
| Bachelor of Architecture (B.Arch.)                                                    | – / –  | – / –  | 410    |
| B.E. in Artificial Intelligence and Data Science                                      | 15859  | 25771  | 25646  |
| B.E. in Artificial Intelligence and Machine Learning                                  | – / –  | – / –  | 27283  |
| B.E. in Computer Science and Engineering (Cyber Security)                             | – / –  | – / –  | 28625  |
| B.E. in Computer Science and Engineering (Artificial Intelligence & Machine Learning) | – / –  | – / –  | 19046  |
| B.Tech. in Aerospace Engineering                                                      | – / –  | – / –  | 47947  |

### MSRIT COLLEGE KCET CUTOFF - OBC:

| Course                                                | 2022  | 2023  | 2024  |
| ----------------------------------------------------- | ----- | ----- | ----- |
| B.E. in Civil Engineering                             | 46447 | 35217 | 33103 |
| B.E. in Mechanical Engineering                        | 35226 | 27245 | 24096 |
| B.E. in Electronics and Communication Engineering     | 3985  | 4094  | 4564  |
| B.E. in Industrial Engineering and Management         | 43992 | 55277 | 37643 |
| B.E. in Electronics and Telecommunication Engineering | 8977  | 7914  | 6551  |
| B.E. in Biotechnology Engineering                     | 13775 | 15077 | 16766 |
| B.E. in Electrical and Electronics Engineering        | 9893  | 7763  | 9339  |
| B.E. in Chemical Engineering                          | 30946 | 26332 | 27194 |
| B.E. in Computer Science and Engineering              | 1125  | 1171  | 1626  |
| B.E. in Medical Electronics Engineering               | 23145 | 37624 | 37014 |
| B.E. in Information Science and Engineering           | 2265  | 1995  | 3105  |
| B.E. in Electronics and Instrumentation Engineering   | 12622 | 10794 | 10851 |
| B.E. in Artificial Intelligence and Data Science      | 3239  | 2860  | 4371  |

---

# End
